MoneyTransferAPI

1. The microservice, preinstalled-server-free RESTful API (including data model and the backing implementation) for money transfers between accounts

2. Stack
2.1.1. Java 8
2.1.2. Vert.x
2.1.3. H2 Database (an in-memory using)
2.1.4. Log4j
2.2. JUnit
2.3. Maven (through the Eclipse IDE, with a fat .jar)
