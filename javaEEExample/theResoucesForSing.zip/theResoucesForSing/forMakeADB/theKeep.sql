-- !first
/*
CONNECT system/vlastwliin..us ;

DROP USER myWords CASCADE ;

CREATE USER myWords
  IDENTIFIED BY 1 ;

GRANT CREATE SESSION, ALTER SESSION, CREATE DATABASE LINK, -
  CREATE MATERIALIZED VIEW, CREATE PROCEDURE, CREATE PUBLIC SYNONYM, -
  CREATE ROLE, CREATE SEQUENCE, CREATE SYNONYM, CREATE TABLE, -
  CREATE TRIGGER, CREATE TYPE, CREATE VIEW, UNLIMITED TABLESPACE -
  to myWords ;

-- 
DISCONNECT;
*/

-- !second
CONNECT myWords/1 ;

-- !the first second for do out
DROP SEQUENCE ments_als_seq;
DROP TABLE ments_als;

CREATE SEQUENCE ments_als_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE ments_als
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT ments_als_word_not_null NOT NULL
  CONSTRAINT ments_als_word_unique UNIQUE
, CONSTRAINT ments_als_pk PRIMARY KEY(word_id)
) ;

-- !the second second for do out
DROP SEQUENCE ants_ents_als_seq;
DROP TABLE ants_ents_als;

CREATE SEQUENCE ants_ents_als_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE ants_ents_als
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT ants_ents_als_word_not_null NOT NULL
  CONSTRAINT ants_ents_als_word_unique UNIQUE
, CONSTRAINT ants_ents_als_pk PRIMARY KEY(word_id)
) ;

-- !the third second for do out
DROP SEQUENCE udes_ures_als_seq;
DROP TABLE udes_ures_als;

CREATE SEQUENCE udes_ures_als_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE udes_ures_als
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT udes_ures_als_word_not_null NOT NULL
  CONSTRAINT udes_ures_als_word_unique UNIQUE
, CONSTRAINT udes_ures_als_pk PRIMARY KEY(word_id)
) ;

-- !the fourth second for do out
DROP SEQUENCE ouses_seq;
DROP TABLE ouses;

CREATE SEQUENCE ouses_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE ouses
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT ouses_word_not_null NOT NULL
  CONSTRAINT ouses_word_unique UNIQUE
, CONSTRAINT ouses_pk PRIMARY KEY(word_id)
) ;

-- !the fifth second for do out
DROP SEQUENCE ars_ies_als_seq;
DROP TABLE ars_ies_als;

CREATE SEQUENCE ars_ies_als_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE ars_ies_als
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT ars_ies_als_word_not_null NOT NULL
  CONSTRAINT ars_ies_als_word_unique UNIQUE
, CONSTRAINT ars_ies_als_pk PRIMARY KEY(word_id)
) ;

-- !the sixth second for do out
DROP SEQUENCE ors_ies_als_seq;
DROP TABLE ors_ies_als;

CREATE SEQUENCE ors_ies_als_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE ors_ies_als
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT ors_ies_als_word_not_null NOT NULL
  CONSTRAINT ors_ies_als_word_unique UNIQUE
, CONSTRAINT ors_ies_als_pk PRIMARY KEY(word_id)
) ;

-- !the seventh second for do out
DROP SEQUENCE prepositions_seq;
DROP TABLE prepositions;

CREATE SEQUENCE prepositions_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE prepositions
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT prepositions_word_not_null NOT NULL
  CONSTRAINT prepositions_word_unique UNIQUE
, CONSTRAINT prepositions_pk PRIMARY KEY(word_id)
) ;

-- !the eighth second for do out
DROP SEQUENCE conjunctions_seq;
DROP TABLE conjunctions;

CREATE SEQUENCE conjunctions_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE conjunctions
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT conjunctions_word_not_null NOT NULL
  CONSTRAINT conjunctions_word_unique UNIQUE
, CONSTRAINT conjunctions_pk PRIMARY KEY(word_id)
) ;

-- !the ninth second for do out
DROP SEQUENCE asks_seq;
DROP TABLE asks;

CREATE SEQUENCE asks_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE asks
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT asks_word_not_null NOT NULL
  CONSTRAINT asks_word_unique UNIQUE
, CONSTRAINT asks_pk PRIMARY KEY(word_id)
) ;

-- !the tenth second for do out
DROP SEQUENCE pronouns_seq;
DROP TABLE pronouns;

CREATE SEQUENCE pronouns_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE pronouns
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT pronouns_word_not_null NOT NULL
  CONSTRAINT pronouns_word_unique UNIQUE
, CONSTRAINT pronouns_pk PRIMARY KEY(word_id)
) ;

-- !the eleventh second for do out
DROP SEQUENCE ers_ies_als_seq;
DROP TABLE ers_ies_als;

CREATE SEQUENCE ers_ies_als_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE ers_ies_als
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT ers_ies_als_word_not_null NOT NULL
  CONSTRAINT ers_ies_als_word_unique UNIQUE
, CONSTRAINT ers_ies_als_pk PRIMARY KEY(word_id)
) ;

-- !!the twelfth - down
-- !the thirteenth second for do out
DROP SEQUENCE ities_encies_seq;
DROP TABLE ities_encies;

CREATE SEQUENCE ities_encies_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE ities_encies
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT ities_encies_word_not_null NOT NULL
  CONSTRAINT ities_encies_word_unique UNIQUE
, CONSTRAINT ities_encies_pk PRIMARY KEY(word_id)
) ;

-- !the fourteenth second for do out
DROP SEQUENCE ences_ances_seq;
DROP TABLE ences_ances;
CREATE SEQUENCE ences_ances_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE ences_ances
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT ences_ances_word_not_null NOT NULL
  CONSTRAINT ences_ances_word_unique UNIQUE
, CONSTRAINT ences_ances_pk PRIMARY KEY(word_id)
) ;

-- !the fifteenth second for do out
DROP SEQUENCE ates_seq;
DROP TABLE ates;

CREATE SEQUENCE ates_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE ates
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT ates_word_not_null NOT NULL
  CONSTRAINT ates_word_unique UNIQUE
, CONSTRAINT ates_pk PRIMARY KEY(word_id)
) ;

-- !the sixteenth second for do out
DROP SEQUENCE tions_sions_als_seq;
DROP TABLE tions_sions_als;

CREATE SEQUENCE tions_sions_als_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE tions_sions_als
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT tions_sions_als_word_not_null NOT NULL
  CONSTRAINT tions_sions_als_word_unique UNIQUE
, CONSTRAINT tions_sions_als_pk PRIMARY KEY(word_id)
) ;

-- !the seventeenth second for do out
DROP SEQUENCE ists__ics_als_seq;
DROP TABLE ists__ics_als;

CREATE SEQUENCE ists__ics_als_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE ists__ics_als
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT ists__ics_als_word_not_null NOT NULL
  CONSTRAINT ists__ics_als_word_unique UNIQUE
, CONSTRAINT ists__ics_als_pk PRIMARY KEY(word_id)
) ;

-- !the eighteenth second for do out
DROP SEQUENCE other_ics_als_seq;
DROP TABLE other_ics_als;

CREATE SEQUENCE other_ics_als_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE other_ics_als
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT other_ics_als_word_not_null NOT NULL
  CONSTRAINT other_ics_als_word_unique UNIQUE
, CONSTRAINT other_ics_als_pk PRIMARY KEY(word_id)
) ;

-- !the ninteenth second for do out
DROP SEQUENCE ums_ems_seq;
DROP TABLE ums_ems;

CREATE SEQUENCE ums_ems_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE ums_ems
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT ums_ems_word_not_null NOT NULL
  CONSTRAINT ums_ems_word_unique UNIQUE
, CONSTRAINT ums_ems_pk PRIMARY KEY(word_id)
) ;

-- !the twentieth second for do out
DROP SEQUENCE ings_seq;
DROP TABLE ings;

CREATE SEQUENCE ings_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE ings
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT ings_word_not_null NOT NULL
  CONSTRAINT ings_word_unique UNIQUE
, CONSTRAINT ings_pk PRIMARY KEY(word_id)
) ;

-- !the twenty-first second for do out
DROP SEQUENCE eds_seq;
DROP TABLE eds;

CREATE SEQUENCE eds_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE eds
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT eds_word_not_null NOT NULL
  CONSTRAINT eds_word_unique UNIQUE
, CONSTRAINT eds_pk PRIMARY KEY(word_id)
) ;

-- !the twenty-second second for do out
DROP SEQUENCE ships_hoods_seq;
DROP TABLE ships_hoods;

CREATE SEQUENCE ships_hoods_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE ships_hoods
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT ships_hoods_word_not_null NOT NULL
  CONSTRAINT ships_hoods_word_unique UNIQUE
, CONSTRAINT ships_hoods_pk PRIMARY KEY(word_id)
) ;

-- !the twenty-third second for do out
DROP SEQUENCE numbers_seq;
DROP TABLE numbers;

CREATE SEQUENCE numbers_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE numbers
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT numbers_word_not_null NOT NULL
  CONSTRAINT numbers_word_unique UNIQUE
, CONSTRAINT numbers_pk PRIMARY KEY(word_id)
) ;

-- !on the starts
-- !the twenty-fourth second for do out
DROP SEQUENCE pros_pres_seq;
DROP TABLE pros_pres;

CREATE SEQUENCE pros_pres_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE pros_pres
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT pros_pres_word_not_null NOT NULL
  CONSTRAINT pros_pres_word_unique UNIQUE
, CONSTRAINT pros_pres_pk PRIMARY KEY(word_id)
) ;

-- !the twenty-fifth second for do out
DROP SEQUENCE cons_coms_seq;
DROP TABLE cons_coms;

CREATE SEQUENCE cons_coms_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE cons_coms
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT cons_coms_word_not_null NOT NULL
  CONSTRAINT cons_coms_word_unique UNIQUE
, CONSTRAINT cons_coms_pk PRIMARY KEY(word_id)
) ;

-- !the twenty-sixth second for do out
DROP SEQUENCE other_cos_seq;
DROP TABLE other_cos;

CREATE SEQUENCE other_cos_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE other_cos
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT other_cos_word_not_null NOT NULL
  CONSTRAINT other_cos_word_unique UNIQUE
, CONSTRAINT other_cos_pk PRIMARY KEY(word_id)
) ;

-- !the twenty-sixth second for do out
DROP SEQUENCE lies_seq;
DROP TABLE lies;

CREATE SEQUENCE lies_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE lies
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT lies_word_not_null NOT NULL
  CONSTRAINT lies_word_unique UNIQUE
, CONSTRAINT lies_pk PRIMARY KEY(word_id)
) ;

-- !the twenty-seventh second for do out
DROP SEQUENCE tives_sives_seq;
DROP TABLE tives_sives;

CREATE SEQUENCE tives_sives_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE tives_sives
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT tives_sives_word_not_null NOT NULL
  CONSTRAINT tives_sives_word_unique UNIQUE
, CONSTRAINT tives_sives_pk PRIMARY KEY(word_id)
) ;

-- !the twenty-eighth second for do out
DROP SEQUENCE izes_ises_seq;
DROP TABLE izes_ises;

CREATE SEQUENCE izes_ises_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE izes_ises
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT izes_ises_word_not_null NOT NULL
  CONSTRAINT izes_ises_word_unique UNIQUE
, CONSTRAINT izes_ises_pk PRIMARY KEY(word_id)
) ;

-- ! ?
-- !the twelfth second for do out
DROP SEQUENCE ies_seq;
DROP TABLE ies;

CREATE SEQUENCE ies_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE ies
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT ies_word_not_null NOT NULL
  CONSTRAINT ies_word_unique UNIQUE
, CONSTRAINT ies_pk PRIMARY KEY(word_id)
) ;

-- !re-, un-, -fy... ir-, il-, in-, im-... 
-- !the twenty ninth second for do out
DROP SEQUENCE fies_seq;
DROP TABLE fies;

CREATE SEQUENCE fies_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE fies
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT fies_word_not_null NOT NULL
  CONSTRAINT fies_word_unique UNIQUE
, CONSTRAINT fies_pk PRIMARY KEY(word_id)
) ;

-- !the thirtieth second for do out
DROP SEQUENCE verbs_seq;
DROP TABLE verbs;

CREATE SEQUENCE verbs_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE verbs
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT verbs_word_not_null NOT NULL
  CONSTRAINT verbs_word_unique UNIQUE
, CONSTRAINT verbs_pk PRIMARY KEY(word_id)
) ;

-- !the thirty first second for do out
DROP SEQUENCE other_words_seq;
DROP TABLE other_words;

CREATE SEQUENCE other_words_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE other_words
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT other_words_word_not_null NOT NULL
  CONSTRAINT other_words_word_unique UNIQUE
, CONSTRAINT other_words_pk PRIMARY KEY(word_id)
) ;

-- !the thirty second second for do out
DROP SEQUENCE ies_as_y_seq;
DROP TABLE ies_as_y;

CREATE SEQUENCE ies_as_y_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE ies_as_y
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT ies_as_y_word_not_null NOT NULL
  CONSTRAINT ies_as_y_word_unique UNIQUE
, CONSTRAINT ies_as_y_pk PRIMARY KEY(word_id)
) ;

-- !the thirty third second for do out
DROP SEQUENCE adverbs_seq;
DROP TABLE adverbs;

CREATE SEQUENCE adverbs_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE adverbs
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT adverbs_word_not_null NOT NULL
  CONSTRAINT adverbs_word_unique UNIQUE
, CONSTRAINT adverbs_pk PRIMARY KEY(word_id)
) ;

-- !the thirty fourth second for do out
DROP SEQUENCE ses_seq;
DROP TABLE ses;

CREATE SEQUENCE ses_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE ses
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT ses_word_not_null NOT NULL
  CONSTRAINT ses_word_unique UNIQUE
, CONSTRAINT ses_pk PRIMARY KEY(word_id)
) ;

-- !the thirty fifth second for do out
DROP SEQUENCE esses__nesses_seq;
DROP TABLE esses__nesses;

CREATE SEQUENCE esses__nesses_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE esses__nesses
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT esses__nesses_word_not_null NOT NULL
  CONSTRAINT esses__nesses_word_unique UNIQUE
, CONSTRAINT esses__nesses_pk PRIMARY KEY(word_id)
) ;

-- !the thirty sixth second for do out
DROP SEQUENCE dises_seq;
DROP TABLE dises;

CREATE SEQUENCE dises_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE dises
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT dises_word_not_null NOT NULL
  CONSTRAINT dises_word_unique UNIQUE
, CONSTRAINT dises_pk PRIMARY KEY(word_id)
) ;

-- !the thirty seventh second for do out
DROP SEQUENCE odd_verbs_seq;
DROP TABLE odd_verbs;

CREATE SEQUENCE odd_verbs_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE odd_verbs
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT odd_verbs_word_not_null NOT NULL
  CONSTRAINT odd_verbs_word_unique UNIQUE
, CONSTRAINT odd_verbs_pk PRIMARY KEY(word_id)
) ;

-- !the thirty eigh(t)th second for do out
DROP SEQUENCE long_verbs_seq;
DROP TABLE long_verbs;

CREATE SEQUENCE long_verbs_seq
  START WITH 1
  INCREMENT BY 1 ;

CREATE TABLE long_verbs
( word_id NUMBER( 6, 0 )
, word VARCHAR2(48)
  CONSTRAINT long_verbs_word_not_null NOT NULL
  CONSTRAINT long_verbs_word_unique UNIQUE
, CONSTRAINT long_verbs_pk PRIMARY KEY(word_id)
) ;

DISCONNECT;