package com.condar.first;

import java.io.File;
import java.io.Reader;
import java.io.Writer;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.StreamTokenizer;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Scanner;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;

public class ForTheParse
{
  static String toTheNameOfTheFile;
  
  static File doParse()
  {
    //D:/rb/nynw/myProjects/forMakeTheFirst/dictionary.txt
    File toTheFile = new File(toTheNameOfTheFile),
        toTheFruitedFile = new File( toTheFile.getPath()
            .substring( 0, toTheFile.getPath().lastIndexOf('\\') )
            + "/myDictionary.txt" );
    
    try( Reader r = new BufferedReader( new FileReader(toTheFile) );
        Writer wr = new BufferedWriter( new FileWriter(toTheFruitedFile) );
        //Writer trashWr = new BufferedWriter( new FileWriter(
        //    "D:/rb/nynw/myProjects/forMakeTheFirst/trashDictionary.txt") ) 
        )
    {
      StreamTokenizer toTheCutOfAStream = new StreamTokenizer(r);
      toTheCutOfAStream.resetSyntax();
      toTheCutOfAStream.wordChars( 0x20, 0x7A );
      toTheCutOfAStream.whitespaceChars( 0xA, 0xA );
      
      StringTokenizer toTheCutOfAString; 
      
      int count = 0, trashCount = 0;
      String the = "", oldThe = null, theNextWord;
      
      Set<Character> theOne = new HashSet<>(),
          theNext = new HashSet<>();
      
      Set<String> theOnesOfOneSign = new HashSet<>();//do with your for-write signs
      theOnesOfOneSign.add("a");//only one...--!into the file!
      
      Set<String> theOnesOfTwoSigns = new HashSet<>();
      theOnesOfTwoSigns.addAll( Arrays.asList(
          "am", "an", "as", "at", "be", "by", "do", "go", "ha", "he",
          "if", "in", "is", "it", "me", "my", "no", "of", "on", "or",
          "re", "so", "to", "up", "us", "we" ) );//into the file!
      
      Set<String> theUngoodOnesOfThreeSigns = new HashSet<>();//with the Google
      theUngoodOnesOfThreeSigns.addAll( Arrays.asList(
          "abn", "abo", "aha", "amu", "ana", "aol", "aro", "asf",
          "ats", "awu", "bam", "bap", "boa", "bod", "bpi", "cay",
          "cca", "col", "coo", "cor", "cos", "coy", "dak", "dan",
          "dap", "das", "deb", "dor", "dpi", "duo", "emu", "erg",
          "esu", "etc", "fax", "feu", "gay", "gnu", "hah", "hoi",
          "huh", "inv", "lor", "mac", "mem", "mep", "mho", "mod",
          "nom", "nos", "obi", "ohm", "oho", "oik", "ope", "pec",
          "phi", "pia", "poo", "ppa", "qwi", "rah", "roc", "rte",
          "sab", "sen", "ser", "spa", "sui", "ugh", "ups", "vac",
          "viz", "wop", "yea", "yum", "zed", "zee" ) );//into the file!
      
      while( toTheCutOfAStream.nextToken() != StreamTokenizer.TT_EOF )
      {
        if( toTheCutOfAStream.sval != null && toTheCutOfAStream.sval
            .startsWith("   ") )
        {
          toTheCutOfAString = new StringTokenizer( toTheCutOfAStream.sval, " " );
          if( toTheCutOfAString.hasMoreTokens() )
          {
            the = toTheCutOfAString.nextToken();
            theNextWord = toTheCutOfAString.hasMoreTokens() ?
                toTheCutOfAString.nextToken() : "  ";
            
            if( theNextWord.length() == 1 )
            {
              theNextWord += " ";
            }
            
            theOne.clear();
            for( Character c : the.toCharArray() )
            {
              theOne.add(c);
            }
            
            theNext.clear();
            for( Character c : theNextWord.toCharArray() )
            {
              theNext.add(c);
            }
            
            if( ! the.toLowerCase().equals(oldThe) && the.matches("^[a-z]+(-[a-z]+)?$")
                && ! ( the.matches("^[bcdfghjklmnpqrstvwxyz]+(-[a-z]+)?$")
                    || the.matches("^[aeiou]+(-[a-z]+)?$") ) )
            {
              if( ! ( theNext.containsAll(theOne)
                  && the.substring( 0, 2 )
                  .equals( theNextWord.substring( 0, 2 ) ) )
                  && ! theUngoodOnesOfThreeSigns.contains(the)//( the.equals("abn") )
                  && ! ( the.equals("acft") || the.equals("whse") || the.equals("pkge") )//!!more/unto...
                  || ( the.equals("noon") || the.equals("noun") )//!!agains...// )//after scan(ning) the trash and after know on the doubled signs
                    //in either parts and on the even/extra signs in the abbreviations(exx)...
                  || theOnesOfOneSign.contains(the)
                  || theOnesOfTwoSigns.contains(the) )
              {
                wr.write( ++count + ") " + the + "\r\n" );
                oldThe = the.toLowerCase();
              }
              else
              {
                //trashWr.write( ++trashCount + ") " + the + " -- " + theNextWord + "\r\n" );
              }
              
            }
            
          }
          
        }
        
      }
      
    }
    catch( IOException ex )
    {
      ex.printStackTrace();
    }
    
    //System.out.println("!The trash file is made.");
    
    return toTheFruitedFile;
    
  }
  /*
  static File doMoreParse()
  {
    //D:/rb/nynw/myProjects/forMakeTheFirst/dictionary.txt
    File toTheFile = new File("D:/rb/nynw/myProjects/forMakeTheFirst/myDictionary.txt"),
        toTheFruitedFile = new File("D:/rb/nynw/myProjects/forMakeTheFirst"
        + "/myShortenedDictionary.txt");
    
    try( Scanner toTheScan = new Scanner( new BufferedReader( new FileReader(toTheFile) ) );//!to the Scanner class
        Writer wr = new BufferedWriter( new FileWriter(toTheFruitedFile) ) )
    {
      String toTheWord;
      int at = 1;
      while( toTheScan.hasNext() )
      {
        toTheScan.next();
        toTheWord = toTheScan.next();
        if( toTheWord.length() == 4 )//== 1 )//toTheWord.length() < 3 )
        {
          wr.write( at++ + ") " + toTheWord +"\r\n" );
        }
        
      }
      
    }
    catch( IOException ex )
    {
      ex.printStackTrace();
    }
    
    return toTheFruitedFile;
    
  }
  */
  public static void main( String[] theArgumentsOfTheCallWithTheCommandLine )
  {
    if( theArgumentsOfTheCallWithTheCommandLine != null
        && theArgumentsOfTheCallWithTheCommandLine.length == 1 )
    {
      
      toTheNameOfTheFile = theArgumentsOfTheCallWithTheCommandLine[0];
      File toTheFruitedFile = doParse();
      System.out.println( "Done! " + toTheFruitedFile );
      /*
      toTheFruitedFile = doMoreParse();
      System.out.println( "Done! " + toTheFruitedFile );
      */
    }
    else
    {
      System.out.println("I am kindly asking of you to write\n"
          + "only one of-file name!");
    }
    
  }
  
}



/**package com.condar.first;

import java.io.File;
import java.io.Reader;
import java.io.Writer;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.StreamTokenizer;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Scanner;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;

public class ForTheParse
{
  static String toTheNameOfTheFile;
  
  static File doParse()
  {
    //D:/rb/nynw/myProjects/forMakeTheFirst/dictionary.txt
    File toTheFile = new File(toTheNameOfTheFile),
        toTheFruitedFile = new File( toTheFile.getPath()
            .substring( 0, toTheFile.getPath().lastIndexOf('\\') )
            + "/myDictionary.txt" );
    
    try( Reader r = new BufferedReader( new FileReader(toTheFile) );
        Writer wr = new BufferedWriter( new FileWriter(toTheFruitedFile) );
        Writer trashWr = new BufferedWriter( new FileWriter(
            "D:/rb/nynw/myProjects/forMakeTheFirst/trashDictionary.txt") ))
    {
      StreamTokenizer toTheCutOfAStream = new StreamTokenizer(r);
      toTheCutOfAStream.resetSyntax();
      toTheCutOfAStream.wordChars( 0x20, 0x7A );
      toTheCutOfAStream.whitespaceChars( 0xA, 0xA );
      
      StringTokenizer toTheCutOfAString; 
      
      int count = 0, trashCount = 0;
      String the = "", oldThe = null, theNextWord;
      
      Set<Character> theOne = new HashSet<>(),
          theNext = new HashSet<>();
      
      Set<String> theOnesOfOneSign = new HashSet<>();//do with your for-write signs
      theOnesOfOneSign.add("a");//only one...--!into the file!
      
      Set<String> theOnesOfTwoSigns = new HashSet<>();
      theOnesOfTwoSigns.addAll( Arrays.asList(
          "am", "an", "as", "at", "be", "by", "do", "go", "ha", "he",
          "if", "in", "is", "it", "me", "my", "no", "of", "on", "or",
          "re", "so", "to", "up", "us", "we" ) );//into the file!
      
      Set<String> theUngoodOnesOfThreeSigns = new HashSet<>();//with the Google
      theUngoodOnesOfThreeSigns.addAll( Arrays.asList(
          "abn", "abo", "aha", "amu", "ana", "aol", "aro", "asf",
          "ats", "awu", "bam", "bap", "boa", "bod", "bpi", "cay",
          "cca", "col", "coo", "cor", "cos", "coy", "dak", "dan",
          "dap", "das", "deb", "dor", "dpi", "duo", "emu", "erg",
          "esu", "etc", "fax", "feu", "gay", "gnu", "hah", "hoi",
          "huh", "inv", "lor", "mac", "mem", "mep", "mho", "mod",
          "nom", "nos", "obi", "ohm", "oho", "oik", "ope", "pec",
          "phi", "pia", "poo", "ppa", "qwi", "rah", "roc", "rte",
          "sab", "sen", "ser", "spa", "sui", "ugh", "ups", "vac",
          "viz", "wop", "yea", "yum", "zed", "zee" ) );//into the file!
      
      while( toTheCutOfAStream.nextToken() != StreamTokenizer.TT_EOF )
      {
        if( toTheCutOfAStream.sval != null && toTheCutOfAStream.sval
            .startsWith("   ") )
        {
          toTheCutOfAString = new StringTokenizer( toTheCutOfAStream.sval, " " );
          if( toTheCutOfAString.hasMoreTokens() )
          {
            the = toTheCutOfAString.nextToken();
            theNextWord = toTheCutOfAString.hasMoreTokens() ?
                toTheCutOfAString.nextToken() : "  ";
            //after view the shortened:
            /*
            //!it helps with only one word the bo...--view the set of words of two signs
            if( theNextWord.equals("I") ||
                theNextWord.equals("II") ||
                theNextWord.equals("III") ||
                theNextWord.equals("IV") )
            {
              theNextWord = toTheCutOfAString.hasMoreTokens() ?
                  toTheCutOfAString.nextToken()
                  .toLowerCase() : "  ";
            }
            //theNextWord = theNextWord.toLowerCase();
            *//**
            
            if( theNextWord.length() == 1 )
            {
              theNextWord += " ";
            }
            
            theOne.clear();
            for( Character c : the.toCharArray() )
            {
              theOne.add(c);
            }
            
            theNext.clear();
            for( Character c : theNextWord.toCharArray() )
            {
              theNext.add(c);
            }
            
            if( ! the.toLowerCase().equals(oldThe) && the.matches("^[a-z]+(-[a-z]+)?$")
                && ! ( the.matches("^[bcdfghjklmnpqrstvwxyz]+(-[a-z]+)?$")
                    || the.matches("^[aeiou]+(-[a-z]+)?$") )
                //&& ! ( theNext.containsAll(theOne)
                //    && the.substring( 0, 2 ).equals( theNextWord.substring( 0, 2 ) ) )
                )
            {
              if( ! ( theNext.containsAll(theOne)
                  && the.substring( 0, 2 )
                  .equals( theNextWord.substring( 0, 2 ) ) )
                  && ! theUngoodOnesOfThreeSigns.contains(the)//( the.equals("abn") )
                  && ! ( the.equals("acft") || the.equals("whse") || the.equals("pkge") )//!!more/unto...
                  || ( the.equals("noon") || the.equals("noun") )//!!agains...// )//after scan(ning) the trash and after know on the doubled signs
                    //in either parts and on the even/extra signs in the abbreviations(exx)...
                  || theOnesOfOneSign.contains(the)
                  || theOnesOfTwoSigns.contains(the)
                  //|| theOnesOfThreeSigns.contains(the) 
                  )
              {
                wr.write( ++count + ") " + the + "\r\n" );
                oldThe = the.toLowerCase();
              }
              else
              {
                trashWr.write( ++trashCount + ") " + the + " -- " + theNextWord + "\r\n" );
              }
              
            }
            
          }
          
        }
        
      }
      
    }
    catch( IOException ex )
    {
      ex.printStackTrace();
    }
    
    System.out.println("!The trash file is made.");
    
    return toTheFruitedFile;
    
  }
  
  static File doMoreParse()
  {
    //D:/rb/nynw/myProjects/forMakeTheFirst/dictionary.txt
    File toTheFile = new File("D:/rb/nynw/myProjects/forMakeTheFirst/myDictionary.txt"),
        toTheFruitedFile = new File("D:/rb/nynw/myProjects/forMakeTheFirst"
        + "/myShortenedDictionary.txt");
    
    try( Scanner toTheScan = new Scanner( new BufferedReader( new FileReader(toTheFile) ) );//!to the Scanner class
        Writer wr = new BufferedWriter( new FileWriter(toTheFruitedFile) ) )
    {
      String toTheWord;
      int at = 1;
      while( toTheScan.hasNext() )
      {
        toTheScan.next();
        toTheWord = toTheScan.next();
        if( toTheWord.length() == 4 )//== 1 )//toTheWord.length() < 3 )
        {
          wr.write( at++ + ") " + toTheWord +"\r\n" );
        }
        
      }
      
    }
    catch( IOException ex )
    {
      ex.printStackTrace();
    }
    
    return toTheFruitedFile;
    
  }
  
  public static void main( String[] theArgumentsOfTheCallWithTheCommandLine )
  {
    if( theArgumentsOfTheCallWithTheCommandLine != null
        && theArgumentsOfTheCallWithTheCommandLine.length == 1 )
    {
      
      toTheNameOfTheFile = theArgumentsOfTheCallWithTheCommandLine[0];
      File toTheFruitedFile = doParse();
      System.out.println( "Done! " + toTheFruitedFile );
      
      toTheFruitedFile = doMoreParse();
      System.out.println( "Done! " + toTheFruitedFile );
      
    }
    else
    {
      System.out.println("I am kindly asking of you to write\n"
          + "only one of-file name!");
    }
    
  }
  
}
**/


/**package com.condar.first;

import java.io.File;
import java.io.Reader;
import java.io.Writer;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.StreamTokenizer;
import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Scanner;
import java.util.Arrays;
import java.util.Set;
import java.util.HashSet;
import java.util.List;

public class ForTheParse
{
  static String toTheNameOfAFile;
  
  static File doParse()//( String toTheNameOfAFile )
  {
    //D:/rb/nynw/myProjects/forMakeTheFirst/dictionary.txt
    File toTheFile = new File(toTheNameOfAFile),
        toTheFruitedFile = new File( toTheFile.getPath()
                .substring( 0, toTheFile.getPath().lastIndexOf('\\') )
            + "/myDictionary.txt" );
    
    try( Reader r = new BufferedReader( new FileReader(toTheFile) );
        Writer wr = new BufferedWriter( new FileWriter(toTheFruitedFile) );
        Writer trashWr = new BufferedWriter( new FileWriter(
            "D:/rb/nynw/myProjects/forMakeTheFirst/trashDictionary.txt") ))
    {
      StreamTokenizer toTheCutOfAStream = new StreamTokenizer(r);
      toTheCutOfAStream.resetSyntax();
      toTheCutOfAStream.wordChars( 0x20, 0x7A );
      toTheCutOfAStream.whitespaceChars( 0xA, 0xA );
      
      StringTokenizer toTheCutOfAString; 
      
      int count = 0, trashCount = 0;
      String the = "", oldThe = null, theNextWord;
      //char[] theSet, theNextSet;
      //Set<Character> theOne, theNextSet;
      //List<Character> theList;
      //byte[] theOne, theNext;
      Set<Character> theOne = new HashSet<>(),
          theNext = new HashSet<>();
      
      while( toTheCutOfAStream.nextToken() != StreamTokenizer.TT_EOF )
      {
        if( toTheCutOfAStream.sval != null && toTheCutOfAStream.sval
            .startsWith("   ") )
        {
          toTheCutOfAString = new StringTokenizer( toTheCutOfAStream.sval, " " );
          if( toTheCutOfAString.hasMoreTokens() )
          {
            the = toTheCutOfAString.nextToken();
            theNextWord = toTheCutOfAString.hasMoreTokens() ?
                toTheCutOfAString.nextToken() : "  ";//!!!
            //!!!!!
            if( theNextWord.length() == 1 )
            {
              theNextWord += " ";
            }
            //System.out.println("!!" + "abc".contains("cb") );
            //theSet = the.toCharArray();
            //theNextSet = theNextWord.toCharArray();
            //java.util.Set<Character> st = new java.util.HashSet<Character>(Arrays.asList(the));
            //Arrays.sort(theNextSet);
            //java.util.Collections.
            //theList = Arrays.asList( the.toCharArray() );
            //theOne = new HashSet<Character>( the.getBytes() );
            /*
            the = "fuck";
            theNextWord = "kcuf";
            theOne = the.getBytes();
            theNext = theNextWord.getBytes();
            Arrays.sort(theOne);
            Arrays.sort(theNext);
            System.out.println( (char) theOne[0] );
            System.out.println( (char) theNext[0] );
            try
            {
              Thread.currentThread().sleep(10000);
            }
            catch( Exception ex ){}
            *//**
            theOne.clear();
            for( Character c : the.toCharArray() )
            {
              theOne.add(c);
            }
            
            theNext.clear();
            for( Character c : theNextWord.toCharArray() )
            {
              theNext.add(c);
            }
            
            if( ! the.toLowerCase().equals(oldThe) && the
                    .matches("^[a-z]+(-[a-z]+)?$")//"^[A-Z]?[a-z]+(-[A-Z]?[a-z]+)?$")
                && ! ( the.matches
                        ("^[bcdfghjklmnpqrstvwxyz]+(-[a-z]+)?$")//"^[bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ]+(-[A-Z]?[a-z]+)?$")
                    || the.matches
                        ("^[aeiou]+(-[a-z]+)?$") )//"^[\\w&&\\D&&[^_bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ]]+"
                         //   + "(-[A-Z]?[a-z]+)?$") )//{2,}$") )//"[a-zA-Z]+") )
                //&& ( theNextWord != null && theNextWord.length() >= 2
                //    && the.substring( 0, 2 ).equals( theNextWord.substring( 0, 2 ) ) ) )//!!!
                && //( theNextWord.length() >= 2 &&
                    ! ( theNext.containsAll(theOne)//java.util.Arrays.sort( theNextWord.toCharArray() ).//!no that:theNextWord.contains(the)
                        && the.substring( 0, 2 ).equals( theNextWord.substring( 0, 2 ) ) )
                //&& ! (
                //    the.equals("abn")
                //    || the.equals("abt")
                //    )
                )//!!!!by the shorten
              //!!!
            {
              wr.write( ++count + ") " + the + "\r\n" );
              oldThe = the.toLowerCase();
              
            }
            else if( ! the.toLowerCase().equals(oldThe) && the
                    .matches("^[a-z]+(-[a-z]+)?$")
                && ! ( the.matches
                    ("^[bcdfghjklmnpqrstvwxyz]+(-[a-z]+)?$")
                || the.matches("^[aeiou]+(-[a-z]+)?$") )
                && theNext.containsAll(theOne)
                    && the.substring( 0, 2 ).equals( theNextWord.substring( 0, 2 ) ) )
            {
              trashWr.write( ++trashCount + ") " + the + " -- " + theNextWord + "\r\n" );
            }
            
          }
          
        }
        
      }
      
    }
    catch( IOException ex )
    {
      ex.printStackTrace();
    }
    
    return toTheFruitedFile;
    
  }
  
  static File doMoreParse()//( String toTheNameOfAFile )
  {
    //D:/rb/nynw/myProjects/forMakeTheFirst/dictionary.txt
    File toTheFile = new File("D:/rb/nynw/myProjects/forMakeTheFirst/myDictionary.txt"),
        toTheFruitedFile = new File("D:/rb/nynw/myProjects/forMakeTheFirst"
            + "/myShortenedDictionary.txt");
    
    try( Scanner toTheScan = new Scanner( new BufferedReader( new FileReader(toTheFile) ) );//!to the Scanner class
        Writer wr = new BufferedWriter( new FileWriter(toTheFruitedFile) ) )
    {
      //Scanner toTheScan = new Scanner(toTheFile);
      //toTheScan.useDelimiter("\n|(\r\n)");//"^(/r/n)| $");
      ///System.out.println( toTheScan.next() );
      ///System.out.println( toTheScan.next() );
      ///System.out.println( toTheScan.next() );
      String toTheWord;
      int at = 1;
      while( toTheScan.hasNext() )//the second next...//(!unwork!)hasNextLine() )//(!unwork)"1.") )//"^[A-Za-z]{4}$") )//"^[0-9]+\\) [A-Za-z]{4}$") )
      {
        //System.out.println("!in the loop");
        
        toTheScan.next();//"^[A-Za-z]+$");//"^[A-Za-z]{4}$");//"^[0-9]+\\) [A-Za-z]{4}$");//"^[A-Z]?[a-z]{3}$");
        toTheWord = toTheScan.next();
        //System.out.println( "!!" + toTheWord.substring( 0, 1 ) );//toTheWord.length() - 1 ) );
        //if( toTheWord != null )
        if( toTheWord.length() < 3 )//&& toTheWord.matches("^$") )--!!3,4-4,5-5...
        {
          wr.write( at + ") " + toTheWord +"\r\n" );
          ++at;
          
        }
        
      }
      
    }
    catch( IOException ex )
    {
      ex.printStackTrace();
    }
    
    return toTheFruitedFile;
    
  }
  
  public static void main( String[] theArgumentsOfTheCallWithTheCommandLine )
  {
    if( theArgumentsOfTheCallWithTheCommandLine != null
        && theArgumentsOfTheCallWithTheCommandLine.length == 1 )
    {
      
      toTheNameOfAFile = theArgumentsOfTheCallWithTheCommandLine[0];
      File toTheFruitedFile = doParse();//( theArgumentsOfTheCallWithTheCommandLine[0] );
      System.out.println( "Done! " + toTheFruitedFile );
      
      toTheFruitedFile = doMoreParse();
      System.out.println( "Done! " + toTheFruitedFile );
      
    }
    else
    {
      System.out.println("I am kindly asking of you to write\n"
          + "only one of-file name!");
      //return;
      
    }
    
  }
  
}
**/


/**package com.condar.first;

import java.io.File;
import java.io.Reader;
import java.io.Writer;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.StreamTokenizer;
import java.io.IOException;
import java.util.StringTokenizer;

public class ForTheParse
{
  static File doParse( String forANameOfAFile )
  {
    File theFile;
    
    
  }
  
  public static void main( String[] theArgumentsOfTheCallWithTheCommandLine )//theNames )//OfTheFile)//forLaunch )//forArgumentsOfLaunchingWithTheCommandLine )
  {
    File theFile;
    if( theArgumentsOfTheCallWithTheCommandLine != null
        && theArgumentsOfTheCallWithTheCommandLine.length == 1 )
    {
      theFile = new File( theArgumentsOfTheCallWithTheCommandLine[0] );
    }
    else
    {
      System.out.println("I am kindly asking of you to write\n"
          + "only one of-file name!");
      return;
      
    }
    //D:\rb\nynw\myProjects\forMakeTheFirst/dictionary.txt
    //System.out.println("!");
    
    try( Reader r = new BufferedReader( new FileReader(theFile) );// )//theNames[0] ) ) )
        Writer wr = new BufferedWriter( new FileWriter( theFile.getPath().substring( 0,
            theFile.getPath().lastIndexOf('\\') ) + "/myDictionary.txt" ) ) )//System.getProperty("user.dir") + "Dictionary.txt" ) ) )
    {
      StreamTokenizer theOfstreamCut = new StreamTokenizer(r);
      theOfstreamCut.resetSyntax();
      theOfstreamCut.wordChars( 0x20, 0x7A );//0x0B, 0x7A );//0x20, 0x7A );
      theOfstreamCut.whitespaceChars( 0xA, 0xA );
      //theOfstreamCut.eolIsSignificant(false);
      
      StringTokenizer theOfstringCut; 
      
      int count = 0;
      String the = "", oldThe = null;
      //System.out.println( the.equals( "!" + oldThe ) );
      //System.out.println( "!" + "asd-asd".matches("^([a-z]*)-\\1$") );//--!ser:group as fruit,only if asd=asd...//"^([A-Z]?[a-z]*)(-\1)?$") );
      while( theOfstreamCut.nextToken() != theOfstreamCut.TT_EOF )
      {
        //System.out.println( theOfstreamCut.sval );
        if( theOfstreamCut.sval != null && theOfstreamCut.sval.startsWith("   ") )
        {
          theOfstringCut = new StringTokenizer( theOfstreamCut.sval, " " );
          if( theOfstringCut.hasMoreTokens() )
          {
            the = theOfstringCut.nextToken();
            if( ( ! ( the.toLowerCase() ).equals(oldThe) ) && the.matches("^[A-Z]?[a-z]+(-[A-Z]?[a-z]+)?$")
                && ! ( the.matches("^[bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ]+(-[A-Z]?[a-z]+)?$")
                    || the.matches("^[\\w&&\\D&&[^_bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ]]+(-[A-Z]?[a-z]+)?$") ) )//{2,}$") )//"[a-zA-Z]+") )
            {
              //!!System.out.println( ++count + ") " + the );
              wr.write( ++count + ") " + the + "\r\n" );//!ser(and in tasks):(char)0xd + (char)0xa );//+ (char)0xd );//a );//0xc );//!the Notepad shows the '\n' untruly...
              oldThe = the.toLowerCase();
              
            }
            
          }
          
        }
        
      }
      
    }
    catch( IOException ex )
    {
      ex.printStackTrace();
    }
    
  }
  
}



/*package com.condar.first;

import java.io.File;
import java.io.Reader;
import java.io.Writer;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.StreamTokenizer;
import java.io.IOException;
import java.util.StringTokenizer;

public class ForTheParse
{
  public static void main( String[] theNames )//OfTheFile)//forLaunch )//forArgumentsOfLaunchingWithTheCommandLine )
  {
    File theFile;
    if( theNames != null
        && theNames.length == 1 )
    {
      theFile = new File( theNames[0] );
    }
    else
    {
      System.out.println("I am kindly asking of you to write\n"
          + "only one of-file name!");
      return;
      
    }
    //D:\rb\nynw\myProjects\forMakeTheFirst/Dictionary.txt
    //System.out.println("!");
    
    try( Reader r = new BufferedReader( new FileReader(theFile) ) )//theNames[0] ) ) )
    {
      StreamTokenizer theOfstreamCut = new StreamTokenizer(r);
      theOfstreamCut.resetSyntax();
      theOfstreamCut.wordChars( 0x20, 0x7A );//0x0B, 0x7A );//0x20, 0x7A );
      theOfstreamCut.whitespaceChars( 0xA, 0xA );
      //theOfstreamCut.eolIsSignificant(false);
      
      StringTokenizer theOfstringCut; 
      
      int count = 0;
      String the = "", oldThe = null;
      //System.out.println( the.equals( "!" + oldThe ) );
      //System.out.println( "!" + "asd-asd".matches("^([a-z]*)-\\1$") );//--!ser:group as fruit,only if asd=asd...//"^([A-Z]?[a-z]*)(-\1)?$") );
      while( theOfstreamCut.nextToken() != theOfstreamCut.TT_EOF )
      {
        //System.out.println( theOfstreamCut.sval );
        if( theOfstreamCut.sval != null && theOfstreamCut.sval.startsWith("   ") )
        {
          theOfstringCut = new StringTokenizer( theOfstreamCut.sval, " " );
          if( theOfstringCut.hasMoreTokens() )
          {
            the = theOfstringCut.nextToken();
            if( ( ! ( the.toLowerCase() ).equals(oldThe) ) && the.matches("^[A-Z]?[a-z]*(-[A-Z]?[a-z]+)?$") )//"[a-zA-Z]+") )
            {
              System.out.println( ++count + ") " + the );
              oldThe = the.toLowerCase();
              
            }
            
          }
          
        }
        
      }
      
    }
    catch( IOException ex )
    {
      ex.printStackTrace();
    }
    
  }
  
}*/