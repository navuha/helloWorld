package com.condar.first;

import com.condar.first.ForTheParse;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class AppTest
{
  @Test
  public void testApp()
  {
    ForTheParse.toTheNameOfTheFile = "D:/rb/nynw/myProjects/forMakeTheFirst/dictionary.txt";
    assertEquals( "There is no the due returned file!", "D:\\rb\\nynw\\myProjects\\forMakeTheFirst\\myDictionary.txt",
        ForTheParse.doParse().getAbsolutePath() );
    
  }
  
}