package com.condar.first;

import java.io.File;
import java.io.Writer;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Set;
import java.util.HashSet;
import java.util.Arrays;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import oracle.jdbc.pool.OracleDataSource;

import java.sql.ResultSet;

public class ForTheParse2_01
{
  //...
  static File doEvenMoreParse()
  {
    File toTheFile = new File("D:/rb/nynw/myProjects/forMakeTheFirst/myDictionary.txt"),
        toTheFruitedFile = new File("D:/rb/nynw/myProjects/forMakeTheFirst"
        + "/myShortenedDictionary.txt");
    
    String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
    OracleDataSource toTheDBSource = null;
    try
    {
      toTheDBSource = new OracleDataSource();
      toTheDBSource.setURL(jdbcURL);
      
    }
    catch( SQLException ex )
    {
      ex.printStackTrace();
    }
    
    //String toTheStringForCommand = "INSERT INTO ? VALUES( ents_ants_seq.NEXTVAL, ? )";
    
    try( Scanner toTheScan = new Scanner( new BufferedReader( new FileReader(toTheFile) ) );//!to the Scanner class
        Writer wr = new BufferedWriter( new FileWriter(toTheFruitedFile) );
        Connection toTheCon = toTheDBSource.getConnection( "myWords", "1" );
        PreparedStatement toTheCommandForInsertIntoTheMENTS_ALS = toTheCon.prepareStatement(
            "INSERT INTO ments_als VALUES( ments_als_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheANTS_ENTS_ALS = toTheCon.prepareStatement(
            "INSERT INTO ants_ents_als VALUES( ants_ents_als_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheUDES_URES_ALS = toTheCon.prepareStatement(
            "INSERT INTO udes_ures_als VALUES( udes_ures_als_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheOUSES = toTheCon.prepareStatement(
            "INSERT INTO ouses VALUES( ouses_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheARS_IES_ALS = toTheCon.prepareStatement(
            "INSERT INTO ars_ies_als VALUES( ars_ies_als_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheORS_IES_ALS = toTheCon.prepareStatement(
            "INSERT INTO ors_ies_als VALUES( ors_ies_als_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoThePREPOSITIONS = toTheCon.prepareStatement(
            "INSERT INTO prepositions VALUES( prepositions_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheCONJUNCTIONS = toTheCon.prepareStatement(
            "INSERT INTO conjunctions VALUES( conjunctions_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheASKS = toTheCon.prepareStatement(
            "INSERT INTO asks VALUES( asks_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoThePRONOUNS = toTheCon.prepareStatement(
            "INSERT INTO pronouns VALUES( pronouns_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheERS_IES_ALS = toTheCon.prepareStatement(
            "INSERT INTO ers_ies_als VALUES( ers_ies_als_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheIES = toTheCon.prepareStatement(
            "INSERT INTO ies VALUES( ies_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheITIES_ENCIES = toTheCon.prepareStatement(
            "INSERT INTO ities_encies VALUES( ities_encies_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheENCES_ANCES = toTheCon.prepareStatement(
            "INSERT INTO ences_ances VALUES( ences_ances_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheATES = toTheCon.prepareStatement(
            "INSERT INTO ates VALUES( ates_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheTIONS_SIONS_ALS = toTheCon.prepareStatement(
            "INSERT INTO tions_sions_als VALUES( tions_sions_als_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheISTS__ICS_ALS = toTheCon.prepareStatement(
            "INSERT INTO ists__ics_als VALUES( ists__ics_als_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheOTHER_ICS_ALS = toTheCon.prepareStatement(
            "INSERT INTO other_ics_als VALUES( other_ics_als_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheUMS_EMS = toTheCon.prepareStatement(
            "INSERT INTO ums_ems VALUES( ums_ems_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheINGS = toTheCon.prepareStatement(
            "INSERT INTO ings VALUES( ings_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheEDS = toTheCon.prepareStatement(
            "INSERT INTO eds VALUES( eds_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheSHIPS_HOODS = toTheCon.prepareStatement(
            "INSERT INTO ships_hoods VALUES( ships_hoods_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheNUMBERS = toTheCon.prepareStatement(
            "INSERT INTO numbers VALUES( numbers_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoThePROS_PRES = toTheCon.prepareStatement(
            "INSERT INTO pros_pres VALUES( pros_pres_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheOTHER_COS = toTheCon.prepareStatement(
            "INSERT INTO other_cos VALUES( other_cos_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheCONS_COMS = toTheCon.prepareStatement(
            "INSERT INTO cons_coms VALUES( cons_coms_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheLIES = toTheCon.prepareStatement(
            "INSERT INTO lies VALUES( lies_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheTIVES_SIVES = toTheCon.prepareStatement(
            "INSERT INTO tives_sives VALUES( tives_sives_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheIZES_ISES = toTheCon.prepareStatement(
            "INSERT INTO izes_ises VALUES( izes_ises_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheFIES = toTheCon.prepareStatement(
            "INSERT INTO fies VALUES( fies_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheVERBS = toTheCon.prepareStatement(
            "INSERT INTO verbs VALUES( verbs_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheOTHER_WORDS = toTheCon.prepareStatement(
            "INSERT INTO other_words VALUES( other_words_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheIES_AS_Y = toTheCon.prepareStatement(
            "INSERT INTO ies_as_y VALUES( ies_as_y_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheADVERBS = toTheCon.prepareStatement(
            "INSERT INTO adverbs VALUES( adverbs_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheSES = toTheCon.prepareStatement(
            "INSERT INTO ses VALUES( ses_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheESSES__NESSES = toTheCon.prepareStatement(
            "INSERT INTO esses__nesses VALUES( esses__nesses_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheDISES = toTheCon.prepareStatement(
            "INSERT INTO dises VALUES( dises_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheODD_VERBS = toTheCon.prepareStatement(
            "INSERT INTO odd_verbs VALUES( odd_verbs_seq.NEXTVAL, ? )");
        PreparedStatement toTheCommandForInsertIntoTheSHORT_VERBS = toTheCon.prepareStatement(
            "INSERT INTO short_verbs VALUES( short_verbs_seq.NEXTVAL, ? )");
        
        //PreparedStatement toTheCommandForInsertIntoTheIRREG_VERBS_23 = toTheCon.prepareStatement(
        //    "INSERT INTO irreg_verbs_23 VALUES( irreg_verbs_23_seq.NEXTVAL, ? )")
        
        PreparedStatement toTheCommandForSelectFromTheVERBS = toTheCon.prepareStatement(
            "SELECT word FROM verbs WHERE word = ?")//EXISTS (word)")
        
        )
    {
      PreparedStatement toTheCommandForInsert;
      
      Map< String, PreparedStatement > toTheCommands = new HashMap<>( 10, 1.0f );
      toTheCommands.put( "ments_als", toTheCommandForInsertIntoTheMENTS_ALS );
      toTheCommands.put( "ants_ents_als", toTheCommandForInsertIntoTheANTS_ENTS_ALS );
      toTheCommands.put( "udes_ures_als", toTheCommandForInsertIntoTheUDES_URES_ALS );
      toTheCommands.put( "ouses", toTheCommandForInsertIntoTheOUSES );
      //toTheCommands.put( "aoers_ies_als", toTheCommandForInsertIntoTheAOERS_IES_ALS );
      toTheCommands.put( "ars_ies_als", toTheCommandForInsertIntoTheARS_IES_ALS );
      toTheCommands.put( "ors_ies_als", toTheCommandForInsertIntoTheORS_IES_ALS );
      
      toTheCommands.put( "prepositions", toTheCommandForInsertIntoThePREPOSITIONS );
      toTheCommands.put( "conjunctions", toTheCommandForInsertIntoTheCONJUNCTIONS );
      toTheCommands.put( "asks", toTheCommandForInsertIntoTheASKS );
      toTheCommands.put( "pronouns", toTheCommandForInsertIntoThePRONOUNS );
      
      toTheCommands.put( "ers_ies_als", toTheCommandForInsertIntoTheERS_IES_ALS );
      toTheCommands.put( "ies", toTheCommandForInsertIntoTheIES );//! ?
      toTheCommands.put( "ities_encies", toTheCommandForInsertIntoTheITIES_ENCIES );
      toTheCommands.put( "ences_ances", toTheCommandForInsertIntoTheENCES_ANCES );//ENCES );
      toTheCommands.put( "ates", toTheCommandForInsertIntoTheATES );
      toTheCommands.put( "tions_sions_als", toTheCommandForInsertIntoTheTIONS_SIONS_ALS );
      toTheCommands.put( "ists__ics_als", toTheCommandForInsertIntoTheISTS__ICS_ALS );
      toTheCommands.put( "other_ics_als", toTheCommandForInsertIntoTheOTHER_ICS_ALS );
      toTheCommands.put( "ums_ems", toTheCommandForInsertIntoTheUMS_EMS );
      toTheCommands.put( "ings", toTheCommandForInsertIntoTheINGS );
      toTheCommands.put( "eds", toTheCommandForInsertIntoTheEDS );
      toTheCommands.put( "ships_hoods", toTheCommandForInsertIntoTheSHIPS_HOODS );
      toTheCommands.put( "numbers", toTheCommandForInsertIntoTheNUMBERS );
      
      toTheCommands.put( "pros_pres", toTheCommandForInsertIntoThePROS_PRES );
      toTheCommands.put( "other_cos", toTheCommandForInsertIntoTheOTHER_COS );
      toTheCommands.put( "cons_coms", toTheCommandForInsertIntoTheCONS_COMS );
      
      toTheCommands.put( "lies", toTheCommandForInsertIntoTheLIES );//forgottens
      toTheCommands.put( "tives_sives", toTheCommandForInsertIntoTheTIVES_SIVES );
      //w....able as a verb
      toTheCommands.put( "izes_ises", toTheCommandForInsertIntoTheIZES_ISES );
      toTheCommands.put( "fies", toTheCommandForInsertIntoTheFIES );
      toTheCommands.put( "verbs", toTheCommandForInsertIntoTheVERBS );
      toTheCommands.put( "other_words", toTheCommandForInsertIntoTheOTHER_WORDS );
      //toTheCommands.put( "irreg_verbs_23", toTheCommandForInsertIntoTheIRREG_VERBS_23 );//together
      toTheCommands.put( "ies_as_y", toTheCommandForInsertIntoTheIES_AS_Y );
      toTheCommands.put( "adverbs", toTheCommandForInsertIntoTheADVERBS );
      toTheCommands.put( "ses", toTheCommandForInsertIntoTheSES );
      toTheCommands.put( "esses__nesses", toTheCommandForInsertIntoTheESSES__NESSES );
      toTheCommands.put( "dises", toTheCommandForInsertIntoTheDISES );
      toTheCommands.put( "odd_verbs", toTheCommandForInsertIntoTheODD_VERBS );
      toTheCommands.put( "short_verbs", toTheCommandForInsertIntoTheSHORT_VERBS );
      
      //on the time
      final Set<String> toTheDones = new HashSet<>( 10, 1.0f );
      toTheDones.addAll( Arrays.asList(
          ""/*"ments_als", "ants_ents_als", "udes_ures_als", "ouses",
          "ars_ies_als", "ors_ies_als", "prepositions", "conjunctions",
          "asks", "pronouns", "ers_ies_als", 
          "ies", 
          "ities_encies", "ences_ances", "ates", "tions_sions_als",
          "ists__ics_als", "other_ics_als", "ums_ems", "ings", "eds",
          "ships_hoods", "numbers", "pros_pres", "cons_coms", "lies",
          "tives_sives", "other_cos", "izes_ises", "fies",
          "verbs", "other_words",// "irreg_verbs_23"
          "reg_600_irreg1_verbs",
          "ies_as_y", "adverbs", "ses", "esses__nesses", "dises",
          "odd_verbs", "short_verbs"
          */
      ) );
      
      //!!!
      final List<String> toThePrepositions = new ArrayList<>();//count then...--!!I need no:half-fixed...
      toThePrepositions.addAll( Arrays.asList(
          "of", "off", "from", "out", "outward", "outwards", "outside",// "out of",
          "to", "toward", "towards", "till", "untill", "inward", "inwards",// "inway",//-wise--method!
          "unto", "backward", "backwards",
          "at", "on", "onward", "onwards", "upon", "onto", "into", "in",
          "under", "inside", "within", "with",// "with no", 
          "without", "for", "fore",//afore, among...
          //https://www.native-english.ru/grammar/prepositions-list
          //across, along, against, amid, amidst, around, aside, athwart,
          //atop, next, ...ing, as far as...,...
          "by",
          "per", "pro", "fro", "since",
          "via",
          "than",
          "through", "thro", "thru", "throughout", "though",
          "near",// "nigh", --verb!as tie[taay]/tuy...
          "neath",
          //"wherewith", "therewith",
          "foreward", "forewards", "forward", "forwards", "yester",
          "inter", "after", "afterward", "afterwards",
          "up", "upward", "upwards",
          "over",
          "above", "about", "but", "beneath", "below", "before", "beside", "besides",// "infra"
          "because",//!iiz!// "because of",//even as an adverb...
          "behind", "belike", "between", "beyond",
          "as", "like", "so", "such",//!--!!sic=so
          "instead",//, "instead of"
          //cum=with,?=com,but ''speerma
          "away", "cum"
      ) );
      
      if( ! toTheDones.contains("prepositions") )
      {
        for( String in : toThePrepositions )
        {
          //System.out.println(in);
          toTheCommandForInsertIntoThePREPOSITIONS.setString( 1, in );
          toTheCommandForInsertIntoThePREPOSITIONS.executeUpdate();
          
        }
        
      }
      
      //PreparedStatement toTheCommandForOrderOntoThePREPOSITIONS = toTheCon.prepareStatement(
      //    "INSERT INTO prepositions VALUES( prepositions_seq.NEXTVAL, ? )");
      
      /*
      final Set<String> toTheOddAdverbs = new HashSet<>();//!and a join word
      toTheOddAdverbs.addAll( Arrays.asList(
          "here", "there", "then", "everywhere", "anywhere"//it is a verb
          //!rewrites, repeats
      ) );
      */
      
      //http://englishgu.ru/soyuzyi-v-angliyskom-yazyike-tablitsa-spisok/
      final List<String> toTheConjunctions = new ArrayList<>();//!and a join word
      toTheConjunctions.addAll( Arrays.asList(
          "and", "or", "nor", "either", "neither", "both",
          "if", "as", "because",// "because of", 
          "but",//!as...
          "however", "once", "hence",
          "otherwise", "still", "then", "that", "therefore",
          "although", "thus", "thereof", "unless",
          "while",//ungood
          "yet",
          "whereas",
          "moreover",
          "furthermore",
          "wherewith", "therewith"
      ) );
      
      if( ! toTheDones.contains("conjunctions") )
      {
        for( String in : toTheConjunctions )
        {
          toTheCommandForInsertIntoTheCONJUNCTIONS.setString( 1, in );
          toTheCommandForInsertIntoTheCONJUNCTIONS.executeUpdate();
          
        }
        
      }
      
      //http://study-english.info/vocabulary-questions.php
      final List<String> toTheAsks = new ArrayList<>(13);//!and a join word
      toTheAsks.addAll( Arrays.asList(
          "whether", "what", "how", "why", "who", "whom",
          "which", "whose", "when", "where", "where from",
          "how much", "how many"//, "whence"
      ) );
      
      if( ! toTheDones.contains("asks") )
      {
        for( String in : toTheAsks )
        {
          toTheCommandForInsertIntoTheASKS.setString( 1, in );
          toTheCommandForInsertIntoTheASKS.executeUpdate();
          
        }
        
      }
      
      //https://www.english-grammar-revolution.com/list-of-pronouns.html
      final List<String> toThePronouns = new ArrayList<>();//!and a join word
      toThePronouns.addAll( Arrays.asList(
          "one", "oneself", "I", "me", "my", "mine", "myself", "we", "us",
          "our", "ours", "ourselves", "you", "your", "yours",
          "yourself", "yourselves", "she", "her", "hers", "herself", "he", "his",
          "him", "himself", "it", "its", "itself",
          "they", "them", "their", "theirs", "themselves",
          "that", "which", "who", "whom", "whose", "whichever",
          "whoever", "whomever", "this", "these", "those",
          "anybody", "anyone", "anything", "each", "either", "everybody",
          "everyone", "everything", "neither", "nobody", "nothing",
          "somebody", "someone", "something", "both", "few", "many", "several",
          "all", "any", "most", "none", "some",
          "thou", "thy"
      ) );
      
      if( ! toTheDones.contains("pronouns") )
      {
        for( String in : toThePronouns )
        {
          //System.out.println(in);
          toTheCommandForInsertIntoThePRONOUNS.setString( 1, in );
          toTheCommandForInsertIntoThePRONOUNS.executeUpdate();
          
        }
        
      }
      
      final List<String> toTheNumbers = new ArrayList<>();//!and a join word
      toTheNumbers.addAll( Arrays.asList(
          "null", "zero", "nought",
          "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve",
          "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen",
          "twenty", "thirty", "forty", "fourty", "fifty", "sixty", "seventy", "eighty", "ninety",
          "hundred", "thousand", "million", "milliard", "billion",
          "zeroth",
          "first", "second", "third",
          "fourth", "fifth", "sixth", "seventh", "eighth", "ninth", "tenth", "eleventh", "twelfth",
          "thirteenth", "fourteenth", "fifteenth", "sixteenth", "seventeenth", "eighteenth", "nineteenth",
          "twentieth", "thirtieth", "fortieth", "fiftieth", "sixtieth", "seventieth", "eightieth", "ninetieth",
          "hundredth", "thousandth", "millionth", "milliardth", "billionth"
      ) );
      
      if( ! toTheDones.contains("numbers") )
      {
        for( String in : toTheNumbers )
        {
          toTheCommandForInsertIntoTheNUMBERS.setString( 1, in );
          toTheCommandForInsertIntoTheNUMBERS.executeUpdate();
          
        }
        
      }
      
      final List<String> toTheOddVerbs = new ArrayList<>();//!and a join word
      toTheOddVerbs.addAll( Arrays.asList(
          "do", "does", "am", "is", "are"
      ) );
      
      if( ! toTheDones.contains("odd_verbs") )
      {
        for( String in : toTheOddVerbs )
        {
          toTheCommandForInsertIntoTheODD_VERBS.setString( 1, in );
          toTheCommandForInsertIntoTheODD_VERBS.executeUpdate();
          
        }
        
      }
      
      
      
      //https://www.englishclub.com/vocabulary/irregular-verbs-list.htm
      //https://www.englishclub.com/vocabulary/regular-verbs-list.htm --!the regular verbs
      final List<String> toTheIrregularVerbs23 = new ArrayList<>();
      final List<String> toTheRegularVerbsAndIrregular1Verbs = new ArrayList<>();
      try( Scanner r = new Scanner( new BufferedReader( new FileReader(
          "D:\\rb\\nynw\\myProjects\\forMakeTheFirst/irregularVerbs.txt") ) );
          Scanner rr = new Scanner( new BufferedReader( new FileReader(
              "D:\\rb\\nynw\\myProjects\\forMakeTheFirst/regular600Verbs.txt") ) ) )
      {
        String s;
        while( r.hasNext() )
        {
          //s = r.next();
          //if( ! toTheRegularVerbsAndIrregular1Verbs.contains(s) )
          //{
          toTheRegularVerbsAndIrregular1Verbs.add( r.next() );
          //}
          
          s = r.next();
          toTheIrregularVerbs23.add(s);
          
          if( s.equals("was") || s.equals("clove") )//!or here on the double/repeat/same--!here!
          {
            toTheIrregularVerbs23.add( r.next() );
          }
          
          s = r.next();
          toTheIrregularVerbs23.add(s);
          
          if( s.equals("cloven") || s.equals("shrunk") )//!
          {
            toTheIrregularVerbs23.add( r.next() );
          }
          
        }
        
        while( rr.hasNext() )
        {
          toTheRegularVerbsAndIrregular1Verbs.add( rr.next() );
        }
        
      }
      catch( IOException ex )
      {
        ex.printStackTrace();
      }
      //System.out.println(toTheIrregularVerbs23);
      //System.out.println( toTheIrregularVerbs23.size() );
      //System.out.println(toTheRegularVerbsAndIrregular1Verbs);
      //System.out.println( toTheRegularVerbsAndIrregular1Verbs.size() );
      /*
      if( ! toTheDones.contains("irreg_verbs_23") )
      {
        for( String in : toTheIrregularVerbs23 )
        {
          //System.out.println(in);
          toTheCommandForInsertIntoTheIRREG_VERBS_23.setString( 1, in );
          toTheCommandForInsertIntoTheIRREG_VERBS_23.executeUpdate();
          
        }
        
      }
      */
      
      
      
      String toTheNameOfTheTable;
      
      //boolean whetherDidTheWordOfQuackeryBe = false,
      //    whetherDidTheWordOfQuacksalverBe = false;//!I simply unwrite those extra words away from the myDictionary.txt!
      /*
30845) qua
30846) quack
30847) quack-quack
30848) quackery
30849) quackle
30850) quacksalver
30851) quad
30852) quadragenarian
      */
      
      String toTheWord;
      int at = 1;
      while( toTheScan.hasNext() )
      {
        toTheNameOfTheTable = null;
        
        toTheScan.next();
        toTheWord = toTheScan.next();
        
        //whetherDidTheWordOfQuackeryBe = toTheWord.equals("quackery");
        
        toTheNameOfTheTable = toThePronouns.contains(toTheWord)//-5
            //|| toTheWord.endsWith("body") || toTheWord.endsWith("one")
            || toTheWord.endsWith("self") || toTheWord.endsWith("selves")
            //|| toTheWord.endsWith("ever")// || toTheWord.endsWith("thing") 
            ? "pronouns"//with no use
        : toTheNumbers.contains(toTheWord) ? "numbers"//-4
        : toThePrepositions.contains(toTheWord) ? "prepositions"//-3
        : toTheAsks.contains(toTheWord) ? "asks"//-2
        //: toTheWord.startsWith("some") ? "odd_adverbs"
        : toTheIrregularVerbs23.contains(toTheWord)
            && ! ( toTheWord.equals("come") || toTheWord.equals("beat")
                || toTheWord.equals("become") || toTheWord.equals("bet")
                || toTheWord.equals("broadcast") || toTheWord.equals("cost")
                || toTheWord.equals("cut") || toTheWord.equals("hit")
                || toTheWord.equals("hurt") || toTheWord.equals("let")
                || toTheWord.equals("put") || toTheWord.equals("read")
                || toTheWord.equals("run") || toTheWord.equals("shut") ) ? "irreg_verbs_23"
        : toTheConjunctions.contains(toTheWord) ? "conjunctions"//-1
        : toTheWord.endsWith("ment") || toTheWord.endsWith("mental") ?//1
            "ments_als"
        : ( toTheWord.endsWith("ent") || toTheWord.endsWith("ant") //2
            || toTheWord.endsWith("ental") || toTheWord.endsWith("antal") )
            && ! ( toTheWord.equals("went") || toTheWord.endsWith("-went")
            || toTheWord.equals("meant") || toTheWord.endsWith("-meant")
            || toTheWord.equals("spent") || toTheWord.endsWith("-spent")
            || toTheWord.equals("ant") || toTheWord.endsWith("-ant")
            || toTheWord.equals("tent") || toTheWord.endsWith("-tent")
            || toTheWord.equals("bent") || toTheWord.endsWith("-bent")
            || toTheWord.equals("lent") || toTheWord.endsWith("-lent")
            || toTheWord.equals("pant") || toTheWord.endsWith("-pant")
            || toTheWord.equals("pent") || toTheWord.endsWith("-pent")
            || toTheWord.equals("rent") || toTheWord.endsWith("-rent")
            || toTheWord.equals("sent") || toTheWord.endsWith("-sent")
            || toTheWord.equals("vent") || toTheWord.endsWith("-vent")
            || toTheWord.equals("want") || toTheWord.endsWith("-want")
            || toTheWord.equals("plant") || toTheWord.endsWith("-plant") ) ? "ants_ents_als"
        : ( toTheWord.endsWith("ude") || toTheWord.endsWith("ure") //3
            || toTheWord.endsWith("udal") || toTheWord.endsWith("ural") )
            && ! ( toTheWord.equals("cure") || toTheWord.endsWith("-cure")
                || toTheWord.equals("sure") || toTheWord.endsWith("-sure")
                || toTheWord.equals("dure") || toTheWord.endsWith("-dure")//! ?
                || toTheWord.equals("future") || toTheWord.endsWith("-future")
                || toTheWord.equals("lure") || toTheWord.endsWith("-lure") ) ? "udes_ures_als"
        : toTheWord.endsWith("ous") ? "ouses"//4
        /*
        : ( toTheWord.endsWith("ar") || toTheWord.endsWith("or") || toTheWord.endsWith("er")//5
            || toTheWord.endsWith("ary") || toTheWord.endsWith("ory") || toTheWord.endsWith("ery")
            || toTheWord.endsWith("aral") || toTheWord.endsWith("oral") || toTheWord.endsWith("eral") )
            //&& ! whetherDidTheWordOfQuackeryBe 
            && ! ( toTheWord.equals("year") || toTheWord.endsWith("-year")
                || toTheWord.equals("water") || toTheWord.endsWith("-water")
                || toTheWord.equals("wear") || toTheWord.endsWith("-wear")
                || toTheWord.equals("weary") || toTheWord.endsWith("-weary")
                || toTheWord.equals("tear") || toTheWord.endsWith("-tear")
                || toTheWord.equals("bear") || toTheWord.endsWith("-bear")
                || toTheWord.equals("gear") || toTheWord.endsWith("-gear")
                || toTheWord.equals("power") || toTheWord.endsWith("-power")
                || toTheWord.equals("powder") || toTheWord.endsWith("-powder")
                //|| toTheWord.equals("either") || toTheWord.endsWith("-either")
                //|| toTheWord.equals("neither") || toTheWord.endsWith("-neither")
                //|| toTheWord.equals("whether") || toTheWord.endsWith("-whether")//for,ever,every,never,over,her,there,where...-upper
                || toTheWord.equals("powder") || toTheWord.endsWith("-powder") ) ? "aoers_ies_als"
        */
        : ( toTheWord.endsWith("ar") || toTheWord.endsWith("ary")//5
            || toTheWord.endsWith("aral") )
            && ! ( toTheWord.equals("year") || toTheWord.endsWith("-year")
                || toTheWord.equals("wear") || toTheWord.endsWith("-wear")
                || toTheWord.equals("weary") || toTheWord.endsWith("-weary")
                || toTheWord.equals("tear") || toTheWord.endsWith("-tear")
                || toTheWord.equals("bear") || toTheWord.endsWith("-bear")
                || toTheWord.equals("gear") || toTheWord.endsWith("-gear")
                || toTheWord.equals("war") || toTheWord.endsWith("-war")
                || toTheWord.equals("wary") || toTheWord.endsWith("-wary")
                || toTheWord.equals("clear") || toTheWord.endsWith("-cleary")
                || toTheWord.equals("car")
                || toTheWord.equals("temper")
                || toTheWord.equals("swear")
                || toTheWord.equals("star")
                || toTheWord.equals("scar")
                || toTheWord.equals("scary")
                || toTheWord.equals("pear")
                //|| toTheWord.equals("near")
                || toTheWord.equals("hear")
                || toTheWord.equals("far")
                || toTheWord.equals("ear")
                || toTheWord.equals("appear") ) ? "ars_ies_als"
        : ( toTheWord.endsWith("or") || toTheWord.endsWith("ory")//6
            || toTheWord.endsWith("oral") )//for,or,nor
            && ! ( toTheWord.equals("glory") || toTheWord.endsWith("-glory")
                || toTheWord.equals("glory") || toTheWord.endsWith("-glory")
                || toTheWord.equals("door") || toTheWord.endsWith("-door")
                || toTheWord.equals("floor") || toTheWord.endsWith("-floor")
                || toTheWord.equals("floor") || toTheWord.endsWith("-floor")
            ) ? "ors_ies_als"
        : ( toTheWord.endsWith("er") || toTheWord.endsWith("ery")//7
            || toTheWord.endsWith("eral") )
            && ! ( toTheWord.equals("clever") || toTheWord.endsWith("-clever")
                || toTheWord.equals("upper") || toTheWord.endsWith("-upper")
                || toTheWord.equals("inner") || toTheWord.endsWith("-inner")
                || toTheWord.equals("outer") || toTheWord.endsWith("-outer")
                || toTheWord.equals("anger") || toTheWord.endsWith("-anger")
                || toTheWord.equals("answer") || toTheWord.endsWith("-answer")
                || toTheWord.equals("powder") || toTheWord.endsWith("-powder")
                || toTheWord.equals("power") || toTheWord.endsWith("-power")
                || toTheWord.equals("paper") || toTheWord.endsWith("-paper")
                || toTheWord.equals("matter") || toTheWord.endsWith("-matter")
                || toTheWord.equals("mother") || toTheWord.endsWith("-mother")
                || toTheWord.equals("father") || toTheWord.endsWith("-father")
                || toTheWord.equals("sister") || toTheWord.endsWith("-sister")
                || toTheWord.equals("brother") || toTheWord.endsWith("-brother")
                || toTheWord.equals("confer") || toTheWord.endsWith("-confer")
                || toTheWord.equals("refer") || toTheWord.endsWith("-refer")
                || toTheWord.equals("differ") || toTheWord.endsWith("-differ")
                || toTheWord.equals("defer") || toTheWord.endsWith("-defer")
                || toTheWord.equals("offer") || toTheWord.endsWith("-offer")
                || toTheWord.equals("eery") || toTheWord.endsWith("-eery")
                || toTheWord.equals("cover") || toTheWord.endsWith("-cover")
                || toTheWord.equals("hover") || toTheWord.endsWith("-hover")
                || toTheWord.equals("ever") || toTheWord.endsWith("-ever")//! ?
                || toTheWord.equals("every") || toTheWord.endsWith("-every")
                || toTheWord.equals("water") || toTheWord.endsWith("-water")
                || toTheWord.equals("order") || toTheWord.endsWith("-order")
                || toTheWord.equals("queer") || toTheWord.endsWith("-queer")
                || toTheWord.equals("query") || toTheWord.endsWith("-query")
                || toTheWord.equals("render") || toTheWord.endsWith("-render")
                || toTheWord.equals("very") || toTheWord.endsWith("-very")
                || toTheWord.equals("buffer") || toTheWord.endsWith("-buffer")
                || toTheWord.equals("wonder") || toTheWord.endsWith("-wonder") ) ? "ers_ies_als"
        : ( toTheWord.endsWith("ity") || toTheWord.endsWith("ency") )//9
            && ! ( toTheWord.equals("city") || toTheWord.endsWith("-city")
                || toTheWord.equals("pity") || toTheWord.endsWith("-pity") ) ? "ities_encies"
        : ( toTheWord.endsWith("ence") || toTheWord.endsWith("ance") )//10
            && ! ( toTheWord.equals("science") || toTheWord.endsWith("-science")
                || toTheWord.equals("dance") || toTheWord.endsWith("-dance") ) ? "ences_ances"
        : toTheWord.endsWith("ate")//11
            && ! ( toTheWord.equals("ate") || toTheWord.endsWith("-ate")
                || toTheWord.equals("rate") || toTheWord.endsWith("-rate")
                || toTheWord.equals("date") || toTheWord.endsWith("-date")
                || toTheWord.equals("fate") || toTheWord.endsWith("-fate")
                || toTheWord.equals("gate") || toTheWord.endsWith("-gate")
                || toTheWord.equals("hate") || toTheWord.endsWith("-hate")
                || toTheWord.equals("plate") || toTheWord.endsWith("-plate")
                || toTheWord.equals("late") || toTheWord.endsWith("-late")
                || toTheWord.equals("state") || toTheWord.endsWith("-state")
                || toTheWord.equals("sate") || toTheWord.endsWith("-sate") ) ? "ates"
        : toTheWord.endsWith("tion") || toTheWord.endsWith("tional")//12
            || toTheWord.endsWith("sion") || toTheWord.endsWith("sional") ? "tions_sions_als"
        : ( toTheWord.endsWith("ist") || toTheWord.endsWith("istal")//12
            || toTheWord.endsWith("istic") || toTheWord.endsWith("istical") )
            && ! ( toTheWord.equals("fist") || toTheWord.endsWith("-fist")
                || toTheWord.equals("list") || toTheWord.endsWith("-list")
                || toTheWord.equals("twist") || toTheWord.endsWith("-twist")
                || toTheWord.equals("waist") || toTheWord.endsWith("-waist")
                || toTheWord.equals("whist") || toTheWord.endsWith("-whist")
                || toTheWord.equals("sate") || toTheWord.endsWith("-sate") ) ? "ists__ics_als"
        : ( toTheWord.endsWith("ic") || toTheWord.endsWith("al") )//13
            && ! ( toTheWord.equals("coal") || toTheWord.endsWith("-coal")
                || toTheWord.equals("goal") || toTheWord.endsWith("-goal")
                || toTheWord.equals("equal") || toTheWord.endsWith("-equal")
                || toTheWord.equals("usual") || toTheWord.endsWith("-usual")
                || toTheWord.equals("heal") || toTheWord.endsWith("-heal")
                || toTheWord.equals("deal") || toTheWord.endsWith("-deal")
                || toTheWord.equals("leal") || toTheWord.endsWith("-leal")//[iial]
                || toTheWord.equals("meal") || toTheWord.endsWith("-meal")
                || toTheWord.equals("metal") || toTheWord.endsWith("-metal")
                || toTheWord.equals("peal") || toTheWord.endsWith("-peal")
                || toTheWord.equals("real") || toTheWord.endsWith("-real")
                || toTheWord.equals("seal") || toTheWord.endsWith("-seal")
                || toTheWord.equals("skoal") || toTheWord.endsWith("-skoal")
                || toTheWord.equals("steal") || toTheWord.endsWith("-steal")
                || toTheWord.equals("weal") || toTheWord.endsWith("-weal")
                || toTheWord.equals("anneal") || toTheWord.endsWith("-anneal") ) ? "other_ics_als"
        : ( toTheWord.endsWith("um") || toTheWord.endsWith("em") )//14
            && ! ( toTheWord.equals("drum") || toTheWord.endsWith("-drum")
                || toTheWord.equals("hem") || toTheWord.endsWith("-hem")
                //|| toTheWord.equals("idem") || toTheWord.endsWith("-idem")//!
                || toTheWord.equals("plum") || toTheWord.endsWith("-plum")
                || toTheWord.equals("seem") || toTheWord.endsWith("-seem")
                || toTheWord.equals("stem") || toTheWord.endsWith("-stem")//!
                || toTheWord.equals("teem") || toTheWord.endsWith("-teem") ) ? "ums_ems"
        : toTheWord.endsWith("ing")//15
            && ! ( toTheWord.equals("thing") || toTheWord.endsWith("-thing")
                || toTheWord.equals("sting") || toTheWord.endsWith("-sting")//'' zxaazxda,booli--!!zh->zx
                || toTheWord.equals("ring") || toTheWord.endsWith("-ring")//loop,whirl,roll
                || toTheWord.equals("sing") || toTheWord.endsWith("-sing")
                || toTheWord.equals("spring") || toTheWord.endsWith("-spring")
                || toTheWord.equals("sing") || toTheWord.endsWith("-sing") ) ? "ings"
        : toTheWord.endsWith("ed")//16
            && ! ( toTheWord.equals("deed") || toTheWord.endsWith("-deed")
                || toTheWord.equals("speed") || toTheWord.endsWith("-speed")//td push/pull
                || toTheWord.equals("bed") || toTheWord.endsWith("-bed")
                || toTheWord.equals("bleed") || toTheWord.endsWith("-bleed")
                || toTheWord.equals("feed") || toTheWord.endsWith("-feed")
                || toTheWord.equals("heed") || toTheWord.endsWith("-heed")
                || toTheWord.equals("meed") || toTheWord.endsWith("-meed")//''mjod!goal to itch/thirst/urge/need/prod
                || toTheWord.equals("need") || toTheWord.endsWith("-need")
                || toTheWord.equals("red") || toTheWord.endsWith("-red")
                || toTheWord.equals("seed") || toTheWord.endsWith("-seed")
                || toTheWord.equals("creed") || toTheWord.endsWith("-creed")
                || toTheWord.equals("greed") || toTheWord.endsWith("-greed") ) ? "eds"//''rjeevnosti?
        : ( toTheWord.endsWith("ship") || toTheWord.endsWith("hood") )//17
            && ! ( toTheWord.equals("ship") || toTheWord.endsWith("-ship")//shape,set?--!ser:
                || toTheWord.equals("hood") || toTheWord.endsWith("-hood") ) ? "ships_hoods"
                    //w.hood as -ude,-ity, -ency, the part with this root deed!..selfhood,kinship,kingship
        : toTheWord.endsWith("ly")//17-1
            && ! ( toTheWord.equals("fly") || toTheWord.endsWith("-fly")
                || toTheWord.equals("reply") || toTheWord.endsWith("-reply")
                //|| toTheWord.equals("ably") || toTheWord.endsWith("-ably")
                || toTheWord.equals("ally") || toTheWord.endsWith("-ally")
                || toTheWord.equals("apply") || toTheWord.endsWith("-apply")
                || toTheWord.equals("belly") || toTheWord.endsWith("-belly")
                || toTheWord.equals("imply") || toTheWord.endsWith("-imply")
                || toTheWord.equals("rely") || toTheWord.endsWith("-rely")
                || toTheWord.equals("supply") || toTheWord.endsWith("-supply")
                //with the adjectives
                ) ? "lies"
        : toTheWord.endsWith("tive") || toTheWord.endsWith("sive") ? "tives_sives"//17-2
        : ( toTheWord.endsWith("ize") || toTheWord.endsWith("ise") )//17-3
            && ! ( toTheWord.equals("wise") || toTheWord.endsWith("-wise")//!
                || toTheWord.equals("advise") || toTheWord.endsWith("-advise")
                || toTheWord.equals("arise") || toTheWord.endsWith("-arise")
                || toTheWord.equals("comprise") || toTheWord.endsWith("-comprise")
                //|| toTheWord.endsWith("concise")
                //|| toTheWord.endsWith("device")//d-v-s
                || toTheWord.equals("noise") || toTheWord.endsWith("-noise")
                || toTheWord.equals("poise") || toTheWord.endsWith("-poise")
                || toTheWord.equals("praise") || toTheWord.endsWith("-praise")
                || toTheWord.equals("raise") || toTheWord.endsWith("-raise")
                || toTheWord.equals("size") || toTheWord.endsWith("-size")
                || toTheWord.equals("vise") || toTheWord.endsWith("-vise")
                || toTheWord.equals("poise") || toTheWord.endsWith("-poise") ) ? "izes_ises"
        : toTheWord.endsWith("fy")//17-4
            && ! ( toTheWord.equals("beefy") || toTheWord.endsWith("-beefy")
                || toTheWord.equals("bluffy") || toTheWord.endsWith("-bluffy")
                || toTheWord.equals("chaffy") || toTheWord.endsWith("-chaffy")
                || toTheWord.equals("comfy") || toTheWord.endsWith("-comfy")
                || toTheWord.equals("daffy") || toTheWord.endsWith("-daffy")
                
                || toTheWord.equals("edify") || toTheWord.endsWith("-edify")
                || toTheWord.equals("defy") || toTheWord.endsWith("-defy")
                
                || toTheWord.equals("goofy") || toTheWord.endsWith("-goofy")
                || toTheWord.equals("huffy") || toTheWord.endsWith("-huffy")
                
                || toTheWord.equals("iffy") || toTheWord.endsWith("-iffy")//random,if+-y...as inly
                
                || toTheWord.equals("leafy") || toTheWord.endsWith("-leafy")
                || toTheWord.equals("puffy") || toTheWord.endsWith("-puffy")
                || toTheWord.equals("reefy") || toTheWord.endsWith("-reefy")
                || toTheWord.equals("sniffy") || toTheWord.endsWith("-sniffy")
                || toTheWord.equals("snuffy") || toTheWord.endsWith("-snuffy")
                || toTheWord.equals("stuffy") || toTheWord.endsWith("-stuffy")
                || toTheWord.equals("taffy") || toTheWord.endsWith("-taffy")
                || toTheWord.equals("toffy") || toTheWord.endsWith("-toffy")
                || toTheWord.equals("turfy") || toTheWord.endsWith("-turfy")
                || toTheWord.equals("whiffy") || toTheWord.endsWith("-whiffy")
                //...
                ) ? "fies"
        : toTheWord.endsWith("y")//8--after the -y others--!!yes
            && ! ( toTheWord.equals("fly") || toTheWord.endsWith("-fly")
                || toTheWord.equals("reply") || toTheWord.endsWith("-reply")
                || toTheWord.equals("ally") || toTheWord.endsWith("-ally")
                || toTheWord.equals("apply") || toTheWord.endsWith("-apply")
                || toTheWord.equals("belly") || toTheWord.endsWith("-belly")
                || toTheWord.equals("imply") || toTheWord.endsWith("-imply")
                || toTheWord.equals("rely") || toTheWord.endsWith("-rely")
                || toTheWord.equals("supply") || toTheWord.endsWith("-supply")//of the lies
                || toTheWord.equals("way") || toTheWord.endsWith("-way")
                || toTheWord.equals("body") || toTheWord.endsWith("-body")//!
                || toTheWord.equals("carry") || toTheWord.endsWith("-carry")
                || toTheWord.equals("city") || toTheWord.endsWith("-city")
                || toTheWord.equals("cloy") || toTheWord.endsWith("-cloy")
                || toTheWord.equals("day") || toTheWord.endsWith("-day")
                || toTheWord.equals("decay") || toTheWord.endsWith("-decay")
                || toTheWord.equals("defy") || toTheWord.endsWith("-defy")
                || toTheWord.equals("delay") || toTheWord.endsWith("-delay")
                || toTheWord.equals("deny") || toTheWord.endsWith("-deny")//unnigh
                || toTheWord.equals("enjoy") || toTheWord.endsWith("-enjoy")
                || toTheWord.equals("fray") || toTheWord.endsWith("-fray")
                || toTheWord.equals("joy") || toTheWord.endsWith("-joy")
                || toTheWord.equals("key") || toTheWord.endsWith("-key")
                || toTheWord.equals("lay") || toTheWord.endsWith("-lay")
                || toTheWord.equals("may") || toTheWord.endsWith("-may")
                || toTheWord.equals("money") || toTheWord.endsWith("-money")
                || toTheWord.equals("nay") || toTheWord.endsWith("-nay")
                || toTheWord.equals("pay") || toTheWord.endsWith("-pay")
                || toTheWord.equals("play") || toTheWord.endsWith("-play")
                || toTheWord.equals("prey") || toTheWord.endsWith("-prey")
                //|| toTheWord.equals("relay") || toTheWord.endsWith("-relay")//re-...and -fy...
                || toTheWord.equals("say") || toTheWord.endsWith("-say")
                || toTheWord.equals("shy") || toTheWord.endsWith("-shy")
                || toTheWord.equals("stay") || toTheWord.endsWith("-stay")
                || toTheWord.equals("sway") || toTheWord.endsWith("-sway")
                //...
            ) ? "ies"
        : toTheWord.endsWith("ie")//17-5
            && ! ( toTheWord.equals("die") || toTheWord.endsWith("-die")
                || toTheWord.equals("fie") || toTheWord.endsWith("-fie")
                || toTheWord.equals("hie") || toTheWord.endsWith("-hie")
                || toTheWord.equals("lie") || toTheWord.endsWith("-lie")//l-y,launch
                || toTheWord.equals("pie") || toTheWord.endsWith("-pie")
                || toTheWord.equals("tie") || toTheWord.endsWith("-tie")
                || toTheWord.equals("vie") || toTheWord.endsWith("-vie") ) ? "ies_as_y"
        : toTheWord.endsWith("ess")// || toTheWord.endsWith("ness") )//17-6
            && ! ( toTheWord.equals("press") || toTheWord.endsWith("-press")
                || toTheWord.equals("access") || toTheWord.endsWith("-access")
                || toTheWord.equals("address") || toTheWord.endsWith("-address")
                || toTheWord.equals("bless") || toTheWord.endsWith("-bless")
                || toTheWord.equals("chess") || toTheWord.endsWith("-chess")//frame
                || toTheWord.equals("confess") || toTheWord.endsWith("-confess")
                || toTheWord.equals("dress") || toTheWord.endsWith("-dress")//adopt
                || toTheWord.equals("guess") || toTheWord.endsWith("-guess")
                || toTheWord.equals("mess") || toTheWord.endsWith("-mess")
                || toTheWord.equals("jess") || toTheWord.endsWith("-jess")
                || toTheWord.endsWith("less") || toTheWord.endsWith("-less")//!--!!
                || toTheWord.equals("caress") || toTheWord.endsWith("-caress")
                || toTheWord.equals("impress") || toTheWord.endsWith("-impress")
                || toTheWord.equals("ingress") || toTheWord.endsWith("-ingress")//egress
                || toTheWord.equals("obsess") || toTheWord.endsWith("-obsess")
                || toTheWord.equals("stress") || toTheWord.endsWith("-stress")
                ) ? "esses__nesses"
        : toTheWord.endsWith("s")//17-6
            && ! ( toTheWord.equals("is") || toTheWord.endsWith("-is")
                || toTheWord.equals("bus") || toTheWord.endsWith("-bus")
                //upper:
                || toTheWord.equals("press") || toTheWord.endsWith("-press")
                || toTheWord.equals("access") || toTheWord.endsWith("-access")
                || toTheWord.equals("address") || toTheWord.endsWith("-address")
                || toTheWord.equals("bless") || toTheWord.endsWith("-bless")
                || toTheWord.equals("chess") || toTheWord.endsWith("-chess")//frame
                || toTheWord.equals("confess") || toTheWord.endsWith("-confess")
                || toTheWord.equals("dress") || toTheWord.endsWith("-dress")//adopt
                || toTheWord.equals("guess") || toTheWord.endsWith("-guess")
                || toTheWord.equals("mess") || toTheWord.endsWith("-mess")
                || toTheWord.equals("jess") || toTheWord.endsWith("-jess")
                || toTheWord.endsWith("less") || toTheWord.endsWith("-less")//!--!!
                || toTheWord.equals("caress") || toTheWord.endsWith("-caress")
                || toTheWord.equals("impress") || toTheWord.endsWith("-impress")
                || toTheWord.equals("ingress") || toTheWord.endsWith("-ingress")//egress
                || toTheWord.equals("obsess") || toTheWord.endsWith("-obsess")
                || toTheWord.equals("stress") || toTheWord.endsWith("-stress")
                
                || toTheWord.startsWith("across")
                || toTheWord.startsWith("always")
                
                || toTheWord.equals("alias") || toTheWord.endsWith("-alias")
                || toTheWord.equals("bliss") || toTheWord.endsWith("-bliss")//joy
                || toTheWord.equals("class") || toTheWord.endsWith("-class")
                || toTheWord.equals("focus") || toTheWord.endsWith("-focus")
                || toTheWord.equals("compass") || toTheWord.endsWith("-compass")
                || toTheWord.equals("cross") || toTheWord.endsWith("-cross")
                || toTheWord.equals("doss") || toTheWord.endsWith("-doss")
                || toTheWord.equals("joss") || toTheWord.endsWith("-joss")
                || toTheWord.equals("jus") || toTheWord.endsWith("-jus")//z(x)k
                || toTheWord.equals("kiss") || toTheWord.endsWith("-kiss")
                || toTheWord.equals("loss") || toTheWord.endsWith("-loss")
                || toTheWord.equals("mass") || toTheWord.endsWith("-mass")
                || toTheWord.equals("miss") || toTheWord.endsWith("-miss")
                || toTheWord.equals("muss") || toTheWord.endsWith("-muss")
                //...
                || toTheWord.equals("pass") || toTheWord.endsWith("-pass")
                //|| toTheWord.equals("yes") || toTheWord.endsWith("-yes")
                ) ? "ses"
        
        : ( toTheWord.startsWith("pro") || toTheWord.startsWith("pre") )//18
            && ! ( toTheWord.equals("proud") || toTheWord.startsWith("proud-")//!!and to an up I can only use the endsWith(<word>)--!!no
                || toTheWord.equals("prop") || toTheWord.startsWith("prop-")
                || toTheWord.equals("proof") || toTheWord.startsWith("proof-")
                || toTheWord.equals("prove") || toTheWord.startsWith("prove-")
                || toTheWord.equals("prone") || toTheWord.startsWith("prone-")
                || toTheWord.equals("prog") || toTheWord.startsWith("prog-")
                || toTheWord.equals("prod") || toTheWord.startsWith("prod-")
                || toTheWord.equals("prey") || toTheWord.startsWith("prey-")
                || toTheWord.equals("pretty") || toTheWord.startsWith("pretty-")
                || toTheWord.equals("press") || toTheWord.startsWith("press-") ) ? "pros_pres"
        : ( toTheWord.startsWith("con") || toTheWord.startsWith("com") )//19
            && ! ( toTheWord.equals("come") || toTheWord.startsWith("come-")// || toTheWord.endsWith("-come")//there are come-...
                //|| toTheWord.equals("comely") || toTheWord.endsWith("-comely")
                || toTheWord.equals("command") || toTheWord.startsWith("command-")
                || toTheWord.equals("commit") || toTheWord.startsWith("commit-")
                || toTheWord.equals("common") || toTheWord.startsWith("common-")//''obskepriinjat(_)hiy(! !?-ed,-''-vvodjajaskiy)--hi=myOld.y
                || toTheWord.equals("compact") || toTheWord.startsWith("compact-")
                || toTheWord.equals("compare") || toTheWord.startsWith("compare-")
                || toTheWord.equals("compass") || toTheWord.startsWith("compass-")
                || toTheWord.equals("compel") || toTheWord.startsWith("compel-")
                || toTheWord.equals("compile") || toTheWord.startsWith("compile-")
                //|| toTheWord.startsWith("complete") || toTheWord.endsWith("-complete")
                || toTheWord.equals("comply") || toTheWord.startsWith("comply-")
                || toTheWord.equals("con") || toTheWord.startsWith("con-")
                || toTheWord.equals("conduct") || toTheWord.startsWith("conduct-")//behave
                || toTheWord.equals("cone") || toTheWord.startsWith("cone-")
                || toTheWord.equals("confer") || toTheWord.startsWith("confer-")
                || toTheWord.equals("confess") || toTheWord.startsWith("confess-")
                || toTheWord.equals("confine") || toTheWord.startsWith("confine-")
                || toTheWord.equals("confront") || toTheWord.startsWith("confront-")
                || toTheWord.equals("confuse") || toTheWord.startsWith("confuse-")
                || toTheWord.equals("connect") || toTheWord.startsWith("connect-")
                || toTheWord.equals("connote") || toTheWord.startsWith("connote-")
                 || toTheWord.equals("control") || toTheWord.startsWith("control-")//pull at, govern, lead, head...
                //...
                ) ? "cons_coms"
        : toTheWord.startsWith("co-") || toTheWord.startsWith("coo")//20
            && ! ( toTheWord.equals("cook") || toTheWord.startsWith("cook-")// || toTheWord.endsWith("-cook") || toTheWord.endsWith("cook-")
                || toTheWord.equals("cool") || toTheWord.startsWith("cool-") ) ? "other_cos"
        : toTheWord.startsWith("afore")//21
            || toTheWord.startsWith("after")
            || toTheWord.startsWith("always")
            || toTheWord.startsWith("never")
            || toTheWord.startsWith("often")
            || toTheWord.startsWith("almost")
            //|| toTheWord.startsWith("even")//...seldom, less, upward, well=will...
            || toTheWord.startsWith("aft")
            || toTheWord.startsWith("very")
            || toTheWord.startsWith("too")
            || toTheWord.startsWith("more")
            
            || toTheWord.startsWith("aboard")
            || toTheWord.startsWith("afoot")
            || toTheWord.startsWith("oft")
            || toTheWord.startsWith("again")
            || toTheWord.startsWith("ago")
            || toTheWord.startsWith("alive")
            || toTheWord.startsWith("along")
            || toTheWord.startsWith("also")
            || toTheWord.startsWith("among")
            || toTheWord.startsWith("amongst")
            || toTheWord.startsWith("anew")
            || toTheWord.startsWith("aback")
            || toTheWord.startsWith("ado")
            || toTheWord.startsWith("aside")
            || toTheWord.startsWith("auto")//! ?
            || toTheWord.endsWith("where")
            || toTheWord.startsWith("when")
            || toTheWord.startsWith("how")
            || toTheWord.endsWith("more")
            || toTheWord.endsWith("most")
            || toTheWord.length() > 2 && toTheWord.startsWith("by")// && ! toTheWord.equals("byte")//bite...
            || toTheWord.startsWith("across")
            || toTheWord.endsWith("ways")
            || toTheWord.endsWith("wards")
            || ! ( toTheWord.equals("less") || toTheWord.equals("bless") ) && toTheWord.endsWith("less")//!
            //...
            ? "adverbs"
        : toTheWord.startsWith("dis")
        && ! ( toTheWord.equals("dish") || toTheWord.startsWith("dish-") ) ? "dises"
        
        : ! ( toTheWord.endsWith("is") || toTheWord.endsWith("ion") || toTheWord.endsWith("ian")//22
            || toTheWord.endsWith("us") || toTheWord.endsWith("oir")
            || toTheWord.endsWith("ish")
            || toTheWord.endsWith("ism")
            //|| toTheWord.endsWith("ess")//"ness")//-less?
            || toTheWord.endsWith("eur")
            || toTheWord.length() > 4 && toTheWord.endsWith("edge")
            || toTheWord.length() > 3 && toTheWord.endsWith("age")
            || toTheWord.endsWith("ics")
            || toTheWord.endsWith("oid") || toTheWord.endsWith("oids")//! !?
            || toTheWord.length() > 5 && toTheWord.endsWith("ard")//5
            || toTheWord.endsWith("ers") || toTheWord.endsWith("ors") || toTheWord.endsWith("ars")
            || toTheWord.length() > 3 && toTheWord.endsWith("man")//5
            || toTheWord.endsWith("ia")//tia")
            || toTheWord.endsWith("ula")
            || toTheWord.length() > 3 && toTheWord.endsWith("out")
            || toTheWord.endsWith("ym")
            || toTheWord.endsWith("iac")
            || toTheWord.endsWith("egm")
            || toTheWord.endsWith("ings")
            || toTheWord.endsWith("ful")//!
            || toTheWord.endsWith("oo")
            //|| toTheWord.endsWith("en")//! ?--!!:
            || toTheWord.length() > 7 && ( toTheWord.endsWith("ten") || toTheWord.endsWith("den") )//5,7,lighten...
            || toTheWord.endsWith("ero")
            || toTheWord.endsWith("eau")
            || toTheWord.endsWith("ma")
            || toTheWord.endsWith("i")
            || toTheWord.endsWith("yr")
            || toTheWord.length() > 3 && toTheWord.endsWith("let")
            || toTheWord.startsWith("where")//!
            || toTheWord.endsWith("most")
            || toTheWord.endsWith("works")
            || toTheWord.length() > 5 && ( toTheWord.endsWith("able") || toTheWord.endsWith("ible") )//5
            || toTheWord.endsWith("ou")
            || toTheWord.endsWith("ee")
            || toTheWord.endsWith("io")
            || toTheWord.equals("no") || toTheWord.equals("not")//!!
            || toTheWord.equals("an") || toTheWord.equals("a") || toTheWord.equals("the")//!!
            || toTheWord.endsWith("eu")//ieu
            || toTheWord.endsWith("eon")
            || toTheWord.equals("aids")//...
            || toTheWord.equals("anna")
            || toTheWord.length() > 5 && toTheWord.endsWith("house")//nouns...
            || toTheWord.length() > 4 && toTheWord.endsWith("worm")
            || toTheWord.equals("pants")
            || toTheWord.endsWith("ika")
            || toTheWord.endsWith("stroke")
            || toTheWord.endsWith("ika")
            || toTheWord.startsWith("un") && ! toTheWord.equals("unique")//!and to the third form...
            //...
            
            || toTheWord.contains("-")//!!
            )
            || toTheWord.equals("is") || toTheWord.endsWith("-is")
            || toTheWord.equals("bus") || toTheWord.endsWith("-bus")
            /*
            || toTheWord.equals("press") || toTheWord.endsWith("-press")
            || toTheWord.equals("access") || toTheWord.endsWith("-access")
            || toTheWord.equals("address") || toTheWord.endsWith("-address")
            || toTheWord.equals("bless") || toTheWord.endsWith("-bless")
            || toTheWord.equals("chess") || toTheWord.endsWith("-chess")//frame
            || toTheWord.equals("confess") || toTheWord.endsWith("-confess")
            || toTheWord.equals("dress") || toTheWord.endsWith("-dress")//adopt
            || toTheWord.equals("guess") || toTheWord.endsWith("-guess")
            || toTheWord.equals("mess") || toTheWord.endsWith("-mess")
            || toTheWord.equals("jess") || toTheWord.endsWith("-jess")
            || toTheWord.equals("less") || toTheWord.endsWith("-less")//!
            //...
            */
            || toTheWord.equals("age") || toTheWord.endsWith("-age")
            || toTheWord.equals("sage") || toTheWord.endsWith("-sage")
            || toTheWord.equals("rage") || toTheWord.endsWith("-rage")
            || toTheWord.equals("void") || toTheWord.endsWith("-void")
            || toTheWord.equals("avoid") || toTheWord.endsWith("-avoid")
            //|| toTheWord.equals("zero") || toTheWord.endsWith("-zero")
            || toTheWord.equals("see") || toTheWord.endsWith("-see")
            || toTheWord.equals("fee") || toTheWord.endsWith("-fee")
            || toTheWord.equals("pee") || toTheWord.endsWith("-pee") ? toTheWord.length() > 6 ? "verbs" : "short_verbs"//!!ser
        : "other_words";//null;//!to the whetherDidTheWordOfQuackeryBe
        
        if( toTheNameOfTheTable != null && ! toTheDones.contains(toTheNameOfTheTable)
            && ! ( toThePrepositions.contains(toTheWord) || toTheConjunctions.contains(toTheWord)
                || toTheAsks.contains(toTheWord) || toThePronouns.contains(toTheWord)
                || toTheNumbers.contains(toTheWord) || toTheIrregularVerbs23.contains(toTheWord)
                || toTheOddVerbs.contains(toTheWord) ) )//second - on the time
        {
          wr.write( at++ + ") " + toTheWord +"\r\n" );
          
          toTheCommandForInsert = toTheCommands.get(toTheNameOfTheTable);
          toTheCommandForInsert.setString( 1, toTheWord );
          toTheCommandForInsert.executeUpdate();
          
        }
        
      }
      
      String toTheSelected;
      //int count = 0;
      for( String s : toTheRegularVerbsAndIrregular1Verbs )
      {
        if( ! toTheDones.contains("reg_600_irreg1_verbs")
            && ! ( s.endsWith("ate") || s.endsWith("ence") || s.endsWith("ance")
                || s.endsWith("ure") || s.endsWith("fy") || s.endsWith("ion")
                || s.startsWith("x-") || s.startsWith("dis") ) )
        {
          toTheCommandForSelectFromTheVERBS.setString( 1, s );
          ResultSet toTheSelecteds = toTheCommandForSelectFromTheVERBS.executeQuery();
          toTheSelected = toTheSelecteds.next() ? toTheSelecteds.getString(1) : null;//!
          //System.out.println( "!" + toTheSelected );
          if( toTheSelected == null )
          {
            //System.out.println(s);
            //++count;
            toTheCommandForInsertIntoTheVERBS.setString( 1, s );
            toTheCommandForInsertIntoTheVERBS.executeUpdate();
            
          }
          
        }
        
      }
      //System.out.println( count + " / " + toTheRegularVerbsAndIrregular1Verbs.size() );
      
    }
    catch( NullPointerException | IOException | SQLException ex )
    {
      ex.printStackTrace();
    }
    
    return toTheFruitedFile;
    
  }
  
  public static void main( String[] theArgumentsOfTheCallWithTheCommandLine )
  {
    File toTheFruitedFile = doEvenMoreParse();
    System.out.println( "Done! " + toTheFruitedFile );
    
  }
  
}
