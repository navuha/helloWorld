package counter.the_stuff_of_the_controller;

public interface TheCounterShape
{
	String doTheAfterRow
			(String theInterRow, int theConOfTheInterSign);
}