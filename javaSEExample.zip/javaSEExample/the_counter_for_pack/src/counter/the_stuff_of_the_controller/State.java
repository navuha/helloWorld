package counter.the_stuff_of_the_controller;

public enum State
{
	ThStart, ThFirst, ThOperator, ThSecond;
}