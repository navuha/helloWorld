1. For more information see the web-page "https://www.hackerrank.com/Condrar", please.
2. Five examples are with a description of its problem. The other file is additional.
3. The equal files are in both of the directories. The file name extensions are different.
