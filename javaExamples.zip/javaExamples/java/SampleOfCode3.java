This challenge I took through that URL: "https://www.hackerrank.com/challenges/java-string-token":
<<Given a string, find number of words in that string. For this problem a word is defined
by a string of one or more english alphabets.

There are multiple ways to tokenize a string in java, learn how to tokenize a string in java
and demonstrate your skill by solving this problem!

Input Format
A string not more than 400000 characters long. The string can be defined by following regular
expression:
[A-Za-z !,?.\_'@]+

That means the string will only contain english alphabets, blank spaces and this characters:
"!,?._'@".

Output Format
In the first line, print number of words nn in the string. The words don't need to be
unique. In the next nn lines, print all the words you found in the order they appeared
in the input.

Sample Input
He is a very very good boy, isn't he?

Sample Output
10
He
is
a
very
very
good
boy
isn
t
he>>

My answer:
<<package example;

import java.util.Scanner;
import java.util.regex.Pattern;

public class SampleOfCode3{//Solution{
	public static void main(String[]args){
		Scanner scanner=new Scanner(System.in);
        	String line=scanner.nextLine();
	        scanner.close();
        	//complete the code
        	int numberOfTokens;
        	if(!line.isEmpty()&&Pattern.matches("^([A-Za-z\\s!,?._'@]|-){1,400000}$",line)){
        		line=line.replaceAll("([\\s!,?._'@]|-)+"," ");
	        	if(line.equals(" ")){
        			line="";
        			numberOfTokens=0;
        			//System.out.println(line);
        			System.out.println(numberOfTokens);
        		}else{
        			line=line.trim();
        			//System.out.println(line);
	        		String[]tokensOfTheLine=line.split("\\s");
	        		numberOfTokens=tokensOfTheLine.length;
	        		System.out.println(numberOfTokens);
	        		for(String token:tokensOfTheLine)
		        		System.out.println(token);
        		}
        	}else{
        		numberOfTokens=0;
        		//System.out.println(line);
        		System.out.println(numberOfTokens);
        	}
	}
}>>