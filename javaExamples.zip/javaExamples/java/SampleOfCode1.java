This challenge I took through that URL: "https://www.hackerrank.com/challenges/java-1d-array":
<<You are playing a game on your cellphone. You are given an array of length n, indexed from 0
to n-1. Each element of the array is either 0 or 1. You can only move to an index which contains
0. At first you are at the 0th position. In each move you can do one of the following things:
	1) Walk one step forward or backward.
	2) Make a jump of exactly length mm forward.

That means you can move from position x to x+1, x-1 or x+m in one move. The new position must
contain 0. Also you can move to any position greater than n-1.

You can't move backward from position 0. If you move to any position greater than n-1, you win
the game.

Given the array and the length of the jump, you need to determine if it's possible to win
the game or not.

Input Format
In the first line there will be an integer T denoting the number of test cases. Each
test case will consist of two lines. The first line will contain two integers, n and m.
On the second line there will be n space-separated integers, each of which is either 0
or 1.

Constraints
1<=T<=5000
2<=n<=100
0<=m<=1000
The first integer of the array is always 0.

Output Format
For each case output "YES" if it's possible to win the game, output "NO" otherwise.

Sample Input
4
5 3
0 0 0 0 0
6 5
0 0 0 1 1 1
6 3
0 0 1 1 1 0
3 1
0 1 0

Sample Output
YES
YES
NO
NO

Explanation
In the first case you can just walk to reach the end of the array.
In the second case, you can walk to index 1 or 2 and jump from there. In the third case, jump length
is too low, you can't reach the end of the array. In the fourth case, jump length is 1, so it
doesn't matter if you jump or walk, you can't reach the end.>>

My answer:
<<package example;//eto prv-l.uz!

public class SampleOfCode1{//Solution{
	private static final class Data{
		static int[]jump;
		static int[][]path;
		static boolean permission;
		
		private static void receiveTheData(){
			java.util.Scanner inputStream=new java.util.Scanner(System.in);
			
			int numberOfTheTestCases=inputStream.nextInt();
			jump=new int[numberOfTheTestCases];
			path=new int[numberOfTheTestCases][];
			for(int j=0,i;j<numberOfTheTestCases;++j){///,i
				int numberOfTheItemsOfTheArray=inputStream.nextInt();
				jump[j]=inputStream.nextInt();
				path[j]=new int[numberOfTheItemsOfTheArray];
				for(/*int */i=0;i<numberOfTheItemsOfTheArray;++i)///int
					path[j][i]=inputStream.nextInt();
			}
			
			inputStream.close();
		}
		
		private static void issueThePermission(){
			permission=Data.path.length>=1&&Data.path.length<=5e3;
			if(!permission)
				System.out.println("Data(the number of the tast cases) is out of boundaries!");
			for(int j=0;permission&&j<Data.path.length;++j){
				permission=Data.path[j].length>=2&&Data.path[j].length<=100
						&&Data.jump[j]>=0&&Data.jump[j]<=100;
				if(!permission)
					System.out.println("Data(the number of the parts(a 0 or a 1) of path["+j+"] or\n"
							+"the value of jump["+j+"]) is out of boundaries!");
				
				permission&=Data.path[j][0]==0;
				if(!permission)
					System.out.println("Data(the value of part[0] of path["+j
							+"]) is out of boundaries([0])!");
				for(int i=1;permission&&i<Data.path[j].length;++i){
					permission=Data.path[j][i]==0||Data.path[j][i]==1;
					if(!permission)
						System.out.println("Data(the value of part["+i+"] of path["+j
								+"]) is out of boundaries([0,1])!");
				}
			}
		}
		
		static{
			receiveTheData();
			issueThePermission();
		}
	}
	
	private static final class EData{
		static int[]jump;
		static int[][]path;
		
		private static void transferTheUnimprovablePartOfTheData(){
			jump=new int[Data.jump.length];
			path=new int[Data.path.length][];
		}
		
		private static void makeTheJumpEffective(){
			for(int j=0;j<jump.length;++j)
				jump[j]=Data.jump[j]>1?Data.jump[j]:-1;
		}
		
		private static void makeThePathEffective(){
			for(int j=0,firstIndexOfTheNothingOrOfZeroEnd;j<path.length;++j){
				for(firstIndexOfTheNothingOrOfZeroEnd=Data.path[j].length;
						firstIndexOfTheNothingOrOfZeroEnd>1
						&&Data.path[j][firstIndexOfTheNothingOrOfZeroEnd-1]==0;
						--firstIndexOfTheNothingOrOfZeroEnd){};
				path[j]=new int[firstIndexOfTheNothingOrOfZeroEnd];
				for(int i=0;i<firstIndexOfTheNothingOrOfZeroEnd;++i)
					path[j][i]=Data.path[j][i];
			}
		}
		
		
		private static int whatIsTheIndexOfFirstZeroInThisMultipleSequenceOfZerosHere(
				int j,int indexOfLastZero){
			int indexOfFirstZero=indexOfLastZero-1;
			for(;indexOfFirstZero>1//0 is first in every path
					&&EData.path[j][indexOfFirstZero-1]==0;
					--indexOfFirstZero){};
		//	System.out.println("whatIsTheIndexOfFirstZeroInThisMultipleSequenceOfZerosHere(i="
		//	+indexOfLastZero+"):"+indexOfFirstZero);
			return indexOfFirstZero;
		}
		
		private static void closeTheZerosOfTraps(){
			boolean itIsATrapSequence;
			//po psld.sltc(570 v ''Excel):
			for(int j=0,i,k,indexOfFirstZero;j<EData.path.length;++j)
				if(EData.path[j].length>4
						&&EData.jump[j]>1&&EData.jump[j]<EData.path[j].length-2)
					for(i=EData.path[j].length-1-EData.jump[j];i>0;--i)///{//i>1;--i)//{
				//		System.out.println("1)i:"+i);
				//	}
						if(EData.path[j][i]==0
								&&EData.path[j][i+1]==1
								&&EData.path[j][i+EData.jump[j]]==1)//the last item equals to 1 in all cases
							if(EData.path[j][i-1]==1)
								EData.path[j][i]=1;
							else{// if(EData.path[j][i-1]==0)
								indexOfFirstZero
										=whatIsTheIndexOfFirstZeroInThisMultipleSequenceOfZerosHere(j,i);
										//except for first Zero as One
								for(k=indexOfFirstZero>0?indexOfFirstZero:++indexOfFirstZero,
										itIsATrapSequence=true;
										itIsATrapSequence&&k<i;++k)//{//v ''i ''true is.
									itIsATrapSequence=EData.path[j][k+EData.jump[j]]==1;
					//				System.out.println(k+")"+itIsATrapSequence);
					//			}
					//			System.out.println("itIsATrapSequence:"+itIsATrapSequence);
								if(itIsATrapSequence)//{
					//				System.out.println("itIsATrapSequence:["+indexOfFirstZero+","+i+"]");
									for(k=indexOfFirstZero>0?indexOfFirstZero:++indexOfFirstZero;
											k<=i;++k)//first - 0
										EData.path[j][k]=1;
					//			}
							}
		}
		
		
		static{
			transferTheUnimprovablePartOfTheData();
			makeTheJumpEffective();
			makeThePathEffective();
			
		//	System.out.println("The data is made effective:");
		//	for(int j=0;j<path.length;++j){
		//		System.out.println(jump[j]);
				
		//		for(int i=0;i<path[j].length;++i)
		//			System.out.print(path[j][i]+" ");
				
		//		System.out.println();
		//	}
			
			closeTheZerosOfTraps();
			
		//	System.out.println("The effective path data after closed the zeros of traps:");
		//	for(int j=0;j<path.length;++j){
		//		for(int i=0;i<path[j].length;++i)
		//			System.out.print(path[j][i]+" ");
				
		//		System.out.println();
		//	}
		}
	}
	
	
	
	private int currentPosition=0;
	
	
	
//	private boolean isCurrentPositionPermitted(int j){
//		return currentPosition>=0&&currentPosition<EData.path[j].length;
//	}
	
	
	private static boolean haveITheJump(int j){
	//	System.out.println("haveITheJump");
		return EData.jump[j]!=-1;
	}
	
	private static boolean haveITheWinningJump(int j){
	//	System.out.println("haveITheWinningJump");
		return EData.jump[j]>=EData.path[j].length;
	}
	
	
	private boolean isItZeroBefore(int j){
	//	System.out.println("isItZeroBefore");
		return EData.path[j][currentPosition+1]==0;
	}
	
	private boolean isItZeroBehind(int j){
	//	System.out.println("isItZeroBehind");
		return
				currentPosition>0?
					EData.path[j][currentPosition-1]==0
				:false;
	}
	
	
	private int whatIsTheIndexOfZeroOrOfTheEndBeforeThisSequenceOfOnes(int j){
		int indexOfZeroBeforeThisSequenceOfOnes=currentPosition+2;
		for(;indexOfZeroBeforeThisSequenceOfOnes<EData.path[j].length
				&&EData.path[j][indexOfZeroBeforeThisSequenceOfOnes]!=0;
				++indexOfZeroBeforeThisSequenceOfOnes){};
	//	System.out.println("whatIsTheIndexOfZeroOrOfEndBeforeThisSequenceOfOnes:"
	//			+indexOfZeroBeforeThisSequenceOfOnes);
		return indexOfZeroBeforeThisSequenceOfOnes;
	}
	
	private int canIJumpOverThisSequenceOfOnesOrOverMoreFromHere(int j){
		int positionOfTheLanding=currentPosition+EData.jump[j];
	//	if(positionOfTheLanding<EData.path[j].length
	//			&&positionOfTheLanding!=EData.path[j].length-1)
	//		System.out.println("canIJumpOverThisSequenceOfOnesOrOverMoreFromHere:");
	//	else
	//		System.out.println("canIJumpOverThisSequenceOfOnesOrOverMoreFromHere");
		return
				positionOfTheLanding<EData.path[j].length?
					positionOfTheLanding!=EData.path[j].length-1?
						positionOfTheLanding>=whatIsTheIndexOfZeroOrOfTheEndBeforeThisSequenceOfOnes(j)
								&&EData.path[j][positionOfTheLanding]==0?
							1
						:0
					:0
				:-3;
	}
	
	
	
	int imaginaryPositionOfTheLandingAfterTheSuccessfulImaginaryCleverJump;
	
	
	private boolean canICleverlyJumpOverThisSequenceOfOnesOrMore(int j){
	//	System.out.println("canICleverlyJumpOverThisSequenceOfOnesOrMore{");
	//	System.out.println("if-condition{");
		if(isItZeroBehind(j)
				&&whatIsTheIndexOfZeroOrOfTheEndBeforeThisSequenceOfOnes(j)<currentPosition+EData.jump[j]){
	//		System.out.println("}if-condition");
			boolean iCanNotJumpOver;
			int realPosition=currentPosition;
			do{
				--currentPosition;
	//			System.out.println("an imaginary step back:"+currentPosition);
				iCanNotJumpOver=canIJumpOverThisSequenceOfOnesOrOverMoreFromHere(j)==0;
	//			System.out.println("do-while-condition:");
			}while(isItZeroBehind(j)&&iCanNotJumpOver);
			if(!iCanNotJumpOver)
				imaginaryPositionOfTheLandingAfterTheSuccessfulImaginaryCleverJump
						=currentPosition+EData.jump[j];
			currentPosition=realPosition;
	//		System.out.println("}canICleverlyJumpOverThisSequenceOfOnesOrMore:"+!iCanNotJumpOver);
			return !iCanNotJumpOver;
		}else
			return false;
	}
	
	
	private void stepForth(int j){
	//	System.out.println("stepForth");
		++currentPosition;
	}
	
	private void jumpForth(int j){
	//	System.out.println("jumpForth");
		currentPosition+=EData.jump[j];
	}
	
	private void cleverlyJumpForth(int j){
	//	System.out.println("cleverlyJumpForth");
		currentPosition=imaginaryPositionOfTheLandingAfterTheSuccessfulImaginaryCleverJump;
	}
	
	
	private static void answer(boolean itIsAWin){
	//	System.out.println("\nanswer:");
		if(itIsAWin)
			System.out.println("YES");
		else
			System.out.println("NO");
	}
	
	
	
	private boolean itIsAWin,itIsALoss;
	
	
	
	Solution(int j){
	//	System.out.println("constructor{");
		itIsAWin=EData.path[j].length==1
				||haveITheWinningJump(j);
		itIsALoss=
				!itIsAWin?
					!haveITheJump(j)&&EData.path[j].length>1
				:false;
	//	System.out.println("}constructor");
	}
	
	
	private void playGame(int j){
	//	System.out.println("playGame("+j+"){");
		while(!itIsAWin&&!itIsALoss){
	//		System.out.println("playGame("+j+"):while{");
			if(isItZeroBefore(j))
				stepForth(j);
			else{
				int iCanJumpOver=canIJumpOverThisSequenceOfOnesOrOverMoreFromHere(j);
				if(iCanJumpOver==-3)
					itIsAWin=true;
				else if(iCanJumpOver==1)
					jumpForth(j);
				else if(iCanJumpOver==0)
					if(canICleverlyJumpOverThisSequenceOfOnesOrMore(j))
						cleverlyJumpForth(j);
					else
						itIsALoss=true;
			}
	//		System.out.println("}playGame("+j+"):while");
		}
	//	System.out.println("the end current position:"+currentPosition);
		answer(itIsAWin);
	//	System.out.println("}playGame("+j+")");
	}
	
	
	public static void main(String[]args){ 
		if(Data.permission)
			for(int j=0;j<EData.path.length;++j)
				new Solution(j).playGame(j);
		else
			System.out.print("The games are not created.");
	}
}>>