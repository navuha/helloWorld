Here is some other examples of code:
<</*package example;
import java.util.Scanner;
import java.util.Locale;

public class Solution{
	public static void main(String[]args){
		//enter your code here. Read input from STDIN.
		//Print output to STDOUT. Your class should be named Solution:
		try(Scanner fromTheInput=new Scanner(System.in)){
			final int
					lengthOfASide=fromTheInput.nextInt(),
					velocityOne=fromTheInput.nextInt(),
					velocityTwo=fromTheInput.nextInt();
			int totalNumberOfTheQueries=fromTheInput.nextInt();
			final long squareOfTheLengthOfASide=(long)lengthOfASide*lengthOfASide;//!long! - in. urwz-e
			long query;
			boolean permission=lengthOfASide>=1&&lengthOfASide<=1e9
					&&velocityOne>=1&&velocityOne<=1e9
					&&velocityTwo>=1&&velocityTwo<=1e9
					&&totalNumberOfTheQueries>=1&&totalNumberOfTheQueries<=1e5
					&&velocityOne!=velocityTwo;
			final double sin45=Math.sin(Math.PI/4);
			double time;
			for(;permission&&totalNumberOfTheQueries-->0;){
				query=fromTheInput.nextLong();
				permission=query>=1l&&query<=squareOfTheLengthOfASide;
				if(permission){
					//v2>v1 or v1>v2: vxy=v2-v1 or vxy=v1-v2: v>0
					//vy=vxy*sin45=vxy*sqrt2/2
					//q=l*l,l=l0-vyt:t=(l0-l)/vy=(l0-sqrtq)/vy=(l0-sqrtq)/(vxy*sin45)
					time=velocityTwo>velocityOne?
						(lengthOfASide-Math.sqrt(query))/((velocityTwo-velocityOne)*sin45)
					:(lengthOfASide-Math.sqrt(query))/((velocityOne-velocityTwo)*sin45);
					
					System.out.printf(Locale.UK,"%.4f\n",time);
				}
			}
			
			if(!permission)
				System.out.println("The data is not permitted!");
		}
	}
}*///rb



/*package example;
import java.util.Scanner;

public class Solution{
	public static void main(String[]args){
		//enter your code here. Read input from STDIN.
		//Print output to STDOUT. Your class should be named Solution:
		try(Scanner fromTheInput=new Scanner(System.in)){
			for(int t=fromTheInput.nextInt(),
					totalNumberOfThePairsOfSocks=fromTheInput.nextInt();t>0;
					totalNumberOfThePairsOfSocks=--t>0?fromTheInput.nextInt():-1)
				System.out.println(totalNumberOfThePairsOfSocks+1);
		}
	}
}*/



/**package example;
import java.util.Scanner;

public class Solution{
	public static void main(String[]args){
		/* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. *//**
		final int n=2;
		int t,i,
				dx,dy;//dx=dy/a:dx=(y2-b)/a-(y1-b)/a
		int[]pointP=new int[n],
				centralPointQ=new int[n],
				mirroredPointP=new int[n];
		boolean permission;
		
		try(Scanner fromTheInput=new Scanner(System.in)){
			for(t=fromTheInput.nextInt(),permission=t>=0&&t<=15;permission&&t>0;--t){
				pointP[0]=fromTheInput.nextInt();
				pointP[1]=fromTheInput.nextInt();
				
				centralPointQ[0]=fromTheInput.nextInt();
				centralPointQ[1]=fromTheInput.nextInt();
				
				i=0;
				do
					permission&=pointP[i]>=-100&&pointP[i]<=100
							&&centralPointQ[i]>=-100&&centralPointQ[i]<=100;
				while(++i<n);
				
				if(permission){
					dx=centralPointQ[0]-pointP[0];
					dy=centralPointQ[1]-pointP[1];
					if(pointP[0]==centralPointQ[0]&&pointP[1]==centralPointQ[1]){
						mirroredPointP[0]=pointP[0];
						mirroredPointP[1]=pointP[1];
					}else if(pointP[0]!=centralPointQ[0]&&pointP[1]==centralPointQ[1]){
						mirroredPointP[0]=centralPointQ[0]+dx;
						mirroredPointP[1]=centralPointQ[1];
					}else if(pointP[0]==centralPointQ[0]&&pointP[1]!=centralPointQ[1]){
						mirroredPointP[0]=centralPointQ[0];
						mirroredPointP[1]=centralPointQ[1]+dy;
					}else{// if(pointP[0]!=centralPointQ[0]&&pointP[1]!=centralPointQ[1])
						mirroredPointP[0]=centralPointQ[0]+dx;
						mirroredPointP[1]=centralPointQ[1]+dy;
					}
					
					System.out.println(mirroredPointP[0]+" "+mirroredPointP[1]);
				}
			}
			
			if(!permission)
				System.out.println("The data is not permitted!");
		}catch(Exception unusualCase){
			System.out.println("Exception:"+unusualCase);
			unusualCase.printStackTrace();
		}
	}
}**///!rb!



//!vzh:vsio po dzh!07.04.2016
/**package example;
//import java.lang.annotation.*;//!:
import java.lang.annotation.Target;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
//import java.lang.reflect.*;//!:
import java.lang.reflect.Method;
//import java.util.*;//!:
import java.util.Scanner;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@interface FamilyBudget{
	String userRole()default"GUEST";
	int budgetLimit()default 0;//!~~Complete the interface~~
}

class FamilyMember{
	//!~~Complete this line~~
	@FamilyBudget(userRole="SENIOR",budgetLimit=100)//!
	public void seniorMember(int budget,int moneySpend) {
		System.out.println("Senior Member");
		System.out.println("Spend: "+moneySpend);
		System.out.println("Budget Left: "+(budget-moneySpend));
	}
	
	//~~Complete this line~~
	@FamilyBudget(userRole="JUNIOR",budgetLimit=50)//!
	public void juniorUser(int budget,int moneySpend){
		System.out.println("Junior Member");
		System.out.println("Spend: "+moneySpend);
		System.out.println("Budget Left: "+(budget-moneySpend));
	}
}

public class Solution{
	public static void main(String[]args){
		Scanner in=new Scanner(System.in);
		
		int testCases=Integer.parseInt(in.nextLine());
		while(testCases>0){
			String role=in.next();
			int spend=in.nextInt();
			try{
				//Class annotatedClass=FamilyMember.class;
				Class<FamilyMember> annotatedClass=FamilyMember.class;//!
				Method[]methods=annotatedClass.getMethods();
				for(Method method:methods){
					if(method.isAnnotationPresent(FamilyBudget.class)){
						FamilyBudget family=method
								.getAnnotation(FamilyBudget.class);
						String userRole=family.userRole();
						//int budgetLimit=~~Complete this line~~;
						int budgetLimit=family.budgetLimit();//!
						if(userRole.equals(role))
							//if(~~Complete this line~~)
							if(spend<=budgetLimit)
								method.invoke(FamilyMember.class.newInstance(),
										budgetLimit,spend);
							else
								System.out.println("Budget Limit Over");
					}
				}
			}catch(Exception e){
				e.printStackTrace();
			}
			
			testCases--;
		}
		
		in.close();//!
	}
}
/*z-vd:
"3
SENIOR 75
JUNIOR 45
SENIOR 40",
vvd:
"Senior Member
Spend: 75
Budget Left: 25
Junior Member
Spend: 45
Budget Left: 5

Senior Member
Spend: 40
Budget Left: 60
"
*/



/*package example;
import java.util.*;
import java.security.*;

interface Food{
	public String getType();
}

class Pizza implements Food{
	public String getType(){return "Someone ordered a Fast Food!";}
}

class Cake implements Food{
	public String getType(){return "Someone ordered a Dessert!";}
}

class FoodFactory{
	public Food getFood(String order){
		//Write your code here
		return//!:
				order.equals("pizza")?
					new Pizza()
				:order.equals("cake")?
					new Cake()
				:null;//-!
	}//End of getFood method
}//End of factory class

public class Solution{
	public static void main(String[]args){
		Do_Not_Terminate.forbidExit();
		
		try{
			Scanner sc=new Scanner(System.in);
			//creating the factory
			FoodFactory foodFactory=new FoodFactory();
			
			//factory instantiates an object
			Food food=foodFactory.getFood(sc.nextLine());
			
			System.out.println("The factory returned "+food.getClass());
			System.out.println(food.getType());
		}catch(Do_Not_Terminate.ExitTrappedException e){
			System.out.println("Unsuccessful Termination!!");
		}
	}
}

class Do_Not_Terminate{//!et. n.mj.kl: toliko ''factory
	public static class ExitTrappedException extends SecurityException{
		private static final long serialVersionUID=1L;
	}
	
	public static void forbidExit(){
		final SecurityManager securityManager=new SecurityManager(){
			@Override
			public void checkPermission(Permission permission){
				if(permission.getName().contains("exitVM"))
					throw new ExitTrappedException();
			}
		};
		System.setSecurityManager(securityManager);
	}
}*/	



/*package example;
import java.io.*;
import java.util.*;
//import java.text.*;
//import java.math.*;
//import java.util.regex.*;
import java.lang.reflect.*;
//!my code:
import static java.lang.System.in;//!

class Prime{//!
	void checkPrime(int...numbers){
		int i;
		boolean stillPrime;
		for(int aNumber:numbers){
			for(i=2,stillPrime=aNumber>1;stillPrime&&i<=aNumber/2;stillPrime=aNumber%i!=0,++i){}
			if(stillPrime)
				System.out.print(aNumber+" ");
		}
		System.out.print("\n");
	}
}
//-!
public class Solution{
	public static void main(String[]args){
		try{
			BufferedReader br=new BufferedReader(new InputStreamReader(in));
			int n1=Integer.parseInt(br.readLine());
			int n2=Integer.parseInt(br.readLine());
			int n3=Integer.parseInt(br.readLine());
			int n4=Integer.parseInt(br.readLine());
			int n5=Integer.parseInt(br.readLine());
			Prime ob=new Prime();
			ob.checkPrime(n1);
			ob.checkPrime(n1,n2);
			ob.checkPrime(n1,n2,n3);
			ob.checkPrime(n1,n2,n3,n4,n5);	
			Method[]methods=Prime.class.getDeclaredMethods();
			Set<String>set=new HashSet<>();
			boolean overload=false;
			for(int i=0;i<methods.length;++i){
				if(set.contains(methods[i].getName())){
					overload=true;
					break;
				}
				set.add(methods[i].getName());
			}
			if(overload)
				throw new Exception("Overloading not allowed");
		}catch(Exception e){
			System.out.println(e);
		}
	}
}*/



/*package example;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.regex.*;
import java.security.*;


public class Solution{
	public static void main(String[]args)throws Exception{
		Do_Not_Terminate.forbidExit();	
		
		try{
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			int num=Integer.parseInt(br.readLine().trim());
			Object o;// Must be used to hold the reference of the instance of the class Solution.Inner.Private
			//!:
			Solution.Inner boundary=new Solution.Inner();
			o=boundary.new Private();//!kk trwb-t sr..''Eclipse
			//boundary.Private 
			//Solution.Inner.Private o1=boundary.new Private();//!the first mode
			System.out.println(num+" is "+((Solution.Inner.Private)o).powerof2(num));//o1.powerof2(num));
			//new (new Solution()).Inner();//-shb prii n.''static//new Solution.Inner();//-rb
			//-!
			System.out.println("An instance of class: "+o.getClass().getCanonicalName()+" has been created");
		}//end of try
		catch (Do_Not_Terminate.ExitTrappedException e){
			System.out.println("Unsuccessful Termination!!");
		}
	}//end of main
	
	//static 
	static class Inner{
		private class Private{
			private String powerof2(int num){
				return(num&num-1)==0?"power of 2":"not a power of 2";//!num&(num-1) - po''bit.szh:
				//num=3=0b11;11&10->10(v mnsh.storn-u) !=0... ==0 toliko s 'invwrs.zv ili tcs.'invers.
				//(0 na 1: 100 i 000):
				//num=4=0b100;100&11->0 ==0! - z-bv. z-kn!(!vzh)
			}
		}
	}//end of Inner
}//end of Solution

class Do_Not_Terminate {
	public static class ExitTrappedException extends SecurityException{
		private static final long serialVersionUID=1L;
	}
	
	public static void forbidExit(){
		final SecurityManager securityManager=new SecurityManager(){
			@Override
			public void checkPermission(Permission permission){
				if(permission.getName().contains("exitVM"))
					throw new ExitTrappedException();
			}
		};
		
		System.setSecurityManager(securityManager);
	}
}*/



/*package example;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;

class Student{
	private String name,id,email;
	
	
	public String getName(){return name;}
	
	public void setId(String id){this.id=id;}
	
	public void setEmail(String email){this.email=email;}
	
	public void anothermethod(){}
}

public class Solution{
	public static void main(String[]args){
		Class student=new Student().getClass();// ~~~Complete this line~~~;
		Method[]methods=student.getDeclaredMethods();// ~~~Complete this line~~~;
		
		ArrayList<String>methodList=new ArrayList<>();
		for(Method aMethod:methods)//~~~Complete this line~~~)
			methodList.add(aMethod.getName());//~~~Complete this line~~~);
		Collections.sort(methodList);
		for(String name:methodList)
			System.out.println(name);
	}
}*/



/**package example;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;
//import java.text.*;
//import java.math.*;
//import java.util.regex.*;
//ps toliko jd.kl, kk i v prd-jd.prmr:
//Write your code here
class Add{
	void add(int...numbers){
		int summa=0,
				i=0,
				indexOfTheLastNumber=numbers.length-1;
		for(int aNumber:numbers){
			summa+=aNumber;
			System.out.print(aNumber);
			if(i<indexOfTheLastNumber){
				++i;
				System.out.print("+");
			}
		}
		System.out.println("="+summa);
	}
}

public class Solution{
	public static void main(String[]args){
		try{
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			int n1=Integer.parseInt(br.readLine());
			int n2=Integer.parseInt(br.readLine());
			int n3=Integer.parseInt(br.readLine());
			int n4=Integer.parseInt(br.readLine());
			int n5=Integer.parseInt(br.readLine());
			int n6=Integer.parseInt(br.readLine());
			Add ob=new Add();
			ob.add(n1,n2);
			ob.add(n1,n2,n3);
			ob.add(n1,n2,n3,n4,n5);	
			ob.add(n1,n2,n3,n4,n5,n6);
			Method[]methods=Add.class.getDeclaredMethods();
			Set<String>set=new HashSet<>();
			boolean overload=false;
			for(int i=0;i<methods.length;i++){
				if(set.contains(methods[i].getName())){
					overload=true;
					break;
				}
				set.add(methods[i].getName());
			}
			if(overload){
				throw new Exception("Overloading not allowed");
			}
		}catch(Exception e){
				e.printStackTrace();
		}
	}
}**/



/**package example;
//!tcs..ix.ps n.izm:
import java.util.*;
import java.io.IOException;
import java.security.Permission;

class Calculate{
	//private static double volume;
	
	//private 
	static final class Main{
		double main(int a){
			if(a<=0)
				throw new NumberFormatException("All the values must be positive");
			//return volume=Math.pow(a,3);
			return Math.pow(a,3);
		}
		
		double main(int l,int b,int h){
			if(l<=0||b<=0||h<=0)
				throw new NumberFormatException("All the values must be positive");
			//return volume=l*b*h;
			return l*b*h;
		}
		
		double main(double r){
			if(r<=0)
				throw new NumberFormatException("All the values must be positive");
			//return volume=4/3*Math.PI*Math.pow(r,3)/2;
			return 4.0/3.0*Math.PI*Math.pow(r,3.0)/2.0;
		}
		
		double main(double r,double h){
			if(r<=0||h<=0)
				throw new NumberFormatException("All the values must be positive");
			//return volume=Math.PI*Math.pow(r,2)*h;
			return Math.PI*Math.pow(r,2.0)*h;
		}
	}
	static Main get_Vol(){return new Main();}
	
	//private 
	final class Output{
		void display(double volume){System.out.printf(Locale.UK,"%.3f\n",volume);}
	}
	Output output=new Output();
	
	
	Scanner fromTheInput=new Scanner(System.in);
	
	int getINTVal()throws IOException{
		return fromTheInput.nextInt();
	}
	
	double getDoubleVal()throws IOException{
		return Double.parseDouble(fromTheInput.next());
	}
}

public class Solution{
	public static void main(String[]args){
		Do_Not_Terminate.forbidExit();		
		try{
			Calculate cal=new Calculate();
			int t=cal.getINTVal();
			while(t-->0){//!
				double volume=0.0;//0.0d;		
				int ch=cal.getINTVal();			
				if(ch==1){
					int a=cal.getINTVal();
					volume=Calculate.get_Vol().main(a);
				}else if(ch==2){
					int l=cal.getINTVal();
					int b=cal.getINTVal();
					int h=cal.getINTVal();
					volume=Calculate.get_Vol().main(l,b,h);
				}else if(ch==3){
					double r=cal.getDoubleVal();
					volume=Calculate.get_Vol().main(r);
				}else{// if(ch==4){
					double r=cal.getDoubleVal();
					double h=cal.getDoubleVal();
					volume=Calculate.get_Vol().main(r,h);
				}
				
				cal.output.display(volume);
			}
		}catch(NumberFormatException e){
			System.out.print(e);
		}catch(IOException e){
			e.printStackTrace();
		}catch(Do_Not_Terminate.ExitTrappedException e){
			System.out.println("Unsuccessful Termination!!");
		}
	}
}
/**
 * This class prevents the user from using System.exit(0)
 * from terminating the program abnormally.
 *//**
class Do_Not_Terminate {
	public static class ExitTrappedException extends SecurityException {}
	
	public static void forbidExit(){
		final SecurityManager securityManager=new SecurityManager(){
			@Override
			public void checkPermission(Permission permission){
				if(permission.getName().contains("exitVM"))
					throw new ExitTrappedException();
			}
		};
		System.setSecurityManager(securityManager);
	}
}//end of Do_Not_Terminate**///rb!



/*package example;
import java.util.*;

public class Solution{//Main{
	static Iterator func(ArrayList mylist){
		Iterator it=mylist.iterator();
		while(it.hasNext()){
			//Object element = ~~Complete this~~
			//if(~~Complete this line~~)//Hints: use instanceof operator
				//break;
			Object element=it.next();
			if(element instanceof String)//Hints: use instanceof operator
				break;
		}
		
		return it;
	}
	
	public static void main(String[]argh){
		ArrayList myList=new ArrayList();
		Scanner sc=new Scanner(System.in);
		int
				n=sc.nextInt(),
				m=sc.nextInt();
		for(int i=0;i<n;++i){
			myList.add(sc.nextInt());
		}
		
		myList.add("###");
		
		for(int i=0;i<m;++i){
			myList.add(sc.next());
		}
		
		Iterator it=func(myList);
		while(it.hasNext()){
			Object element = it.next();
			System.out.println((String)element);
		}
	}
}*/



/*package example;
//izm mzh tlk trj..strk:
import java.util.*;

class Student{}
class Rockstar{}
class Hacker{}

public class Solution{//InstanceOFTutorial
	static String count(ArrayList mylist){
		int a=0,b=0,c=0;
		for(int i=0;i<mylist.size();++i){
			Object element=mylist.get(i);
			if(element instanceof Student)//!
				a++;
			else if(element instanceof Rockstar)//!
				b++;
			else if(element instanceof Hacker)//!
				c++;
		}
		
		String ret=Integer.toString(a)+" "+Integer.toString(b)+" "+Integer.toString(c);
		return ret;
	}
	
	public static void main(String[]argh){
		ArrayList mylist=new ArrayList();
		Scanner sc=new Scanner(System.in);
		for(int i=0,t=sc.nextInt();i<t;++i){
			String s=sc.next();
			if(s.equals("Student"))mylist.add(new Student());
			else if(s.equals("Rockstar"))mylist.add(new Rockstar());
			else if(s.equals("Hacker"))mylist.add(new Hacker());
		}
		
		System.out.println(count(mylist));
	}
}*/



/*package example;

class BiCycle{
	String define_me(){return"a vehicle with pedals.";}
}

class MotorCycle extends BiCycle{
	String define_me(){return"a cycle with an engine.";}
	
	MotorCycle(){
		System.out.println("Hello I am a motorcycle, I am "+define_me());
		//String temp=define_me(); ~~Fix me~~
		String temp=super.define_me();
		System.out.println("My ancestor is a cycle who is "+temp);
	}
}

class Solution{
	public static void main(String[]argh){
		//MotorCycle M=new MotorCycle();
		new MotorCycle();
	}
}*///tam rb toliko prii izm toj zhe strk!



/*package example;
import java.util.Scanner;

class Sports{
	String getName(){return"Generic Sports";}
	
	void getNumberOfTeamMembers(){
		System.out.println("Each team has n players in "+getName());
	}
}

class Soccer extends Sports{
	@Override
	String getName(){return"Soccer Class";}
	// Write your overridden getNumberOfTeamMembers method here
	@Override
	void getNumberOfTeamMembers(){
		System.out.println("Each team has 11 players in "+getName());
	}
}

public class Solution{
	public static void main(String[]args){
		Sports c1=new Sports();
		Soccer c2=new Soccer();
		System.out.println(c1.getName());
		c1.getNumberOfTeamMembers();
		System.out.println(c2.getName());
		c2.getNumberOfTeamMembers();
	}
}*/



/*package example;
import java.util.Scanner;

interface AdvancedArithmetic{
	//public abstract int divisorSum(int n);
	int divisorSum(int n);
}

class MyCalculator implements AdvancedArithmetic{
	public int divisorSum(int n){
		int summa=0;
		for(int i=1;i<=n;++i)
			summa+=n%i==0?i:0;
		return summa;
	}
}

class Solution{
	//implementedInterfaceNames method takes an object and prints the name of the interfaces it implemented
	static void implementedInterfaceNames(Object o){
		for(Class anInterface:o.getClass().getInterfaces())//!
			System.out.println(anInterface.getName());
	}
	
	public static void main(String[]argh){
		MyCalculator myCalculator=new MyCalculator();//!
		System.out.print("I implemented: ");
		implementedInterfaceNames(myCalculator);
		Scanner sc=new Scanner(System.in);
		System.out.print(myCalculator.divisorSum(sc.nextInt())+"\n");
		sc.close();//!
	}
	
}*/



/*package example;
import java.util.Scanner;

abstract class Book{
	String title;
	abstract void setTitle(String s);
	String getTitle(){return title;}
}
//Write MyBook class here
class MyBook extends Book{
	public void setTitle(String line){this.title=line;}
}

public class Solution{//Main{
	public static void main(String[]args){
		//Book new_novel=new Book(); This line prHMain.java:25: error: Book is abstract; cannot be instantiated
		Scanner sc=new Scanner(System.in);
		String title=sc.nextLine();
		sc.close();//!
		MyBook new_novel=new MyBook();
		new_novel.setTitle(title);
		System.out.println("The title is: "+new_novel.getTitle());
	}
}*/



/*package example;
//Write your code here
class Arithmetic{}
//Write your code here
class Adder extends Arithmetic{
	int add(int a,int b){return a+b;}
}

public class Solution{
	public static void main(String[]args){
		// Create a new Adder object
		Adder a=new Adder();
		// Print the name of the superclass on a new line
		System.out.println("My superclass is: "+a.getClass().getSuperclass().getName());	
		// Print the result of 3 calls to Adder's `add(int,int)` method as 3 space-separated integers:
		System.out.print(a.add(10,32)+" "+a.add(10,3)+" "+a.add(10,10)+"\n");
	}
}*/



/*package example;

class Animal{
	void walk(){
		System.out.println("I am walking");
	}
}

class Bird extends Animal{
	void fly(){
		System.out.println("I am flying");
	}
	
	void sing(){
		System.out.println("I am singing");
	}
}

//class Songbird extends Bird{
//	void sing(){
//		System.out.println("I am singing");
//	}
//}

public class Solution{
	public static void main(String[]args){
		Bird bird=new Bird();
		bird.walk();
		bird.fly();
		bird.sing();
	}
}*/



/*package example;
import java.util.Scanner;
import java.util.ArrayDeque;
import java.util.Arrays;

public class Solution{//Test{
	public static void main(String[]args){
		Scanner fromTheInput=new Scanner(System.in);
		
		int
				totalNumberOfTheItems=fromTheInput.nextInt(),
				sizeOfTheSubarrays=fromTheInput.nextInt();fromTheInput.nextLine();
		
		Integer[]data=new Integer[totalNumberOfTheItems];
		int i=0;
		for(String token:fromTheInput.nextLine().split("\\s"))
			data[i++]=Integer.valueOf(token);
		
		fromTheInput.close();
		
		int greatestNumberOfUniqueItems,
				numberOfUniqueItemsOfTheCurrentSubarray=1;
		boolean earlyAnswerIsNotMade;
		
		int[]primitiveFirstSubarray=new int[sizeOfTheSubarrays];
		for(i=0;i<sizeOfTheSubarrays;++i)
			primitiveFirstSubarray[i]=data[i];
		
		Arrays.sort(primitiveFirstSubarray);
		for(i=1;i<sizeOfTheSubarrays;++i)
			if(primitiveFirstSubarray[i-1]!=primitiveFirstSubarray[i])
				++numberOfUniqueItemsOfTheCurrentSubarray;
		
		greatestNumberOfUniqueItems=numberOfUniqueItemsOfTheCurrentSubarray;
		earlyAnswerIsNotMade=greatestNumberOfUniqueItems<sizeOfTheSubarrays;
		
		ArrayDeque<Integer>queue=new ArrayDeque<>(sizeOfTheSubarrays);
		for(i=0;earlyAnswerIsNotMade&&i<sizeOfTheSubarrays;++i){
			queue.addFirst(data[i]);
		}
		
		Integer newItem;
		for(i=sizeOfTheSubarrays;
				earlyAnswerIsNotMade&&i<totalNumberOfTheItems;++i){
			numberOfUniqueItemsOfTheCurrentSubarray-=
					queue.contains(queue.removeLast())?
						0
					:1;
			
			newItem=data[i];
			
			numberOfUniqueItemsOfTheCurrentSubarray+=queue.contains(newItem)?
					0
				:1;
			
			queue.addFirst(newItem);
			
			if(numberOfUniqueItemsOfTheCurrentSubarray>greatestNumberOfUniqueItems)
				greatestNumberOfUniqueItems=numberOfUniqueItemsOfTheCurrentSubarray;
			earlyAnswerIsNotMade=greatestNumberOfUniqueItems<sizeOfTheSubarrays;
		}
		
		System.out.println(greatestNumberOfUniqueItems);
	}
}*/



/*package example;

import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class Student{
	private int id;
	private String fname;
	private double cgpa;
	
	public Student(int id,String fname,double cgpa){
		//super();//!
		this.id=id;
		this.fname=fname;
		this.cgpa=cgpa;
	}
	
	
	public int getId(){
		return id;
	}
	
	public String getFname(){
		return fname;
	}
	
	public double getCgpa(){
		return cgpa;
	}
}
//Complete the code
class Checker implements Comparator<Student>{//!
	private final int order;
	
	private Checker(int anOrder){
		order=anOrder;
	}
	
	static final Checker
			asc=new Checker(1),
			desc=new Checker(-1);
	
	Checker(){
		order=0;
	}
	
	
	private int innerCompare(Student firstStudent,Student secondStudent){
		double difference=firstStudent.getCgpa()-secondStudent.getCgpa();
		if(difference!=0.0)
			return
					difference>0.0?
						1
					:-1;
		else{// if(==)
			int fruitOfTheComparing=firstStudent.getFname().compareTo(secondStudent.getFname());
			return
					fruitOfTheComparing!=0?
						!(fruitOfTheComparing>0)?//!!
							1
						:-1
					:firstStudent.getId()-secondStudent.getId()>0?
						1
					:-1;
		}
	}
	
	public int compare(Student firstStudent,Student secondStudent){
		return order*innerCompare(firstStudent,secondStudent);
	}
}

public class Solution{
	public static void main(String[]args){
		Scanner in=new Scanner(System.in);
		int testCases=Integer.parseInt(in.nextLine());
		boolean permission=testCases>=2&&testCases<=1e3;//!
		
		List<Student>studentList=new ArrayList<>();
		while(testCases>0){
			int id=in.nextInt();
			String fname=in.next();
			double cgpa=Double.parseDouble(in.next());//!
			int lengthOfTheFname=fname.length();//!
			permission&=id>=0&&id<=1e5//!
					&&lengthOfTheFname>=4&&lengthOfTheFname<=30//!an error in the task: 5->4;
					&&cgpa>=0.0&&cgpa<=4.0;
			if(!permission){//!
				System.out.println("This data is not permitted!");
				break;
			}
			
			Student st=new Student(id,fname,cgpa);
			studentList.add(st);
			
			testCases--;
		}
		
		in.close();//!
		
		Collections.sort(studentList,new Checker().desc);//!
		
		for(Student st:studentList){
			System.out.println(st.getFname());
		}
	}
}*/



/*package example;

import java.io.*;
import java.util.*;

class Checker implements Comparator<Player>{
	private final int order;
	
	private Checker(int anOrder){
		order=anOrder;
	}
	
	static final Checker
			asc=new Checker(1),
			desc=new Checker(-1);
	
	Checker(){
		order=0;
	}
	
	
	private int innerCompare(Player firstPlayer,Player secondPlayer){
		if(firstPlayer.score>secondPlayer.score)
			return 1;
		else if(firstPlayer.score<secondPlayer.score)
			return -1;
		else// if(==)
			return firstPlayer.name.compareTo(secondPlayer.name);
	}
	
	public int compare(Player firstPlayer,Player secondPlayer){
		return order*innerCompare(firstPlayer,secondPlayer);
	}
}

class Player{
	String name;
	int score;
}

public class Solution{
	public static void main(String[]args)throws NumberFormatException,IOException{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		int n=Integer.parseInt(br.readLine().trim());
		String s;
		StringTokenizer st;//!
		Player[]player=new Player[n];
		Checker check=new Checker();
		for(int i=0;i<n;++i){
			s=br.readLine().trim();
			st=new StringTokenizer(s);
			player[i]=new Player();
			player[i].name=st.nextToken();//!
			player[i].score=Integer.parseInt(st.nextToken());//!
		}
		
		Arrays.sort(player,check.desc);
		for(int i=0;i<player.length;++i)
			System.out.printf("%s %s\n",player[i].name,player[i].score);
	}
}*///rb!



/*package example;
//import java.io.IOException;
import java.lang.reflect.Method;

class Printer{
	//Write your code here
	<T>void printArray(T[]arrayOfTClassInstances){
		for(T item:arrayOfTClassInstances)
			System.out.println(item);
	}
}

public class Solution{
	public static void main(String[]args){
		Printer myPrinter=new Printer();
		Integer[]intArray={1,2,3};
		String[]stringArray={"Hello","World"};
		myPrinter.printArray(intArray);
		myPrinter.printArray(stringArray);
		int count=0;
		String name;//!mj.
		for(Method method:Printer.class.getDeclaredMethods()){//!vzh
			//String name=method.getName();//!- u-dl-l:
			name=method.getName();//!mj.
			if(name.equals("printArray"))
				count++;
		}
		
		if(count>1)System.out.println("Method overloading is not allowed!");
		assert count==1;//!dlia ''JUnit
	} 
}*/



/*package example;
import java.util.Scanner;
import java.util.ArrayList;

class Solution{
	public static void main(String[]args){
		//Enter your code here. Read input from STDIN. Print output to STDOUT.
		//Your class should be named Solution.
		ArrayList<Integer>subarray;
		ArrayList<ArrayList<Integer>>array=new ArrayList<>();
		int
				numberOfTheLines,numberOfItemsOfTheLine,
				totalNumberOfIntegersInTheAllLines,
				numberOfTheQueries,valueOfTheRowOfTheQuery,valueOfTheColumnOfTheQuery,
				sizeOfTheArray;
		boolean permission;
		
		try(Scanner fromTheInput=new Scanner(System.in)){
			for(numberOfTheLines=fromTheInput.nextInt(),
					permission=numberOfTheLines>=1&&numberOfTheLines<=2e4,
					totalNumberOfIntegersInTheAllLines=0;
					permission&&numberOfTheLines>0;--numberOfTheLines){
				numberOfItemsOfTheLine=fromTheInput.nextInt();
				permission&=numberOfItemsOfTheLine>=0&&numberOfItemsOfTheLine<=5e4;
				if(permission){
					totalNumberOfIntegersInTheAllLines+=numberOfItemsOfTheLine;
					permission&=totalNumberOfIntegersInTheAllLines<=1e5;
					if(permission){
						subarray=new ArrayList<>();
						for(;numberOfItemsOfTheLine>0;--numberOfItemsOfTheLine)
							subarray.add(fromTheInput.nextInt());
						array.add(subarray);
					}
				}
			}
			
			sizeOfTheArray=array.size();
			for(numberOfTheQueries=fromTheInput.nextInt(),
					permission&=numberOfTheQueries>=1&&numberOfTheQueries<=1e3;
					permission&&numberOfTheQueries>0;--numberOfTheQueries){
				valueOfTheRowOfTheQuery=fromTheInput.nextInt();
				if(valueOfTheRowOfTheQuery>0&&valueOfTheRowOfTheQuery<=sizeOfTheArray){
					valueOfTheColumnOfTheQuery=fromTheInput.nextInt();
					subarray=array.get(valueOfTheRowOfTheQuery-1);
					if(valueOfTheColumnOfTheQuery>0&&valueOfTheColumnOfTheQuery<=subarray.size()){
						System.out.println(subarray.get(valueOfTheColumnOfTheQuery-1));
					}else
						System.out.println("ERROR!");
				}else{
					fromTheInput.next();
					System.out.println("ERROR!");
				}
			}
		}catch(Exception unusualCase){
			System.out.println("Exception:"+unusualCase);
		}
	}
}*///!rb



/**package example;

//import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.regex.Pattern;
import java.util.HashSet;

public class Solution{
	public static void main(String[]args){
		**//* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. *//**
		HashSet<String>set=new HashSet<>();
		Pattern pattern=Pattern.compile("^[a-z]{1,5}\\s[a-z]{1,5}$");//"^([a-z]{1,5})\\s\\1$");
		String nextLine;
		boolean permission;//,itIsAddedInTheSet;
		int
				index,
				numberOfTheItemsInTheSet=0;
		try(BufferedReader fromTheBufferOfTheInputStream=new BufferedReader(new InputStreamReader(System.in))){
			for(index=Integer.parseInt(fromTheBufferOfTheInputStream.readLine()),
					permission=index>=1&&index<=1e5;permission&&index>0;--index){
				nextLine=fromTheBufferOfTheInputStream.readLine();
				
				permission=pattern.matcher(nextLine).matches();
			//	System.out.println("for:pattern:if:"+permission);
				if(permission){
					if(set.add(nextLine))
						++numberOfTheItemsInTheSet;
					System.out.println(numberOfTheItemsInTheSet);
				}
			}
		}catch(IOException|NumberFormatException unusualCase){
			System.out.println("Exception:"+unusualCase);
		}
	}
}**/
/*
5
john tom
john mary
john tom
mary anna
mary anna
*/



/*package example;

import java.util.Scanner;
import java.util.ArrayDeque;
//import java.util.ArrayList;

class Solution{
	private static boolean isItAnClosingBracket(char sign){
		return sign==')'||sign==']'||sign=='}';
	}
	
	private static char mirrorInAnOpeningBracketOfTheSameKind(char sign){
		return
				sign==')'?
					'('
				:sign==']'?
					'['
				:'{';
	}
	
	public static void main(String[]argh){
		Scanner fromTheInput=new Scanner(System.in);
		
		String token;
		char sign;
		boolean answer;
		
		ArrayDeque<Character>stack=new ArrayDeque<>();
	//	ArrayList<Boolean>allAnswers=new ArrayList<>();
		
		int i,indexOfTheLastSign;
		
		while(fromTheInput.hasNextLine()){//hasNext()){
			token=fromTheInput.nextLine();//next();
			if(token.isEmpty())
				break;//!in. z-''loop...
		//	System.out.println("1)the token:"+token);
			//if(token.equals(""))//token.isEmpty())
				//break;
			
			indexOfTheLastSign=token.length()-1;
			sign=token.charAt(indexOfTheLastSign);
		//	System.out.println("the last sign(i="+indexOfTheLastSign+"):"+sign);
			
			answer=isItAnClosingBracket(sign)&&!isItAnClosingBracket(token.charAt(0));
		//	System.out.println("the first permitting condition:"+answer);
			if(answer)
				stack.push(sign);
			//one item is even in the stack now:
			for(i=indexOfTheLastSign-1;answer&&i>=0;--i){
		//		System.out.println("for{(i="+i+")");
				sign=token.charAt(i);
		//		System.out.println("the current sign:"+sign);
				
				if(isItAnClosingBracket(sign)){
					stack.push(sign);
		//			System.out.println("push the sign:"+sign);
				}else// if(!isItAnClosingBracket)
					if(stack.isEmpty())
						answer=false;
					else
						if(sign==mirrorInAnOpeningBracketOfTheSameKind(stack.peek())){
		//					System.out.println("remove the sign:"+stack.peek());
							stack.remove();
						}else{
							answer=false;
							stack.clear();
						}
		//		System.out.println("}for\n");
			}
			
			if(answer){
				answer=stack.isEmpty();
		//		System.out.println("stack.isEmpty():"+answer);
				if(!answer)
					stack.clear();
			}
			
			System.out.println(answer);
	//		allAnswers.add(answer);
		}
		fromTheInput.close();
		
	//	for(boolean oneAnswer:allAnswers)
	//		System.out.println(oneAnswer);
	}
}*/
/*
()([{}[]]{})[]
*/



/*package example;
//complete this code or write your own from scratch:
import java.util.Scanner;
import java.util.regex.Pattern;
//import java.util.regex.Matcher;
import java.util.HashMap;

class Solution{
	public static void main(String[]argh){
		Pattern
				patternOfNames=Pattern.compile("^[a-z]+(\\s[a-z]+)?$"),//"^([a-z]+)(\\s\\1)?$"),
				patternOfPhones=Pattern.compile("^[1-9]\\d{7}$");//"^[\\d&&[^0]]\\d{7}$");
		HashMap<String,Integer>namesAndPhones=new HashMap<>();
		String name,phone;
		Integer phoneNumber;
		boolean permission;
		
		Scanner fromTheInput=new Scanner(System.in);
		int numberOfThePairsOfLines=Integer.parseInt(fromTheInput.nextLine());
	///	System.out.println("\n!"+numberOfThePairsOfLines);
	//	fromTheInput.nextLine();
		permission=numberOfThePairsOfLines>=1&&numberOfThePairsOfLines<=1e5;
		for(int i=0;permission&&i<numberOfThePairsOfLines;++i){
			name=fromTheInput.nextLine();
		//	int phone=fromTheInput.nextInt();
		//	fromTheInput.nextLine();
			phone=fromTheInput.nextLine();
	///		System.out.println("!"+name+"="+phone);
			permission=patternOfNames.matcher(name).matches()
					&&patternOfPhones.matcher(phone).matches();
			if(permission){
				phoneNumber=Integer.parseInt(phone);
				namesAndPhones.put(name,phoneNumber);
			}else
				System.out.println("Some or all data is not permitted!");
		}
		
		int numberOfQueries=1;
		while(permission&&fromTheInput.hasNext()){
			name=fromTheInput.nextLine();
			if(namesAndPhones.containsKey(name))
				System.out.println(name+"="+namesAndPhones.get(name));
			else
				System.out.println("Not found");
			
			permission=++numberOfQueries<=1e5;
		}
		
		fromTheInput.close();
	}
}*/
/*
3
uncle sam
99912222
tom
11122222
harry
12299933
uncle sam
uncle tom
harry
 */



/*package example;

public class Solution{
	public static void main(String[]args){
		boolean permission=true;
		
		java.util.Scanner input=new java.util.Scanner(System.in);
		int[][]array=new int[6][6];
		for(int j=0,i;permission&&j<6;++j)
			for(i=0;permission&&i<6;++i){
				array[j][i]=input.nextInt();
				permission=array[j][i]>=-9&&array[j][i]<=9;
			}
		input.close();
		
		if(permission){
			int[][]hourglassArray=new int[3][];
			hourglassArray[0]=new int[3];
			hourglassArray[1]=new int[1];
			hourglassArray[2]=new int[3];
			
			int
					jIndexOfTheUpperLeftAngleOfTheHourglass=0,
					iIndexOfTheUpperLeftAngleOfTheHourglass,j,i,currentSum,
					greatestSum=-9*6;
			do{
				iIndexOfTheUpperLeftAngleOfTheHourglass=0;
				do{
					for(j=0;j<3;++j)
						if(j!=1)
							for(i=0;i<3;++i)
								hourglassArray[j][i]
										=array[jIndexOfTheUpperLeftAngleOfTheHourglass+j]
												[iIndexOfTheUpperLeftAngleOfTheHourglass+i];
						else
							hourglassArray[j][0]
									=array[j+jIndexOfTheUpperLeftAngleOfTheHourglass]
											[0+iIndexOfTheUpperLeftAngleOfTheHourglass+1];
					
					for(j=0,currentSum=0;j<3;++j)
						if(j!=1)
							for(i=0;i<3;++i)
								currentSum+=hourglassArray[j][i];
						else
							currentSum+=hourglassArray[j][0];
					
					if(jIndexOfTheUpperLeftAngleOfTheHourglass==0
							&&iIndexOfTheUpperLeftAngleOfTheHourglass==0)
						greatestSum=currentSum;
					else if(currentSum>greatestSum)
						greatestSum=currentSum;
				}while(++iIndexOfTheUpperLeftAngleOfTheHourglass<=6-3);
			}while(++jIndexOfTheUpperLeftAngleOfTheHourglass<=6-3);
			
			System.out.println(greatestSum);
		}else
			System.out.println("Invalid data!");
	}
}*/



/**package example;//eto prv-l.uz!

public class Solution{
	private static final class Data{
		static int[]jump;
		static int[][]path;
		static boolean permission;
		
		private static void receiveTheData(){
			java.util.Scanner inputStream=new java.util.Scanner(System.in);
			
			int numberOfTheTestCases=inputStream.nextInt();
			jump=new int[numberOfTheTestCases];
			path=new int[numberOfTheTestCases][];
			for(int j=0,i;j<numberOfTheTestCases;++j){///,i
				int numberOfTheItemsOfTheArray=inputStream.nextInt();
				jump[j]=inputStream.nextInt();
				path[j]=new int[numberOfTheItemsOfTheArray];
				for(/*int *//**i=0;i<numberOfTheItemsOfTheArray;++i)///int
					path[j][i]=inputStream.nextInt();
			}
			
			inputStream.close();
		}
		
		private static void issueThePermission(){
			permission=Data.path.length>=1&&Data.path.length<=5e3;
			if(!permission)
				System.out.println("Data(the number of the tast cases) is out of boundaries!");
			for(int j=0;permission&&j<Data.path.length;++j){
				permission=Data.path[j].length>=2&&Data.path[j].length<=100
						&&Data.jump[j]>=0&&Data.jump[j]<=100;
				if(!permission)
					System.out.println("Data(the number of the parts(a 0 or a 1) of path["+j+"] or\n"
							+"the value of jump["+j+"]) is out of boundaries!");
				
				permission&=Data.path[j][0]==0;
				if(!permission)
					System.out.println("Data(the value of part[0] of path["+j
							+"]) is out of boundaries([0])!");
				for(int i=1;permission&&i<Data.path[j].length;++i){
					permission=Data.path[j][i]==0||Data.path[j][i]==1;
					if(!permission)
						System.out.println("Data(the value of part["+i+"] of path["+j
								+"]) is out of boundaries([0,1])!");
				}
			}
		}
		
		static{
			receiveTheData();
			issueThePermission();
		}
	}
	
	private static final class EData{
		static int[]jump;
		static int[][]path;
		
		private static void transferTheUnimprovablePartOfTheData(){
			jump=new int[Data.jump.length];
			path=new int[Data.path.length][];
		}
		
		private static void makeTheJumpEffective(){
			for(int j=0;j<jump.length;++j)
				jump[j]=Data.jump[j]>1?Data.jump[j]:-1;
		}
		
		private static void makeThePathEffective(){
			for(int j=0,firstIndexOfTheNothingOrOfZeroEnd;j<path.length;++j){
				for(firstIndexOfTheNothingOrOfZeroEnd=Data.path[j].length;
						firstIndexOfTheNothingOrOfZeroEnd>1
						&&Data.path[j][firstIndexOfTheNothingOrOfZeroEnd-1]==0;
						--firstIndexOfTheNothingOrOfZeroEnd){};
				path[j]=new int[firstIndexOfTheNothingOrOfZeroEnd];
				for(int i=0;i<firstIndexOfTheNothingOrOfZeroEnd;++i)
					path[j][i]=Data.path[j][i];
			}
		}
		
		
		private static int whatIsTheIndexOfFirstZeroInThisMultipleSequenceOfZerosHere(
				int j,int indexOfLastZero){
			int indexOfFirstZero=indexOfLastZero-1;
			for(;indexOfFirstZero>1//0 is first in every path
					&&EData.path[j][indexOfFirstZero-1]==0;
					--indexOfFirstZero){};
		//	System.out.println("whatIsTheIndexOfFirstZeroInThisMultipleSequenceOfZerosHere(i="
		//	+indexOfLastZero+"):"+indexOfFirstZero);
			return indexOfFirstZero;
		}
		
		private static void closeTheZerosOfTraps(){
			boolean itIsATrapSequence;
			//po psld.sltc(570 v ''Excel):
			for(int j=0,i,k,indexOfFirstZero;j<EData.path.length;++j)
				if(EData.path[j].length>4
						&&EData.jump[j]>1&&EData.jump[j]<EData.path[j].length-2)
					for(i=EData.path[j].length-1-EData.jump[j];i>0;--i)///{//i>1;--i)//{
				//		System.out.println("1)i:"+i);
				//	}
						if(EData.path[j][i]==0
								&&EData.path[j][i+1]==1
								&&EData.path[j][i+EData.jump[j]]==1)//the last item equals to 1 in all cases
							if(EData.path[j][i-1]==1)
								EData.path[j][i]=1;
							else{// if(EData.path[j][i-1]==0)
								indexOfFirstZero
										=whatIsTheIndexOfFirstZeroInThisMultipleSequenceOfZerosHere(j,i);
										//except for first Zero as One
								for(k=indexOfFirstZero>0?indexOfFirstZero:++indexOfFirstZero,
										itIsATrapSequence=true;
										itIsATrapSequence&&k<i;++k)//{//v ''i ''true is.
									itIsATrapSequence=EData.path[j][k+EData.jump[j]]==1;
					//				System.out.println(k+")"+itIsATrapSequence);
					//			}
					//			System.out.println("itIsATrapSequence:"+itIsATrapSequence);
								if(itIsATrapSequence)//{
					//				System.out.println("itIsATrapSequence:["+indexOfFirstZero+","+i+"]");
									for(k=indexOfFirstZero>0?indexOfFirstZero:++indexOfFirstZero;
											k<=i;++k)//first - 0
										EData.path[j][k]=1;
					//			}
							}
		}
		
		
		static{
			transferTheUnimprovablePartOfTheData();
			makeTheJumpEffective();
			makeThePathEffective();
			
		//	System.out.println("The data is made effective:");
		//	for(int j=0;j<path.length;++j){
		//		System.out.println(jump[j]);
				
		//		for(int i=0;i<path[j].length;++i)
		//			System.out.print(path[j][i]+" ");
				
		//		System.out.println();
		//	}
			
			closeTheZerosOfTraps();
			
		//	System.out.println("The effective path data after closed the zeros of traps:");
		//	for(int j=0;j<path.length;++j){
		//		for(int i=0;i<path[j].length;++i)
		//			System.out.print(path[j][i]+" ");
				
		//		System.out.println();
		//	}
		}
	}
	
	
	
	private int currentPosition=0;
	
	
	
//	private boolean isCurrentPositionPermitted(int j){
//		return currentPosition>=0&&currentPosition<EData.path[j].length;
//	}
	
	
	private static boolean haveITheJump(int j){
	//	System.out.println("haveITheJump");
		return EData.jump[j]!=-1;
	}
	
	private static boolean haveITheWinningJump(int j){
	//	System.out.println("haveITheWinningJump");
		return EData.jump[j]>=EData.path[j].length;
	}
	
	
	private boolean isItZeroBefore(int j){
	//	System.out.println("isItZeroBefore");
		return EData.path[j][currentPosition+1]==0;
	}
	
	private boolean isItZeroBehind(int j){
	//	System.out.println("isItZeroBehind");
		return
				currentPosition>0?
					EData.path[j][currentPosition-1]==0
				:false;
	}
	
	
	private int whatIsTheIndexOfZeroOrOfTheEndBeforeThisSequenceOfOnes(int j){
		int indexOfZeroBeforeThisSequenceOfOnes=currentPosition+2;
		for(;indexOfZeroBeforeThisSequenceOfOnes<EData.path[j].length
				&&EData.path[j][indexOfZeroBeforeThisSequenceOfOnes]!=0;
				++indexOfZeroBeforeThisSequenceOfOnes){};
	//	System.out.println("whatIsTheIndexOfZeroOrOfEndBeforeThisSequenceOfOnes:"
	//			+indexOfZeroBeforeThisSequenceOfOnes);
		return indexOfZeroBeforeThisSequenceOfOnes;
	}
	
	private int canIJumpOverThisSequenceOfOnesOrOverMoreFromHere(int j){
		int positionOfTheLanding=currentPosition+EData.jump[j];
	//	if(positionOfTheLanding<EData.path[j].length
	//			&&positionOfTheLanding!=EData.path[j].length-1)
	//		System.out.println("canIJumpOverThisSequenceOfOnesOrOverMoreFromHere:");
	//	else
	//		System.out.println("canIJumpOverThisSequenceOfOnesOrOverMoreFromHere");
		return
				positionOfTheLanding<EData.path[j].length?
					positionOfTheLanding!=EData.path[j].length-1?
						positionOfTheLanding>=whatIsTheIndexOfZeroOrOfTheEndBeforeThisSequenceOfOnes(j)
								&&EData.path[j][positionOfTheLanding]==0?
							1
						:0
					:0
				:-3;
	}
	
	
	
	int imaginaryPositionOfTheLandingAfterTheSuccessfulImaginaryCleverJump;
	
	
	private boolean canICleverlyJumpOverThisSequenceOfOnesOrMore(int j){
	//	System.out.println("canICleverlyJumpOverThisSequenceOfOnesOrMore{");
	//	System.out.println("if-condition{");
		if(isItZeroBehind(j)
				&&whatIsTheIndexOfZeroOrOfTheEndBeforeThisSequenceOfOnes(j)<currentPosition+EData.jump[j]){
	//		System.out.println("}if-condition");
			boolean iCanNotJumpOver;
			int realPosition=currentPosition;
			do{
				--currentPosition;
	//			System.out.println("an imaginary step back:"+currentPosition);
				iCanNotJumpOver=canIJumpOverThisSequenceOfOnesOrOverMoreFromHere(j)==0;
	//			System.out.println("do-while-condition:");
			}while(isItZeroBehind(j)&&iCanNotJumpOver);
			if(!iCanNotJumpOver)
				imaginaryPositionOfTheLandingAfterTheSuccessfulImaginaryCleverJump
						=currentPosition+EData.jump[j];
			currentPosition=realPosition;
	//		System.out.println("}canICleverlyJumpOverThisSequenceOfOnesOrMore:"+!iCanNotJumpOver);
			return !iCanNotJumpOver;
		}else
			return false;
	}
	
	
	private void stepForth(int j){
	//	System.out.println("stepForth");
		++currentPosition;
	}
	
	private void jumpForth(int j){
	//	System.out.println("jumpForth");
		currentPosition+=EData.jump[j];
	}
	
	private void cleverlyJumpForth(int j){
	//	System.out.println("cleverlyJumpForth");
		currentPosition=imaginaryPositionOfTheLandingAfterTheSuccessfulImaginaryCleverJump;
	}
	
	
	private static void answer(boolean itIsAWin){
	//	System.out.println("\nanswer:");
		if(itIsAWin)
			System.out.println("YES");
		else
			System.out.println("NO");
	}
	
	
	
	private boolean itIsAWin,itIsALoss;
	
	
	
	Solution(int j){
	//	System.out.println("constructor{");
		itIsAWin=EData.path[j].length==1
				||haveITheWinningJump(j);
		itIsALoss=
				!itIsAWin?
					!haveITheJump(j)&&EData.path[j].length>1
				:false;
	//	System.out.println("}constructor");
	}
	
	
	private void playGame(int j){
	//	System.out.println("playGame("+j+"){");
		while(!itIsAWin&&!itIsALoss){
	//		System.out.println("playGame("+j+"):while{");
			if(isItZeroBefore(j))
				stepForth(j);
			else{
				int iCanJumpOver=canIJumpOverThisSequenceOfOnesOrOverMoreFromHere(j);
				if(iCanJumpOver==-3)
					itIsAWin=true;
				else if(iCanJumpOver==1)
					jumpForth(j);
				else if(iCanJumpOver==0)
					if(canICleverlyJumpOverThisSequenceOfOnesOrMore(j))
						cleverlyJumpForth(j);
					else
						itIsALoss=true;
			}
	//		System.out.println("}playGame("+j+"):while");
		}
	//	System.out.println("the end current position:"+currentPosition);
		answer(itIsAWin);
	//	System.out.println("}playGame("+j+")");
	}
	
	
	public static void main(String[]args){ 
		if(Data.permission)
			for(int j=0;j<EData.path.length;++j)
				new Solution(j).playGame(j);
		else
			System.out.print("The games are not created.");
	}
}**/



/**package example;

//import java.io.*;
import java.util.Scanner;
//import java.text.*;
//import java.math.*;
//import java.util.regex.*;

public class Solution{
	public static void main(String[]args) {
		**//* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. *//**
		Scanner inputStream=new Scanner(System.in);
		
		int
				i,
				n=inputStream.nextInt();
		int[]numberWithAnIndex=new int[n];
		for(i=0;i<n;++i)
			numberWithAnIndex[i]=inputStream.nextInt();
		
		inputStream.close();
		
		//for(i=0;i<n;++i)
			//System.out.println(numberWithAnIndex[i]);
		
		int numberOfNegativeSubarrays=0;
		for(i=0;i<n;++i)
			//if(i<0)
				//++numberOfNegativeSubarrays;
			for(int j=i,totalNumber=0;j<n;++j){
				totalNumber+=numberWithAnIndex[j];
				if(totalNumber<0)
					++numberOfNegativeSubarrays;
			}
		
		System.out.println(numberOfNegativeSubarrays);
	}
}**/



/*package example;
//!n.izm-ju ix.tcs..uz
import java.math.BigDecimal;
import java.util.*;
class Solution{

    public static void main(String []argh)
    {
        //Input
        Scanner sc= new Scanner(System.in);
        int n=sc.nextInt();
        String []s=new String[n+2];
        for(int i=0;i<n;i++)
        {
            s[i]=sc.next();
        }

        //Write your code here
        try{
        	sc.close();
        	
        	boolean permission=n<=200;
        	java.util.regex.Pattern pattern=java.util.regex.Pattern.compile("^-?\\d*\\.?\\d+$");
        	int i;
        	BigDecimal[]bigDecimalNumberWithAnIndex=new BigDecimal[n+1];//n.2 i n.''"fieldOfTheB..."
        	for(i=0;permission&&i<n;++i)
        		if(!pattern.matcher(s[i]).matches()//s[i].matches("^-?\\d*\\.\\d+$"),//^(-|\\d|\\.)\\d*\\d*$")
        				||s[i].replaceAll("[-.]","").length()>300)
        			permission=false;
        	
        	if(permission){
        		//for(i=0;i<n;++i)
        			//bigDecimalNumberWithAnIndex[i]=new BigDecimal(s[i]);
        		
        		int j;
        		for(i=0;i<n;++i){
        			bigDecimalNumberWithAnIndex[i]=new BigDecimal(s[i]);
        			//System.out.println("!"+bigDecimalNumberWithAnIndex[i]);
        			for(j=i;j>0&&bigDecimalNumberWithAnIndex[j].compareTo(bigDecimalNumberWithAnIndex[j-1])>0;--j){
        				bigDecimalNumberWithAnIndex[n]=bigDecimalNumberWithAnIndex[j-1];
        				s[n]=s[j-1];
        				bigDecimalNumberWithAnIndex[j-1]=bigDecimalNumberWithAnIndex[j];
        				s[j-1]=s[j];
        				bigDecimalNumberWithAnIndex[j]=bigDecimalNumberWithAnIndex[n];
        				s[j]=s[n];
        			}
        		}
        		
        		//for(i=0;i<n;++i)
        			//s[i]=bigDecimalNumberWithAnIndex[i].toPlainString();
        	}
        	//if(n<=200&&)
        }catch(Exception signOfAnException){
        	System.out.println(signOfAnException);
        }
        
        //Output
        for(int i=0;i<n;i++)
        {
            System.out.println(s[i]);
        }

    }


}*/



/**package example;

import java.util.Scanner;
import java.util.regex.Pattern;
import java.math.BigInteger;

public class Solution{
	public static void main(String[]args){
		**//* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. *//**
		Scanner inputStream=new Scanner(System.in);
		
		String[]stringWithAnIndex=new String[2];
		BigInteger[]bigIntegerNumberWithAnIndex=new BigInteger[2];
		boolean[]permission=new boolean[2];
		Pattern pattern=Pattern.compile("^\\d+$");
		//Pattern pattern2=Pattern.compile("^0+([//d[^0]]//d*)$");
		for(int i=0;i<2;++i){
			stringWithAnIndex[i]=inputStream.nextLine();
			permission[i]=stringWithAnIndex[i].length()<=200
					&&pattern.matcher(stringWithAnIndex[i]).matches();
			if(permission[i]){
				stringWithAnIndex[i]=stringWithAnIndex[i].replaceFirst("^0+","");
				//if(pattern2.matcher(stringWithAnIndex[i]).matches())
				if(stringWithAnIndex[i].isEmpty())
					stringWithAnIndex[i]="0";
				
				bigIntegerNumberWithAnIndex[i]=new BigInteger(stringWithAnIndex[i]);
			}
		}
		
		if(permission[0]&&permission[1])
			System.out.println(
					bigIntegerNumberWithAnIndex[0].add(bigIntegerNumberWithAnIndex[1])+"\n"
					+bigIntegerNumberWithAnIndex[0].multiply(bigIntegerNumberWithAnIndex[1])
					);
		
		inputStream.close();
	}
}**///eto rb



/*package example;

import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class Solution{
    public static void main(String[]args){
        Scanner input=new Scanner(System.in);
        
        int numberOfTestCases=Integer.parseInt(input.nextLine());
	    if(numberOfTestCases>=1&&numberOfTestCases<=100){
	    	int totalNumberOfSignsOfAllLines=0;
	        while(numberOfTestCases>=1&&totalNumberOfSignsOfAllLines<=1e6){
	            String line=input.nextLine();
	            //write your code here:
	            int numberOfSignsOfTheLine=line.length();
	            if(numberOfSignsOfTheLine<=1e4){
	            	totalNumberOfSignsOfAllLines=totalNumberOfSignsOfAllLines+numberOfSignsOfTheLine;
	            	Pattern pattern=Pattern.compile("<([^>]+)>([^<>]+)</\\1>");
	            	Matcher matcher=pattern.matcher(line);
	            	
	            	if(matcher.find()){
	            		matcher.reset();
	            		
		            	while(matcher.find()){
		            		System.out.println(matcher.group(2));
		            	}
	            	}else
	            		System.out.println("None");
	            }
	            
	            --numberOfTestCases;
	        }
	    }
	    
        input.close();
    }
}*/



/*package example;

//import java.io.*;
import java.util.Scanner;
//import java.text.*;
//import java.math.*;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class Solution{
    public static void main(String[]args){
        Scanner input=new Scanner(System.in);
        int numberOfTestCases=Integer.parseInt(input.nextLine());
        while(numberOfTestCases>0){
            String userName=input.nextLine();
            //String patternLine=Complete this line in the editable area below
            String patternLine="^[A-z]\\w{7,29}$";
            
            Pattern pattern=Pattern.compile(patternLine);
            Matcher matcher=pattern.matcher(userName);
            
            if(matcher.find())
               System.out.println("Valid");
            else
               System.out.println("Invalid");
            
            --numberOfTestCases;
        }
    }
}*/



/*package example;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Solution{//DuplicateWords{
    public static void main(String[]args){
        String patternLine="\\b([A-z]+)\\b(\\s+\\b\\1\\b)+";//!"<>" n.rb!
        Pattern pattern=Pattern.compile(patternLine,Pattern.CASE_INSENSITIVE);
        
        Scanner scanner=new Scanner(System.in);
        int numberOfTestCases=Integer.parseInt(scanner.nextLine());
        if(numberOfTestCases>=1&&numberOfTestCases<=100)
	        while(numberOfTestCases>=1){
	            String inputLine=scanner.nextLine();
	            
	            if(inputLine.length()<=10000){
		            Matcher matcher=pattern.matcher(inputLine);
		            while(matcher.find())
		                inputLine=inputLine.replaceAll(matcher.group(),matcher.group(1));
		            
		            System.out.println(inputLine);
	            }
	            
		        --numberOfTestCases;
	        }
        
        scanner.close();
    }
}*/



/*package example;
//!tut ps kl - zprt. - pr-ns nzh:
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;

class myRegex{
	String pattern="^(([01]?\\d?\\d|2[0-4]\\d|25[0-5])\\.){3}([01]?\\d?\\d|2[0-4]\\d|25[0-5])$";
}//no na " " n.rb

class Solution{
    public static void main(String[]args){
        Scanner in=new Scanner(System.in);
        while(in.hasNext()){
            String IP=in.next();
            System.out.println(IP.matches(new myRegex().pattern));
        }
        
        in.close();
    }
}*/



/*package example;

import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class Solution{
    public static void main(String[]args){
        Scanner input=new Scanner(System.in);
        int numberOfTestCases=0;
        try{
        	numberOfTestCases=Integer.parseInt(input.nextLine());
        }catch(NumberFormatException e){
        	System.out.println("Exception: "+e);
        }
        Pattern p;
        while(numberOfTestCases>0){
            String patternLine=input.nextLine();
            //write your code
            try{
            	Pattern pattern=Pattern.compile(patternLine);
            	System.out.println("Valid");
            }catch(PatternSyntaxException e){
            	System.out.println("Invalid");
            }
            
            --numberOfTestCases;
        }
        
        input.close();
    }
}*/



/*package example;//eto ps tam: nado bylo brb sltcj..''"line.equals(" ")"

//import java.io.*;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Solution{
	public static void main(String[]args){
		Scanner scanner=new Scanner(System.in);
        String line=scanner.nextLine();
        scanner.close();
        //complete the code
        int numberOfTokens;
        if(!line.isEmpty()&&Pattern.matches("^([A-Za-z\\s!,?._'@]|-){1,400000}$",line)){
        	line=line.replaceAll("([\\s!,?._'@]|-)+"," ");
        	if(line.equals(" ")){
        		line="";
        		numberOfTokens=0;
        		//System.out.println(line);
        		System.out.println(numberOfTokens);
        	}else{
        		line=line.trim();
        	//if(line.charAt(0)==' ')
        		//line=line.substring(1);
        	//while(line.charAt(0)==' '){line=line.substring(1);}
            //while(line.charAt(line.length()-1)==' '){line=line.substring(0,line.length()-1);}
        		//System.out.println(line);
	        	String[]tokensOfTheLine=line.split("\\s");
	        	numberOfTokens=tokensOfTheLine.length;
	        	System.out.println(numberOfTokens);
	        	for(String token:tokensOfTheLine)
	        		System.out.println(token);
        	}
        }else{
        	numberOfTokens=0;
        	//System.out.println(line);
        	System.out.println(numberOfTokens);
        }
	}
}*/
/*package example;//eto vr-n!(!no tct vzh)

//import java.io.*;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Solution{
	public static void main(String[]args){
		Scanner scanner=new Scanner(System.in);
        String line=scanner.nextLine();
        scanner.close();
        //complete the code
        int numberOfTokens;
        boolean lineIsEmpty=line.isEmpty();
        if(!lineIsEmpty&&Pattern.matches("^([A-Za-z\\s!,?._'@]|-){1,400000}$",line)){
        	line=line.replaceAll("([\\s!,?._'@]|-)+"," ");//.trim();
        	//if(line.charAt(0)==' ')
        		//line=line.substring(1);
        	if(!line.equals(" ")){
        		while(line.charAt(0)==' '){line=line.substring(1);}
        		while(line.charAt(line.length()-1)==' '){line=line.substring(0,line.length()-1);}
        		System.out.println(line);
            	String[]tokensOfTheLine=line.split("\\s");
            	numberOfTokens=tokensOfTheLine.length;
            	System.out.println(numberOfTokens);
            	for(String token:tokensOfTheLine)
            		System.out.println(token);
        	}else{
    			line="";
    			numberOfTokens=0;
    			System.out.println(line);
    			System.out.println(numberOfTokens);
        	}
        }else if(lineIsEmpty){
        	numberOfTokens=0;
        	System.out.println(numberOfTokens);
        }
	}
}*/



/*package example;

//import java.io.*;
import java.util.Scanner;

public class Solution{
    static boolean isAnagram(String a,String b){
        //complete the function
    	boolean fruitOfTheMethod=true;
    	if(a.length()==b.length()){
	    	a=a.toLowerCase();
	    	b=b.toLowerCase();
	    	
	    	for(int i=b.length()-1;fruitOfTheMethod&&i>=0;--i){
	    		char sign=b.charAt(i);
	    		if(a.contains(String.valueOf(sign))){
	    			int indexOfTheSignInA=a.indexOf(sign);
	    			a=a.substring(0,indexOfTheSignInA).concat(a.substring(indexOfTheSignInA+1));
	    		}else
	    			fruitOfTheMethod=false;
	    	}
    	}else
    		fruitOfTheMethod=false;
    	
    	return fruitOfTheMethod;
    }
    
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        
        if(isAnagram(sc.next(),sc.next()))
        	System.out.println("Anagrams");
        else
        	System.out.println("Not Anagrams");
        
        sc.close();
    }
}*/



/**package example;

//import java.io.*;
import java.util.Scanner;

public class Solution{
    public static void main(String[]args){
        Scanner scanner=new Scanner(System.in);
        try{
	        String line=scanner.next();
	        /* Enter your code here. Print output to STDOUT. *//**
	        if(line.equals(new StringBuffer(line).reverse().toString()))
	        	System.out.println("Yes");
	        else
	        	System.out.println("No");
        }catch(Exception signOfAnException){
        	System.out.println("Exception: "+signOfAnException);
        }finally{
        	scanner.close();
        }
    }
}**/



/**package example;

//import java.io.*;
import java.util.Scanner;
//import java.text.*;
//import java.math.*;
//import java.util.regex.*;

public class Solution{
    public static void main(String[]args){
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. *//**
    	Scanner scanner=new Scanner(System.in);
    	try{
	    	String
	    			line=scanner.nextLine(),
	    			currentSubstring="",
	    			highestSubstring="",
	    			lowestSubstring="";
	    	
	    	for(int
	    				numberOfSignsInSubstrings=scanner.nextInt(),
	    				lengthOfTheLine=line.length(),
	    				numberOfSubstrings=lengthOfTheLine-numberOfSignsInSubstrings+1,
	    				i=0;
	    			i<numberOfSubstrings;++i){
    			currentSubstring=line.substring(i,i+numberOfSignsInSubstrings);
    			//int fruitOfComparing=currentSubstring.compareTo(highestSubstring);
    			//int fruitOfComparing=currentSubstring.compareTo(lowestSubstring);
    			if(i==0)
    				highestSubstring=lowestSubstring=currentSubstring;
    			else{
    				if(currentSubstring.compareTo(lowestSubstring)<0)
    					lowestSubstring=currentSubstring;
    				if(currentSubstring.compareTo(highestSubstring)>0)
    					highestSubstring=currentSubstring;
    			}
    		}
	    	
	    	System.out.println(lowestSubstring);
	    	System.out.println(highestSubstring);
    	}catch(Exception e){
    		System.out.println("Exception: "+e);
    	}finally{
    		scanner.close();
    	}
    }
}**/



/**package example;

import java.util.*;
import java.security.*;

public class Solution{
	public static void main(String[]args){
		Do_Not_Terminate.forbidExit();
		
		try{
			Scanner in=new Scanner(System.in);
			int n=in.nextInt();
			//String s=???; Complete this line below
			//write your code here:
			in.close();
			String s=null;
			if(Math.abs(n)<=100)
				s=String.valueOf(n);
			else{
				s=String.valueOf(n%100);
				System.out.println("abs(n)>100 - this is forbidden! That is why\n"
						+ "s=String.valueOf(n%100)="+s+" now.");
			}
			//
			if(n==Integer.parseInt(s))
				System.out.println("Good job");
			else
				System.out.println("Wrong answer.");
		}catch(Do_Not_Terminate.ExitTrappedException e){
			System.out.println("Unsuccessful termination!");
		}/*finally{
			in.close();
		}*//**
	}
}
//the following class will prevent you from terminating the code using exit(0)!
class Do_Not_Terminate{
    public static class ExitTrappedException extends SecurityException{
		private static final long serialVersionUID=1L;
    }
    
    public static void forbidExit(){
        final SecurityManager securityManager=new SecurityManager(){
            @Override
            public void checkPermission(Permission permission){
                if(permission.getName().contains("exitVM"))
                    throw new ExitTrappedException();
            }
        };
        
        System.setSecurityManager(securityManager);
    }
}*/



/*package example;

//import java.io.*;
import java.util.Scanner;
//import java.text.*;
//import java.math.*;
//import java.util.regex.*;

public class Solution{
	static boolean flag=false;
	static int B,H;
	
	static{
		Scanner sc=new Scanner(System.in);
		
		B=sc.nextInt();
		H=sc.nextInt();
		
		try{
			if(B>100||H>100){
				//flag=false;
				System.out.println("Breadth and height must be less than or equal to 100");
			}else if(B<=0||H<=0)
					throw new Exception("Breadth and height must be positive");
			else
				flag=true;
		}catch(Exception e){
			System.out.println(e);
		}finally{
			if(sc!=null)
				sc.close();
		}
	}
	
	public static void main(String[]args){
		if(flag){
			int area=B*H;
			System.out.print(area);
		}
	}//end of main
}//end of class*/



/**package example;

//import java.io.*;
import java.util.Scanner;
//import java.text.*;
//import java.math.*;
//import java.util.regex.*;

public class Solution{
    public static void main(String[]args){
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. *//**
    	Scanner sc=new Scanner(System.in);
    	String line=null;
    	boolean flag=true;
    	
    	for(int k=1;flag&&sc.hasNext();++k){
    		line=sc.nextLine();
    		
    		if(line.equals("exit"))
    			flag=false;
    		else
    			System.out.println(k+" "+line);
    	}
    	
    	sc.close();
    }
}**/



/*package example;

import java.util.Scanner;
//import java.io.*;

class Solution{
    public static void main(String[]args){
    	try{
	        Scanner sc=new Scanner(System.in);
	        int numberOfTestCases=sc.nextInt();
	        
	        for(int j=0;j<numberOfTestCases;++j){
	            try{
	                long x=sc.nextLong();
	                
	                System.out.println(x+" can be fitted in:");
	                
	                if(x>=Byte.MIN_VALUE&&x<=Byte.MAX_VALUE)//-128&&x<=127)
	                	System.out.println("* byte\n* short\n* int\n* long");
	                //Complete the code
	                else if(x>=Short.MIN_VALUE&&x<=Short.MAX_VALUE)
	                	System.out.println("* short\n* int\n* long");
	                else if(x>=Integer.MIN_VALUE&&x<=Integer.MAX_VALUE)
	                	System.out.println("* int\n* long");
	                else if(x>=Long.MIN_VALUE&&x<=Long.MAX_VALUE)
	                	System.out.println("* long");
	            }catch(Exception e){
	                System.out.println(sc.next()+" can't be fitted anywhere.");
	            }
	        }
	        
	        sc.close();
    	}catch(Exception e){
            System.out.println("Exception!");
        }
    }
}*/



/*package example;

import java.util.Scanner;

public class Solution{
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        System.out.println("================================");
        for(int j=0;j<3;j++){
            String s=sc.next();
            int i=sc.nextInt();
            //Complete this line
            System.out.printf("%-15s%03d%n",s,i);
        }
        System.out.println("================================");
    }
}*/



/**package example;

//import java.io.*;
//import java.util.*;
//import java.text.*;
//import java.math.*;
//import java.util.regex.*;
import java.util.Scanner;

public class Solution{
    public static void main(String[]args){
    	try{
	        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. *//**
	    	Scanner sc=new Scanner(System.in);
	    	int numberOfRows=Integer.parseInt(sc.nextLine());
	    	String nextLine=null;
	    	String[]l=new String[numberOfRows];
	    	int[][]k=new int[numberOfRows][3];
	    	
	    	for(int j=0;j<numberOfRows;++j){
				nextLine=sc.nextLine();
				l=nextLine.split(" ");
    			for(int i=0;i<3;++i)
	    			k[j][i]=Integer.parseInt(l[i]);
	    	}
	    	
		    for(int j=0;j<numberOfRows;++j){
				int totalAmount=k[j][0];
				for(int i=0;i<k[j][2];++i){
					totalAmount=totalAmount+(int)Math.pow(2,i)*k[j][1];
					System.out.print(totalAmount);
					if(i!=k[j][2]-1)
						System.out.print(" ");
				}
	    	
				System.out.println();
	    	}
	    	
	    	sc.close();
    	}catch(Exception e){
    		System.out.println("Exception: "+e);
		}
    }
}**/



/**package example;

//import java.io.*;
//import java.util.*;
//import java.text.*;
//import java.math.*;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Scanner;

public class Solution{
    public static void main(String[]args){
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. *//**
    	Scanner sc=new Scanner(System.in);
    	//int[][]k=new int[3][3];
    	String[]
    			//p=new String[3],
    			l=new String[3];
    	String nextLine=null;;
    	int[][]k=new int[3][3];
    	//boolean[]cancel={false,false,false};
    	boolean[] permissionToProcess=new boolean[3];
    	for(int j=0;j<3;++j)
    		permissionToProcess[j]=true;
    	//if(permissionToProcess[2])System.out.println("dldskfojd");
    	Pattern p=Pattern.compile("^\\d+\\s\\d+\\s\\d+$");
    	Matcher m=null;
    	for(int j=0;j<3;++j){
    		try{
	    		//for(int j=0;j<3;++j){//i, &&ancel[j];++i){
    			//if(sc.hasNextLine()){//Int())
        			//k[j][i]=sc.nextInt();
				nextLine=sc.nextLine();
				m=p.matcher(nextLine);
    			if(m.matches())//nextLine.contains(" * "))
    				l=nextLine.split(" ");
    			else
    				permissionToProcess[j]=false;
    			/*for(String s:l)
    				System.out.print(s+" ");
    			System.out.println(permissionToProcess[j]);*//**
    			//}
    		}catch(Exception e){
	    		System.out.println("Exception: "+e);
    		}
	        		//else
	        			//cancel[j]=true;
	        		//l=p[j].split(" ");
    		for(int i=0;permissionToProcess[j]&&i<3;++i){
    			k[j][i]=Integer.parseInt(l[i]);//getInteger(l[i]);
	        			//System.out.println(l[i]);
    			//System.out.println(k[j][i]);
	        }
    	}
    	
	    for(int j=0;/*permissionToProcess[j]&&*//**j<3;++j)//{//!shb prii j vsiudu: n.vp..''"++j"
	    	if(permissionToProcess[j]){
				int totalAmount=k[j][0];
				for(int i=0;i<k[j][2];++i){
					totalAmount=totalAmount+(int)Math.pow(2,i)*k[j][1];
					System.out.print(totalAmount);
					if(i!=k[j][2]-1)
						System.out.print(" ");
				}
	    	
				System.out.println();
	    	}
    	
    	sc.close();
    }
}**/



/**package example;

//import java.util.Scanner;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

public class Solution{
    public static void main(String[]args){
        /*Scanner sc=new Scanner(System.in);
        int i=sc.nextInt();*//**
        //Complete this code
    	InputStream is=System.in;
    	InputStreamReader isr=new InputStreamReader(is);
		BufferedReader br=new BufferedReader(isr);
    	
		String nextLine=null,s=null;//,i=null,d=null;
		int i=0;
		double d=0.0;
		/*boolean f=true;
		int n=0;
		do{
			try{
				nextLine=br.readLine();
			}catch(IOException e){
				System.out.println(e);
			}
			
			++n;
			if(nextLine!=null)
				if(n==1)
					i=nextLine;
				else if(n==2)
					d=nextLine;
				else
					s=nextLine;
			else
				f=false;
		}while(f);*//**
		for(int n=0;n<3;++n){
			try{
				nextLine=br.readLine();
			}catch(IOException e){
				System.out.println(e);
			}
			
			if(nextLine!=null)
				if(n==0)
					i=Integer.valueOf(nextLine);
				else if(n==1)
					d=Double.valueOf(nextLine);
				else
					s=nextLine;
			else
				break;
		};
		
		try{
			br.close();
			isr.close();
			//is.close();
		}catch(IOException e){
			System.out.println("Can not close the streams: "+e);
		}
		
        System.out.println("String: "+s);
        System.out.println("Double: "+d);
        System.out.println("Int: "+i);
    }
}**/



/**package example;

//import java.io.*;
import java.util.*;
//import java.text.*;
//import java.math.*;
//import java.util.regex.*;

public class Solution{
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        String ans="";
        
        if(n>=1&&n<=100)
        	if(n%2==1||n>=6&&n<=20)
        		ans="Weird";
        	else// if(n>=2&&n<=4||n>21)
        		ans="Not Weird";
        	**//*//else
        		//Complete the code
        	else if(n>=2&&n<=4)//5)
        		ans="Not Weird";
        	else if(n>=6&&n<=20)
        		ans="Weird";
        	else if(n>21)//20)
        		ans="Not Weird";*//**
        
        System.out.println(ans);
        
        sc.close();
    }
}**/



/****package example;

//import java.util.*;
import java.util.Scanner;

class myCalculator{
    String power(double a,double b){
    	try{
        	if(a<0||b<0)
        		throw new Exception("n and p should be non-negative");
        	return String.valueOf((long)Math.pow(a,b));
        }catch(Exception e){
        	return e.toString();
        }
    }
}

class Solution{
    public static void main(String[]argh){
        Scanner in=new Scanner(System.in);
        
        while(in.hasNextInt()){
            int n=in.nextInt();
            int p=in.nextInt();
            myCalculator M=new myCalculator();
            
            try{
                System.out.println(M.power(n,p));
            }catch(Exception e){
                System.out.println(e);
            }
        }
    }
}****/



/***package example;
//Write your code here
//import java.util.*;
import java.lang.Math;
import java.util.Scanner;

abstract class MyCalculator{
    static double power(double a,double b){
        	return Math.pow(a,b);
    }
    /*
    static boolean areIntegralNumbersHere(double a,double b){
    	if((double)Math.round(a)==a&&(double)Math.round(b)==b)
    		return true;
    	else
    		return false;
    }
    *//***
}

class Solution{
    public static void main(String[]args){
        Scanner in = new Scanner(System.in);
        //MyCalculator m = new MyCalculator();
        
        //try{
        while(in.hasNextInt()){
        	int
                    n = in.nextInt(),
                    p = in.nextInt();
        	
            try{
            	if(n<0||p<0)
            		throw new Exception("n and p should be non-negative");
            	else// if(MyCalculator.areIntegralNumbersHere(n,p))
            		System.out.println(Math.round(MyCalculator.power(n,p)));
            	/*else
            		System.out.println(MyCalculator.power(n,p));*//***
            }catch(Exception e){
            	System.out.println(e);
            }/*finally{
            	in.close();
            }*//***
        }
        
        in.close();
    }
}***/


/**package example;

//import java.io.*;
import java.util.*;
//import java.text.*;
//import java.math.*;
//import java.util.regex.*;

public class Solution{
    public static void main(String[]args){
        /* Enter your code here. Read input from STDIN. Print output to STDOUT.
        Your class should be named Solution. *//**
    	Scanner sc=new Scanner(System.in);
    	try{
        	int
        			a=sc.nextInt(),
        			b=sc.nextInt();
        	
    		System.out.println(a/b);
    	}catch(InputMismatchException|ArithmeticException e){
    		if(e.toString().contains("java.util.InputMismatchException"))
    			System.out.println("java.util.InputMismatchException");
    		else
    			System.out.println(e);
    	}
    }
}**/>>