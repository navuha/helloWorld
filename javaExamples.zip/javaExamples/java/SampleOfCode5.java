This challenge I took through that URL: "https://www.hackerrank.com/challenges/java-sort":
<<You are given a list of student information: ID, FirstName, and CGPA. Your task is to rearrange
them according to their CGPA in decreasing order. If two student have the same CGPA, then arrange
them according to their first name in alphabetical order. If those two students also have the same
first name, then order them according to their ID. No two students have the same ID.

Hint: You can use comparators to sort a list of objects. See the oracle docs to learn about comparators.

Input Format
The first line of input contains an integer N, representing the total number of students. The next N
lines contains a list of student information in the following structure:
ID Name CGPA

Constraints
2<=N<=1000
0<=ID<=100000
5<=|Name|<=30
0<=CGPA<=4.00
The name contains only lowercase English letters. The ID contains only integer numbers without leading
zeros. The CGPA will contain, at most, 2 digits after the decimal point.

Output Format
After rearranging the students according to the above rules, print the first name of each student on
a separate line.

Sample Input
5
33 Rumpa 3.68
85 Ashis 3.85
56 Samiha 3.75
19 Samara 3.75
22 Fahim 3.76

Sample Output
Ashis
Fahim
Samara
Samiha
Rumpa>>

My answer:
<<package example;

import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class Student{
	private int id;
	private String fname;
	private double cgpa;
	
	public Student(int id,String fname,double cgpa){
		//super();//!
		this.id=id;
		this.fname=fname;
		this.cgpa=cgpa;
	}
	
	
	public int getId(){
		return id;
	}
	
	public String getFname(){
		return fname;
	}
	
	public double getCgpa(){
		return cgpa;
	}
}
//Complete the code
class Checker implements Comparator<Student>{//!
	private final int order;
	
	private Checker(int anOrder){
		order=anOrder;
	}
	
	static final Checker
			asc=new Checker(1),
			desc=new Checker(-1);
	
	Checker(){
		order=0;
	}
	
	
	private int innerCompare(Student firstStudent,Student secondStudent){
		double difference=firstStudent.getCgpa()-secondStudent.getCgpa();
		if(difference!=0.0)
			return
					difference>0.0?
						1
					:-1;
		else{// if(==)
			int fruitOfTheComparing=firstStudent.getFname().compareTo(secondStudent.getFname());
			return
					fruitOfTheComparing!=0?
						!(fruitOfTheComparing>0)?//!!
							1
						:-1
					:firstStudent.getId()-secondStudent.getId()>0?
						1
					:-1;
		}
	}
	
	public int compare(Student firstStudent,Student secondStudent){
		return order*innerCompare(firstStudent,secondStudent);
	}
}

public class SampleOfCode5{//Solution{
	public static void main(String[]args){
		Scanner in=new Scanner(System.in);
		int testCases=Integer.parseInt(in.nextLine());
		boolean permission=testCases>=2&&testCases<=1e3;//!
		
		List<Student>studentList=new ArrayList<>();
		while(testCases>0){
			int id=in.nextInt();
			String fname=in.next();
			double cgpa=Double.parseDouble(in.next());//!
			int lengthOfTheFname=fname.length();//!
			permission&=id>=0&&id<=1e5//!
					&&lengthOfTheFname>=4&&lengthOfTheFname<=30//!an error in the task: 5->4;
					&&cgpa>=0.0&&cgpa<=4.0;
			if(!permission){//!
				System.out.println("This data is not permitted!");
				break;
			}
			
			Student st=new Student(id,fname,cgpa);
			studentList.add(st);
			
			testCases--;
		}
		
		in.close();//!
		
		Collections.sort(studentList,new Checker().desc);//!
		
		for(Student st:studentList){
			System.out.println(st.getFname());
		}
	}
}>>